package com.custom.smartkeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipItem(
    val text: String,
    val pinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class LangOption(
    val code: String,
    val name: String,
    val nativeLabel: String
)

object KeyboardPrefs {
    private const val PREFS = "smart_keyboard_prefs"

    val supportedLanguages = listOf(
        LangOption("en", "English (India)", "EN"),
        LangOption("hi", "Hindi", "हिन्दी"),
        LangOption("ur", "Urdu", "اردو"),
        LangOption("pa", "Punjabi", "ਪੰਜਾਬੀ"),
        LangOption("bn", "Bengali", "বাংলা"),
        LangOption("mr", "Marathi", "मराठी"),
        LangOption("ta", "Tamil", "தமிழ்"),
        LangOption("te", "Telugu", "తెలుగు"),
        LangOption("gu", "Gujarati", "ગુજરાતી"),
        LangOption("ar", "Arabic", "العربية"),
        LangOption("es", "Spanish", "Español"),
        LangOption("fr", "French", "Français"),
        LangOption("de", "German", "Deutsch"),
        LangOption("ja", "Japanese", "日本語"),
        LangOption("ko", "Korean", "한국어")
    )

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var themeIndex: Int = 0
    fun getThemeIndex(ctx: Context): Int = prefs(ctx).getInt("theme_idx", 0)
    fun setThemeIndex(ctx: Context, idx: Int) = prefs(ctx).edit().putInt("theme_idx", idx).apply()

    fun isNumberRow(ctx: Context): Boolean = prefs(ctx).getBoolean("number_row", true)
    fun setNumberRow(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("number_row", v).apply()

    fun isAutoCap(ctx: Context): Boolean = prefs(ctx).getBoolean("auto_cap", true)
    fun setAutoCap(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("auto_cap", v).apply()

    fun isSuggestionsOn(ctx: Context): Boolean = prefs(ctx).getBoolean("suggestions_on", true)
    fun setSuggestionsOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("suggestions_on", v).apply()

    fun isNextWordOn(ctx: Context): Boolean = prefs(ctx).getBoolean("next_word_on", true)
    fun setNextWordOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("next_word_on", v).apply()

    fun isSoundOn(ctx: Context): Boolean = prefs(ctx).getBoolean("sound_on", false)
    fun setSoundOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("sound_on", v).apply()

    fun getSoundVolume(ctx: Context): Int = prefs(ctx).getInt("sound_vol", 30)
    fun setSoundVolume(ctx: Context, v: Int) = prefs(ctx).edit().putInt("sound_vol", v.coerceIn(0, 100)).apply()

    fun isVibrateOn(ctx: Context): Boolean = prefs(ctx).getBoolean("vibrate_on", true)
    fun setVibrateOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("vibrate_on", v).apply()

    fun getVibrateMs(ctx: Context): Int = prefs(ctx).getInt("vibrate_ms", 12)
    fun setVibrateMs(ctx: Context, v: Int) = prefs(ctx).edit().putInt("vibrate_ms", v.coerceIn(0, 60)).apply()

    fun getHeightPercent(ctx: Context): Int = prefs(ctx).getInt("height_pct", 100)
    fun setHeightPercent(ctx: Context, v: Int) = prefs(ctx).edit().putInt("height_pct", v.coerceIn(80, 125)).apply()

    fun getFontStyle(ctx: Context): Int = prefs(ctx).getInt("font_style", 0)
    fun setFontStyle(ctx: Context, v: Int) = prefs(ctx).edit().putInt("font_style", v).apply()

    fun isTranslateOn(ctx: Context): Boolean = prefs(ctx).getBoolean("translate_on", true)
    fun setTranslateOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("translate_on", v).apply()

    fun getTargetLangCode(ctx: Context): String = prefs(ctx).getString("target_lang", "en") ?: "en"
    fun setTargetLangCode(ctx: Context, code: String) = prefs(ctx).edit().putString("target_lang", code).apply()

    fun isGrammarFixOn(ctx: Context): Boolean = prefs(ctx).getBoolean("grammar_fix", true)
    fun setGrammarFixOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("grammar_fix", v).apply()

    fun getGeminiApiKey(ctx: Context): String = prefs(ctx).getString("gemini_api_key", "") ?: ""
    fun setGeminiApiKey(ctx: Context, key: String) = prefs(ctx).edit().putString("gemini_api_key", key.trim()).apply()

    fun getTargetLangName(ctx: Context): String {
        val code = getTargetLangCode(ctx)
        return supportedLanguages.firstOrNull { it.code == code }?.name ?: "English"
    }

    fun getClips(ctx: Context): List<ClipItem> {
        val raw = prefs(ctx).getString("clips_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<ClipItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("t")
                if (t.isNotBlank()) {
                    list.add(ClipItem(t, o.optBoolean("p", false), o.optLong("ts", 0L)))
                }
            }
            list.sortedWith(compareByDescending<ClipItem> { it.pinned }.thenByDescending { it.timestamp })
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveClips(ctx: Context, items: List<ClipItem>) {
        val arr = JSONArray()
        items.take(25).forEach { c ->
            arr.put(JSONObject().apply {
                put("t", c.text)
                put("p", c.pinned)
                put("ts", c.timestamp)
            })
        }
        prefs(ctx).edit().putString("clips_json", arr.toString()).apply()
    }

    fun addClip(ctx: Context, text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val existing = getClips(ctx).toMutableList()
        val prev = existing.firstOrNull { it.text == clean }
        existing.removeAll { it.text == clean }
        existing.add(0, ClipItem(clean, pinned = prev?.pinned ?: false, timestamp = System.currentTimeMillis()))
        saveClips(ctx, existing)
    }

    fun togglePinClip(ctx: Context, text: String) {
        val list = getClips(ctx).map {
            if (it.text == text) it.copy(pinned = !it.pinned) else it
        }
        saveClips(ctx, list)
    }

    fun deleteClip(ctx: Context, text: String) {
        val list = getClips(ctx).filterNot { it.text == text }
        saveClips(ctx, list)
    }
}
