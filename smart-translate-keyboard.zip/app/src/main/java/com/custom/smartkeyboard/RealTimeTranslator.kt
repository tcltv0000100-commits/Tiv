package com.custom.smartkeyboard

import android.content.Context
import android.util.LruCache
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object RealTimeTranslator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val cache = LruCache<String, String>(120)
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    fun translateAndPolish(
        context: Context,
        text: String,
        targetLangCode: String,
        targetLangName: String,
        grammarFix: Boolean
    ): String? {
        val clean = text.trim()
        if (clean.length < 2) return null

        val key = "$targetLangCode|$grammarFix|$clean"
        cache.get(key)?.let { return it }

        // 1. If user added a free Gemini API key in Settings, use Gemini for pro Hinglish + grammar
        val geminiKey = KeyboardPrefs.getGeminiApiKey(context)
        if (geminiKey.isNotBlank()) {
            val geminiOut = translateWithGemini(clean, targetLangName, geminiKey)
            if (!geminiOut.isNullOrBlank()) {
                cache.put(key, geminiOut)
                return geminiOut
            }
        }

        // 2. Free zero-key fallback: translate.googleapis.com + optional LanguageTool grammar fix
        var translated = translateWithGoogleFree(clean, targetLangCode) ?: return null
        if (grammarFix && targetLangCode in setOf("en", "es", "fr", "de")) {
            translated = polishWithLanguageTool(translated, targetLangCode)
        }
        cache.put(key, translated)
        return translated
    }

    private fun translateWithGemini(text: String, targetLangName: String, apiKey: String): String? {
        return try {
            val prompt = "Translate the following text (which may be Hinglish, Hindi, or any language) into natural $targetLangName with proper grammar, spelling, and punctuation. Return ONLY the final translated text, nothing else:\n$text"
            val body = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    )
                )
            }
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
            val req = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody(jsonMedia))
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val json = JSONObject(resp.body?.string() ?: return null)
                val out = json.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?.trim()
                out?.takeIf { it.isNotBlank() }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun translateWithGoogleFree(text: String, targetLang: String): String? {
        return try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$targetLang&dt=t&q=$encoded"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string() ?: return null
                val outer = JSONArray(raw)
                val sentences = outer.optJSONArray(0) ?: return null
                val sb = StringBuilder()
                for (i in 0 until sentences.length()) {
                    val part = sentences.optJSONArray(i)?.optString(0) ?: ""
                    sb.append(part)
                }
                val result = sb.toString().trim()
                result.takeIf { it.isNotBlank() }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun polishWithLanguageTool(text: String, langCode: String): String {
        return try {
            val form = FormBody.Builder()
                .add("text", text)
                .add("language", if (langCode == "en") "en-US" else langCode)
                .build()
            val req = Request.Builder()
                .url("https://api.languagetool.org/v2/check")
                .post(form)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return text
                val json = JSONObject(resp.body?.string() ?: return text)
                val matches = json.optJSONArray("matches") ?: return text
                if (matches.length() == 0) return text

                val sb = StringBuilder(text)
                // Apply replacements from end to start so offsets stay valid
                val edits = mutableListOf<Triple<Int, Int, String>>()
                for (i in 0 until matches.length()) {
                    val m = matches.optJSONObject(i) ?: continue
                    val offset = m.optInt("offset", -1)
                    val len = m.optInt("length", 0)
                    val rep = m.optJSONArray("replacements")?.optJSONObject(0)?.optString("value")
                    if (offset >= 0 && len > 0 && !rep.isNullOrBlank()) {
                        edits.add(Triple(offset, len, rep))
                    }
                }
                edits.sortByDescending { it.first }
                for ((offset, len, rep) in edits) {
                    if (offset + len <= sb.length) {
                        sb.replace(offset, offset + len, rep)
                    }
                }
                sb.toString()
            }
        } catch (_: Exception) {
            text
        }
    }
}
