package com.custom.smartkeyboard

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF121216.toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 64, 44, 60)
        }

        root.addView(TextView(this).apply {
            text = "Keyboard & Translation Settings"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 28)
        })

        fun addSwitch(label: String, initial: Boolean, onToggle: (Boolean) -> Unit) {
            root.addView(Switch(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = initial
                setPadding(0, 18, 0, 18)
                setOnCheckedChangeListener { _, checked -> onToggle(checked) }
            })
        }

        addSwitch("Real-Time Translation", KeyboardPrefs.isTranslateOn(this)) {
            KeyboardPrefs.setTranslateOn(this, it)
        }
        addSwitch("Auto Grammar & Spelling Polish (LanguageTool)", KeyboardPrefs.isGrammarFixOn(this)) {
            KeyboardPrefs.setGrammarFixOn(this, it)
        }
        addSwitch("Show Number Row", KeyboardPrefs.isNumberRow(this)) {
            KeyboardPrefs.setNumberRow(this, it)
        }
        addSwitch("Word Suggestions & Auto-Complete", KeyboardPrefs.isSuggestionsOn(this)) {
            KeyboardPrefs.setSuggestionsOn(this, it)
        }
        addSwitch("Next-Word Suggestions", KeyboardPrefs.isNextWordOn(this)) {
            KeyboardPrefs.setNextWordOn(this, it)
        }
        addSwitch("Auto-Capitalization", KeyboardPrefs.isAutoCap(this)) {
            KeyboardPrefs.setAutoCap(this, it)
        }
        addSwitch("Keypress Sound", KeyboardPrefs.isSoundOn(this)) {
            KeyboardPrefs.setSoundOn(this, it)
        }
        addSwitch("Keypress Vibration", KeyboardPrefs.isVibrateOn(this)) {
            KeyboardPrefs.setVibrateOn(this, it)
        }

        root.addView(TextView(this).apply {
            text = "Default Target Translation Language"
            textSize = 14f
            setTextColor(0xFFB0B0BA.toInt())
            setPadding(0, 28, 0, 10)
        })

        val langNames = KeyboardPrefs.supportedLanguages.map { "${it.name} (${it.nativeLabel})" }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, langNames)
            val currentIdx = KeyboardPrefs.supportedLanguages.indexOfFirst { it.code == KeyboardPrefs.getTargetLangCode(this@SettingsActivity) }
            if (currentIdx >= 0) setSelection(currentIdx)
        }
        root.addView(spinner)

        root.addView(TextView(this).apply {
            text = "Optional Free Gemini API Key (for best Hinglish & pro grammar; leave blank for zero-key free translator)"
            textSize = 13f
            setTextColor(0xFFB0B0BA.toInt())
            setPadding(0, 32, 0, 10)
        })

        val keyInput = EditText(this).apply {
            hint = "Paste Gemini API Key (optional)"
            setText(KeyboardPrefs.getGeminiApiKey(this@SettingsActivity))
            setHintTextColor(0xFF7A7A85.toInt())
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF222228.toInt())
            setPadding(24, 24, 24, 24)
        }
        root.addView(keyInput)

        root.addView(Button(this).apply {
            text = "Save Settings"
            setOnClickListener {
                val chosenLang = KeyboardPrefs.supportedLanguages[spinner.selectedItemPosition]
                KeyboardPrefs.setTargetLangCode(this@SettingsActivity, chosenLang.code)
                KeyboardPrefs.setGeminiApiKey(this@SettingsActivity, keyInput.text.toString())
                Toast.makeText(this@SettingsActivity, "Settings saved!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 24
            }
        })

        scroll.addView(root)
        setContentView(scroll)
    }
}
