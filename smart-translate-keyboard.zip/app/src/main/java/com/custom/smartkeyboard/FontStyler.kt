package com.custom.smartkeyboard

object FontStyler {
    val styleNames = arrayOf("Default", "Bold", "Italic", "Mono", "SmallCaps")

    fun apply(text: String, styleIndex: Int): String {
        if (styleIndex == 0 || text.isEmpty()) return text
        val sb = StringBuilder(text.length)
        for (ch in text) {
            sb.append(transformChar(ch, styleIndex))
        }
        return sb.toString()
    }

    private fun transformChar(ch: Char, style: Int): String {
        return when (style) {
            1 -> when (ch) { // Mathematical Bold
                in 'A'..'Z' -> String(Character.toChars(0x1D400 + (ch - 'A')))
                in 'a'..'z' -> String(Character.toChars(0x1D41A + (ch - 'a')))
                in '0'..'9' -> String(Character.toChars(0x1D7CE + (ch - '0')))
                else -> ch.toString()
            }
            2 -> when (ch) { // Mathematical Italic
                in 'A'..'Z' -> String(Character.toChars(0x1D434 + (ch - 'A')))
                'h' -> "\u210E"
                in 'a'..'z' -> String(Character.toChars(0x1D44E + (ch - 'a')))
                else -> ch.toString()
            }
            3 -> when (ch) { // Mathematical Monospace
                in 'A'..'Z' -> String(Character.toChars(0x1D670 + (ch - 'A')))
                in 'a'..'z' -> String(Character.toChars(0x1D68A + (ch - 'a')))
                in '0'..'9' -> String(Character.toChars(0x1D7F6 + (ch - '0')))
                else -> ch.toString()
            }
            4 -> smallCapsMap[ch]?.toString() ?: ch.toString()
            else -> ch.toString()
        }
    }

    private val smallCapsMap = mapOf(
        'a' to 'ᴀ', 'b' to 'ʙ', 'c' to 'ᴄ', 'd' to 'ᴅ', 'e' to 'ᴇ',
        'f' to 'ꜰ', 'g' to 'ɢ', 'h' to 'ʜ', 'i' to 'ɪ', 'j' to 'ᴊ',
        'k' to 'ᴋ', 'l' to 'ʟ', 'm' to 'ᴍ', 'n' to 'ɴ', 'o' to 'ᴏ',
        'p' to 'ᴘ', 'q' to 'ǫ', 'r' to 'ʀ', 's' to 's', 't' to 'ᴛ',
        'u' to 'ᴜ', 'v' to 'ᴠ', 'w' to 'ᴡ', 'x' to 'x', 'y' to 'ʏ', 'z' to 'ᴢ'
    )
}
