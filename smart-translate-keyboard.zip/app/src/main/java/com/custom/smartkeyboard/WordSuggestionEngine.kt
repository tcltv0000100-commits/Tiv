package com.custom.smartkeyboard

import java.util.LinkedHashSet

object WordSuggestionEngine {

    private val commonWords = listOf(
        // Common English + Indian English + Hinglish everyday words
        "the", "that", "this", "there", "their", "they", "them", "then", "than", "thank", "thanks",
        "you", "your", "yours", "yeah", "yes", "yesterday", "today", "tomorrow", "tonight",
        "what", "when", "where", "which", "who", "why", "will", "with", "would", "want", "wait",
        "have", "has", "had", "here", "hello", "help", "home", "how", "happy", "hope", "good",
        "great", "going", "gone", "give", "get", "getting", "got", "fine", "from", "for", "friend",
        "are", "and", "about", "after", "again", "all", "also", "always", "already", "any", "anything",
        "please", "possible", "problem", "project", "phone", "photo", "send", "sent", "sending",
        "sorry", "sure", "soon", "some", "someone", "something", "sometimes", "start", "stop",
        "call", "calling", "came", "come", "coming", "can", "cannot", "could", "check", "checked",
        "make", "making", "made", "many", "maybe", "mean", "meeting", "message", "money", "more", "morning",
        "need", "never", "new", "next", "nice", "night", "nothing", "now", "number",
        "okay", "only", "open", "order", "other", "our", "out", "over",
        "right", "ready", "really", "reply", "report", "remember", "request",
        "see", "seen", "say", "said", "same", "save", "share", "should", "show", "sleep",
        "take", "taking", "talk", "talking", "tell", "telling", "text", "think", "time", "told",
        "update", "understand", "until", "use", "using", "very", "video", "voice",
        "work", "working", "watch", "watching", "water", "week", "well", "went", "were", "while",
        // Common Hinglish words
        "bhai", "bro", "kya", "hai", "hain", "ho", "haan", "nahi", "nhi", "acha", "achha",
        "theek", "thik", "kaisa", "kaise", "kahan", "kab", "kyun", "kyu", "kar", "karo", "karna",
        "raha", "rahi", "rahe", "hu", "hoon", "main", "mein", "hum", "aap", "tum", "tera", "mera",
        "abhi", "baad", "kal", "aaj", "subah", "raat", "ghar", "office", "yaar", "dost", "mast",
        "badiya", "badhiya", "bhej", "bhejo", "bheja", "dekh", "dekho", "dekha", "sun", "suno",
        "bol", "bolo", "bola", "milte", "milna", "chalo", "chal", "ruko", "ruk", "jaldi", "samajh"
    )

    private val nextWordMap = mapOf(
        "how" to listOf("are", "is", "much"),
        "are" to listOf("you", "we", "they"),
        "i" to listOf("am", "will", "have"),
        "thank" to listOf("you", "u", "god"),
        "good" to listOf("morning", "night", "evening"),
        "see" to listOf("you", "it", "later"),
        "what" to listOf("is", "are", "happened"),
        "where" to listOf("are", "is", "you"),
        "please" to listOf("send", "check", "call"),
        "call" to listOf("me", "you", "back"),
        "send" to listOf("me", "it", "the"),
        "kya" to listOf("hua", "kar", "hai"),
        "kaise" to listOf("ho", "hai", "hain"),
        "kaisa" to listOf("hai", "lag", "chal"),
        "theek" to listOf("hai", "hu", "hoon"),
        "kal" to listOf("milte", "aana", "subah"),
        "abhi" to listOf("aata", "karta", "nahi"),
        "ok" to listOf("bro", "bhai", "done"),
        "bhai" to listOf("kya", "kaise", "sun")
    )

    private val learnedWords = LinkedHashSet<String>()

    fun learnWord(word: String) {
        val w = word.trim().lowercase()
        if (w.length in 2..24 && w.all { it.isLetter() }) {
            learnedWords.add(w)
            if (learnedWords.size > 300) {
                learnedWords.iterator().let { it.next(); it.remove() }
            }
        }
    }

    fun suggestForCurrentWord(prefix: String): List<String> {
        val p = prefix.trim()
        if (p.isEmpty()) return emptyList()
        val lower = p.lowercase()
        val isCapitalized = p.firstOrNull()?.isUpperCase() == true

        val results = LinkedHashSet<String>()
        // 1. Learned words matching prefix
        for (w in learnedWords) {
            if (w.startsWith(lower) && w != lower) results.add(w)
            if (results.size >= 3) break
        }
        // 2. Built-in dictionary prefix match
        if (results.size < 3) {
            for (w in commonWords) {
                if (w.startsWith(lower)) results.add(w)
                if (results.size >= 3) break
            }
        }
        // 3. Simple typo/edit-distance-1 correction if few matches
        if (results.size < 2 && lower.length >= 3) {
            for (w in commonWords) {
                if (kotlin.math.abs(w.length - lower.length) <= 1 && editDistance(w, lower) == 1) {
                    results.add(w)
                    if (results.size >= 3) break
                }
            }
        }

        return results.take(3).map { w ->
            if (isCapitalized) w.replaceFirstChar { it.uppercase() } else w
        }
    }

    fun suggestNextWords(previousWord: String): List<String> {
        val prev = previousWord.trim().lowercase()
        if (prev.isEmpty()) return listOf("I", "Hi", "Okay")
        return nextWordMap[prev] ?: listOf("is", "and", "the")
    }

    private fun editDistance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev
                else 1 + minOf(prev, dp[j], dp[j - 1])
                prev = temp
            }
        }
        return dp[b.length]
    }
}
