package com.custom.smartkeyboard

import java.util.LinkedHashSet

object WordSuggestionEngine {

    private val dictionary: List<String> by lazy {
        rawWords.split(' ').filter { it.isNotBlank() }
    }

    // High-frequency English + Indian English + Hinglish vocabulary
    private const val rawWords =
        "the be to of and a in that have i it for not on with he as you do at " +
        "this but his by from they we say her she or an will my one all would there their what " +
        "so up out if about who get which go me when make can like time no just him know take " +
        "people into year your good some could them see other than then now look only come its over " +
        "think also back after use two how our work first well way even new want because any these " +
        "give day most us is are was were been being am has had did does doing done having " +
        "hello hi hey okay ok yes yeah yep nope no sorry thanks thank please welcome fine great " +
        "good morning afternoon evening night today tomorrow yesterday tonight later soon now " +
        "always never sometimes often usually really actually basically literally maybe probably " +
        "very much many more most less few little lot lots enough almost already still yet " +
        "call calling called text message msg chat reply sent send sending share shared photo pic " +
        "video audio voice link file download upload open close start stop check checked checking " +
        "watch watching look looking listen listening play playing game music song movie " +
        "phone mobile laptop computer screen battery charger network wifi internet data " +
        "home house room office school college class work job meeting boss team friend friends " +
        "family brother sister mother father mom dad bro sis sir madam buddy dude guys " +
        "love like miss hate care happy sad angry excited tired busy free ready wait waiting " +
        "food water tea coffee breakfast lunch dinner eat eating drink drinking hungry " +
        "money price cost free paid pay payment bank account order delivery address location " +
        "name number email password login account profile settings update version install " +
        "question answer problem issue error bug fix fixed working proper properly fast slow " +
        "better best nice awesome amazing cool super perfect clean simple easy hard " +
        "understand understood remember forget forgot believe hope wish need needed " +
        "change changed changes create created make made build built write written read " +
        "person people someone anyone everyone nobody something anything everything nothing " +
        "where when why how which whose whom whatever whenever wherever " +
        "before after during while since until between among through around against " +
        "because although though unless however therefore anyway besides instead " +
        "actually apparently certainly clearly completely definitely directly especially " +
        "exactly extremely finally generally immediately importantly naturally obviously " +
        "originally particularly personally possibly quickly seriously simply suddenly " +
        "tomorrow weekend monday tuesday wednesday thursday friday saturday sunday " +
        "january february march april may june july august september october november december " +
        // Hinglish high-frequency words
        "bhai kya hai hain ho raha rahi rahe hu hoon main mein hum aap tum tera mera " +
        "haan nahi nhi acha achha theek thik kaisa kaise kahan kab kyun kyu kar karo karna " +
        "abhi baad kal aaj subah raat ghar office yaar dost mast badiya badhiya " +
        "bhej bhejo bheja dekh dekho dekha sun suno bol bolo bola milte milna chalo chal " +
        "ruko ruk jaldi samajh samjha bata batao bataya pucha pooch poochho " +
        "kaam paisa samay waqt zindagi pyar dosti khushi tension problem dikkat " +
        "lekin par magar aur ya phir fir toh to bhi hi tohna hoga hogi honge " +
        "kuchh kuch sab sabhi koi kisi apna apni apne yahan wahan jahan " +
        "iska uska jiska kiska inka unka hamara tumhara " +
        "chahiye chahie lagta lagti lagte sakta sakti sakte pata malum " +
        "karna karunga karungi karenge kiya kiye diya diye liya liye gaya gayi gaye " +
        "aaya aayi aaye aana jaana rehna sona khana peena milna rakhna dena lena " +
        "bahut bohot zyada jyada kam thoda bilkul ekdam ditto same alag naya purana " +
        "sahi galat bura accha bekar zabardast solid"

    private val nextWordMap = mapOf(
        "how" to listOf("are", "is", "much"),
        "are" to listOf("you", "we", "they"),
        "i" to listOf("am", "will", "have"),
        "thank" to listOf("you", "u", "god"),
        "thanks" to listOf("a", "bro", "for"),
        "good" to listOf("morning", "night", "evening"),
        "see" to listOf("you", "it", "later"),
        "what" to listOf("is", "are", "happened"),
        "where" to listOf("are", "is", "you"),
        "please" to listOf("send", "check", "call"),
        "call" to listOf("me", "you", "back"),
        "send" to listOf("me", "it", "the"),
        "can" to listOf("you", "i", "we"),
        "will" to listOf("be", "do", "send"),
        "going" to listOf("to", "home", "out"),
        "want" to listOf("to", "this", "it"),
        "need" to listOf("to", "help", "this"),
        "kya" to listOf("hua", "kar", "hai"),
        "kaise" to listOf("ho", "hai", "hain"),
        "kaisa" to listOf("hai", "lag", "chal"),
        "theek" to listOf("hai", "hu", "hoon"),
        "kal" to listOf("milte", "aana", "subah"),
        "abhi" to listOf("aata", "karta", "nahi"),
        "ok" to listOf("bro", "bhai", "done"),
        "bhai" to listOf("kya", "kaise", "sun"),
        "main" to listOf("abhi", "kal", "ghar"),
        "aap" to listOf("kaise", "kahan", "kab")
    )

    private val learnedWords = LinkedHashSet<String>()

    fun learnWord(word: String) {
        val w = word.trim().lowercase()
        if (w.length in 2..24 && w.all { it.isLetter() }) {
            learnedWords.add(w)
            if (learnedWords.size > 400) {
                learnedWords.iterator().let { it.next(); it.remove() }
            }
        }
    }

    fun suggestForCurrentWord(prefix: String): List<String> {
        val p = prefix.trim()
        if (p.isEmpty()) return emptyList()
        val lower = p.lowercase()
        val isCapitalized = p.firstOrNull()?.isUpperCase() == true

        val results = LinkedHashSet<String>()
        // 1. Learned words matching prefix
        for (w in learnedWords) {
            if (w.startsWith(lower)) results.add(w)
            if (results.size >= 3) break
        }
        // 2. Built-in dictionary exact or prefix match
        if (results.size < 3) {
            for (w in dictionary) {
                if (w.startsWith(lower)) results.add(w)
                if (results.size >= 3) break
            }
        }
        // 3. Edit-distance-1 typo correction for words >= 3 chars
        if (results.size < 2 && lower.length >= 3) {
            for (w in dictionary) {
                if (kotlin.math.abs(w.length - lower.length) <= 1 && editDistance(w, lower) == 1) {
                    results.add(w)
                    if (results.size >= 3) break
                }
            }
        }

        return results.take(3).map { w ->
            if (isCapitalized) w.replaceFirstChar { it.uppercase() } else w
        }
    }

    fun suggestNextWords(previousWord: String): List<String> {
        val prev = previousWord.trim().lowercase()
        if (prev.isEmpty()) return listOf("I", "Hi", "Okay")
        return nextWordMap[prev] ?: listOf("is", "and", "to")
    }

    private fun editDistance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev
                else 1 + minOf(prev, dp[j], dp[j - 1])
                prev = temp
            }
        }
        return dp[b.length]
    }
}
