package com.custom.smartkeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF121216.toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 60)
        }

        root.addView(TextView(this).apply {
            text = "Emoji Keyboard"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        })
        root.addView(TextView(this).apply {
            text = "Type in any language (including Hinglish) and get real-time translated & grammatically polished text + word suggestions."
            textSize = 14f
            setTextColor(0xFFB0B0BA.toInt())
            setPadding(0, 0, 0, 36)
        })

        root.addView(Button(this).apply {
            text = "1. Enable Keyboard in System Settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "2. Select Emoji Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 18
            }
        })

        root.addView(Button(this).apply {
            text = "3. Keyboard & Translation Settings"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 18
            }
        })

        root.addView(TextView(this).apply {
            text = "Test Typing Here:"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 40, 0, 12)
        })

        root.addView(EditText(this).apply {
            hint = "Tap here to test keyboard & live translation..."
            setHintTextColor(0xFF8E8E98.toInt())
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF222228.toInt())
            setPadding(32, 32, 32, 32)
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
        })

        scroll.addView(root)
        setContentView(scroll)
    }
}
