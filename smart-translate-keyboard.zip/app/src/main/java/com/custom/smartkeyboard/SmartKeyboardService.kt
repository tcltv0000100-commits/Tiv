package com.custom.smartkeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognizerIntent
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SmartKeyboardService : InputMethodService() {

    private data class KbTheme(
        val name: String,
        val bg: Int,
        val keyBg: Int,
        val specialKeyBg: Int,
        val accent: Int,
        val text: Int,
        val subText: Int,
        val barBg: Int
    )

    private val themes = listOf(
        KbTheme("Dark", 0xFF141416.toInt(), 0xFF2B2B2F.toInt(), 0xFF202024.toInt(), 0xFF4A8CFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF9E9EA8.toInt(), 0xFF1B1B1F.toInt()),
        KbTheme("AMOLED", 0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF121214.toInt(), 0xFF4A8CFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF8E8E93.toInt(), 0xFF0A0A0C.toInt()),
        KbTheme("Light", 0xFFECEEF2.toInt(), 0xFFFFFFFF.toInt(), 0xFFD5D8E0.toInt(), 0xFF2563EB.toInt(), 0xFF111111.toInt(), 0xFF5F6368.toInt(), 0xFFE2E5EC.toInt()),
        KbTheme("Ocean", 0xFF0B192C.toInt(), 0xFF172D4A.toInt(), 0xFF11223A.toInt(), 0xFF38BDF8.toInt(), 0xFFFFFFFF.toInt(), 0xFF94A3B8.toInt(), 0xFF0F2138.toInt()),
        KbTheme("Crimson", 0xFF1E0B10.toInt(), 0xFF35151E.toInt(), 0xFF280E16.toInt(), 0xFFFF4D6D.toInt(), 0xFFFFFFFF.toInt(), 0xFFD1A3AE.toInt(), 0xFF240D13.toInt())
    )

    private enum class PanelMode {
        QWERTY, SYMBOLS_1, SYMBOLS_2, MENU_GRID, EMOJI, CLIPBOARD, TEXT_EDIT, THEMES, FONT, SOUND_VIB, SIZE, TARGET_LANG
    }

    private var panelMode = PanelMode.QWERTY
    private var shiftState = 0 // 0=lower, 1=shift, 2=caps
    private var lastShiftTapMs = 0L

    private lateinit var rootContainer: LinearLayout
    private lateinit var toolbarRow: LinearLayout
    private lateinit var translateBanner: LinearLayout
    private lateinit var translatePreviewText: TextView
    private lateinit var translateApplyBtn: TextView
    private lateinit var suggestionStrip: LinearLayout
    private lateinit var panelHost: FrameLayout

    private lateinit var translateToggleBtn: TextView
    private lateinit var targetLangBtn: TextView

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var translateJob: Job? = null
    private var lastTranslatedResult: String = ""
    private var lastTranslatedSource: String = ""

    private var clipboardManager: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager?.primaryClip
        val txt = clip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!txt.isNullOrBlank()) {
            KeyboardPrefs.addClip(this, txt)
            if (panelMode == PanelMode.CLIPBOARD) rebuildPanel()
        }
    }

    private val quickEmojis = listOf("😂", "🥰", "😍", "😘", "😭", "😜", "👍", "❤️", "🔥", "🙏")

    private var isSelectingText = false

    override fun onCreate() {
        super.onCreate()
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        try {
            clipboardManager?.addPrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        translateJob?.cancel()
        serviceScope.cancel()
        try {
            clipboardManager?.removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {}
    }

    override fun onCreateInputView(): View {
        rootContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        buildRootUi()
        return rootContainer
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        panelMode = PanelMode.QWERTY
        updateAutoCapState()
        buildRootUi()
        refreshSuggestionsAndTranslate()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (panelMode == PanelMode.QWERTY) {
            updateAutoCapState()
            refreshSuggestionsAndTranslate()
        }
    }

    private fun theme(): KbTheme = themes[KeyboardPrefs.getThemeIndex(this).coerceIn(0, themes.lastIndex)]

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun roundedBg(color: Int, radiusDp: Int = 8, strokeColor: Int = 0, strokeWidthDp: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != 0 && strokeWidthDp > 0) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }
    }

    private fun buildRootUi() {
        val t = theme()
        rootContainer.removeAllViews()
        rootContainer.setBackgroundColor(t.bg)

        // 1. Top Toolbar
        toolbarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(t.barBg)
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        addToolbarButton("⊞", "Menu") {
            panelMode = if (panelMode == PanelMode.MENU_GRID) PanelMode.QWERTY else PanelMode.MENU_GRID
            rebuildPanel()
        }
        addToolbarButton("😊", "Emoji") {
            panelMode = if (panelMode == PanelMode.EMOJI) PanelMode.QWERTY else PanelMode.EMOJI
            rebuildPanel()
        }

        val trOn = KeyboardPrefs.isTranslateOn(this)
        translateToggleBtn = TextView(this).apply {
            text = if (trOn) "🌐 Translate ON" else "🌐 Translate"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (trOn) Color.WHITE else t.subText)
            background = roundedBg(if (trOn) t.accent else t.keyBg, 14)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            setOnClickListener {
                val next = !KeyboardPrefs.isTranslateOn(this@SmartKeyboardService)
                KeyboardPrefs.setTranslateOn(this@SmartKeyboardService, next)
                buildRootUi()
                refreshSuggestionsAndTranslate()
            }
        }
        toolbarRow.addView(translateToggleBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(4)
        })

        targetLangBtn = TextView(this).apply {
            val lang = KeyboardPrefs.supportedLanguages.firstOrNull { it.code == KeyboardPrefs.getTargetLangCode(this@SmartKeyboardService) }
            text = "→ ${lang?.nativeLabel ?: "EN"} ▾"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            background = roundedBg(t.keyBg, 14)
            setPadding(dp(9), dp(5), dp(9), dp(5))
            setOnClickListener {
                panelMode = if (panelMode == PanelMode.TARGET_LANG) PanelMode.QWERTY else PanelMode.TARGET_LANG
                rebuildPanel()
            }
        }
        toolbarRow.addView(targetLangBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(4)
        })

        toolbarRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        addToolbarButton("📋", "Clipboard") {
            panelMode = if (panelMode == PanelMode.CLIPBOARD) PanelMode.QWERTY else PanelMode.CLIPBOARD
            rebuildPanel()
        }
        addToolbarButton("↔", "Text Edit") {
            panelMode = if (panelMode == PanelMode.TEXT_EDIT) PanelMode.QWERTY else PanelMode.TEXT_EDIT
            rebuildPanel()
        }
        addToolbarButton("⚙", "Settings") {
            openSettings()
        }
        rootContainer.addView(toolbarRow)

        // 2. Live Translation Preview Banner
        translateBanner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(t.barBg)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
        }
        translatePreviewText = TextView(this).apply {
            textSize = 13f
            setTextColor(t.text)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener { applyTranslatedText() }
        }
        translateBanner.addView(translatePreviewText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        translateApplyBtn = TextView(this).apply {
            text = "Apply ✓"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = roundedBg(0xFF22C55E.toInt(), 12)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { applyTranslatedText() }
        }
        translateBanner.addView(translateApplyBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(8)
        })
        rootContainer.addView(translateBanner)

        // 3. Word Suggestions / Quick Emoji Strip
        suggestionStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(t.bg)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        rootContainer.addView(suggestionStrip)

        // 4. Main Panel Host
        panelHost = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        rootContainer.addView(panelHost)

        rebuildPanel()
        refreshSuggestionsAndTranslate()
    }

    private fun addToolbarButton(label: String, desc: String, onClick: () -> Unit) {
        val t = theme()
        val tv = TextView(this).apply {
            text = label
            contentDescription = desc
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(t.text)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener {
                performFeedback()
                onClick()
            }
        }
        toolbarRow.addView(tv)
    }

    private fun rebuildPanel() {
        panelHost.removeAllViews()
        when (panelMode) {
            PanelMode.QWERTY -> buildQwertyPanel()
            PanelMode.SYMBOLS_1 -> buildSymbolsPanel(page2 = false)
            PanelMode.SYMBOLS_2 -> buildSymbolsPanel(page2 = true)
            PanelMode.MENU_GRID -> buildMenuGridPanel()
            PanelMode.EMOJI -> buildEmojiPanel()
            PanelMode.CLIPBOARD -> buildClipboardPanel()
            PanelMode.TEXT_EDIT -> buildTextEditPanel()
            PanelMode.THEMES -> buildThemesPanel()
            PanelMode.FONT -> buildFontPanel()
            PanelMode.SOUND_VIB -> buildSoundVibPanel()
            PanelMode.SIZE -> buildSizePanel()
            PanelMode.TARGET_LANG -> buildTargetLangPanel()
        }
    }

    private fun keyHeightPx(): Int {
        val scale = KeyboardPrefs.getHeightPercent(this) / 100f
        return (dp(44) * scale).toInt()
    }

    private fun buildQwertyPanel() {
        val t = theme()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }

        if (KeyboardPrefs.isNumberRow(this)) {
            col.addView(buildCharRow(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"), isNumberRow = true))
        }

        val r1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val r2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val r3 = listOf("z", "x", "c", "v", "b", "n", "m")

        col.addView(buildCharRow(r1))
        col.addView(buildCharRow(r2, horizontalPadDp = 16))

        // Row 3 with Shift + Letters + Backspace
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
        }
        val shiftLabel = when (shiftState) {
            2 -> "⇪"
            1 -> "⬆"
            else -> "⇧"
        }
        row3.addView(buildSpecialKey(shiftLabel, 1.45f, isActive = shiftState > 0) {
            val now = System.currentTimeMillis()
            shiftState = if (shiftState == 1 && now - lastShiftTapMs < 350) 2
            else if (shiftState > 0) 0 else 1
            lastShiftTapMs = now
            rebuildPanel()
        })
        for (ch in r3) {
            val out = if (shiftState > 0) ch.uppercase() else ch
            row3.addView(buildLetterKey(out, 1f))
        }
        row3.addView(buildBackspaceKey(1.45f))
        col.addView(row3)

        // Row 4: ?123 , 😊 [Spacebar] . Enter
        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(2))
        }
        row4.addView(buildSpecialKey("?123", 1.35f) {
            panelMode = PanelMode.SYMBOLS_1
            rebuildPanel()
        })
        row4.addView(buildLetterKey(",", 0.9f, isSpecialBg = true))
        row4.addView(buildSpecialKey("😊", 0.95f) {
            panelMode = PanelMode.EMOJI
            rebuildPanel()
        })
        val spaceText = "${KeyboardPrefs.getTargetLangName(this).substringBefore(" ")} • Space"
        row4.addView(buildSpaceKey(spaceText, 4.1f))
        row4.addView(buildLetterKey(".", 0.9f, isSpecialBg = true))
        row4.addView(buildEnterKey(1.55f))
        col.addView(row4)

        panelHost.addView(col)
    }

    private fun buildSymbolsPanel(page2: Boolean) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        val r1 = if (!page2) listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        else listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆")
        val r2 = if (!page2) listOf("@", "#", "₹", "_", "&", "-", "+", "(", ")", "/")
        else listOf("£", "¢", "€", "¥", "^", "°", "=", "{", "}", "\\")
        val r3 = if (!page2) listOf("*", "\"", "'", ":", ";", "!", "?")
        else listOf("%", "©", "®", "™", "✓", "[", "]")

        col.addView(buildCharRow(r1))
        col.addView(buildCharRow(r2))

        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
        }
        row3.addView(buildSpecialKey(if (!page2) "=\\<" else "?123", 1.45f) {
            panelMode = if (!page2) PanelMode.SYMBOLS_2 else PanelMode.SYMBOLS_1
            rebuildPanel()
        })
        for (ch in r3) row3.addView(buildLetterKey(ch, 1f))
        row3.addView(buildBackspaceKey(1.45f))
        col.addView(row3)

        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(2))
        }
        row4.addView(buildSpecialKey("ABC", 1.45f) {
            panelMode = PanelMode.QWERTY
            rebuildPanel()
        })
        row4.addView(buildLetterKey(",", 0.9f, isSpecialBg = true))
        row4.addView(buildSpaceKey("Space", 4.5f))
        row4.addView(buildLetterKey(".", 0.9f, isSpecialBg = true))
        row4.addView(buildEnterKey(1.55f))
        col.addView(row4)

        panelHost.addView(col)
    }

    private fun buildCharRow(chars: List<String>, horizontalPadDp: Int = 0, isNumberRow: Boolean = false): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(horizontalPadDp), dp(3), dp(horizontalPadDp), dp(3))
            for (c in chars) {
                addView(buildLetterKey(c, 1f, heightPx = if (isNumberRow) dp(36) else keyHeightPx()))
            }
        }
    }

    private fun buildLetterKey(label: String, weight: Float, isSpecialBg: Boolean = false, heightPx: Int = keyHeightPx()): TextView {
        val t = theme()
        val fontIdx = KeyboardPrefs.getFontStyle(this)
        val display = FontStyler.apply(label, fontIdx)
        return TextView(this).apply {
            text = display
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(t.text)
            background = roundedBg(if (isSpecialBg) t.specialKeyBg else t.keyBg, 7)
            layoutParams = LinearLayout.LayoutParams(0, heightPx, weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener {
                performFeedback()
                commitStyledText(label)
                if (shiftState == 1) {
                    shiftState = 0
                    rebuildPanel()
                }
                refreshSuggestionsAndTranslate()
            }
        }
    }

    private fun buildSpecialKey(label: String, weight: Float, isActive: Boolean = false, onClick: () -> Unit): TextView {
        val t = theme()
        return TextView(this).apply {
            text = label
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (isActive) Color.WHITE else t.text)
            background = roundedBg(if (isActive) t.accent else t.specialKeyBg, 7)
            layoutParams = LinearLayout.LayoutParams(0, keyHeightPx(), weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener {
                performFeedback()
                onClick()
            }
        }
    }

    private fun buildSpaceKey(label: String, weight: Float): TextView {
        val t = theme()
        return TextView(this).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(t.subText)
            background = roundedBg(t.keyBg, 7)
            layoutParams = LinearLayout.LayoutParams(0, keyHeightPx(), weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener {
                performFeedback()
                val ic = currentInputConnection ?: return@setOnClickListener
                val prevWord = getCurrentWordPrefix(ic)
                if (prevWord.isNotBlank()) WordSuggestionEngine.learnWord(prevWord)
                ic.commitText(" ", 1)
                updateAutoCapState()
                refreshSuggestionsAndTranslate()
            }
            setOnLongClickListener {
                panelMode = PanelMode.TARGET_LANG
                rebuildPanel()
                true
            }
        }
    }

    private fun buildBackspaceKey(weight: Float): TextView {
        val t = theme()
        val tv = TextView(this).apply {
            text = "⌫"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(t.text)
            background = roundedBg(t.specialKeyBg, 7)
            layoutParams = LinearLayout.LayoutParams(0, keyHeightPx(), weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
        }
        val repeatRunnable = object : Runnable {
            override fun run() {
                deleteOneChar()
                mainHandler.postDelayed(this, 60)
            }
        }
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    performFeedback()
                    deleteOneChar()
                    mainHandler.postDelayed(repeatRunnable, 350)
                    v.isPressed = true
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(repeatRunnable)
                    v.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun buildEnterKey(weight: Float): TextView {
        val t = theme()
        val imeAction = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_UNSPECIFIED
        val label = when (imeAction) {
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "↵"
        }
        return TextView(this).apply {
            text = label
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedBg(t.accent, 7)
            layoutParams = LinearLayout.LayoutParams(0, keyHeightPx(), weight).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            setOnClickListener {
                performFeedback()
                val ic = currentInputConnection ?: return@setOnClickListener
                if (imeAction in listOf(EditorInfo.IME_ACTION_SEARCH, EditorInfo.IME_ACTION_SEND, EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_NEXT)) {
                    ic.performEditorAction(imeAction)
                } else {
                    ic.commitText("\n", 1)
                }
            }
        }
    }

    private fun deleteOneChar() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
        updateAutoCapState()
        refreshSuggestionsAndTranslate()
    }

    private fun commitStyledText(raw: String) {
        val ic = currentInputConnection ?: return
        val styled = FontStyler.apply(raw, KeyboardPrefs.getFontStyle(this))
        ic.commitText(styled, 1)
    }

    private fun updateAutoCapState() {
        if (!KeyboardPrefs.isAutoCap(this) || shiftState == 2) return
        val ic = currentInputConnection ?: return
        val cap = ic.getCursorCapsMode(EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val newShift = if (cap != 0) 1 else 0
        if (newShift != shiftState && panelMode == PanelMode.QWERTY) {
            shiftState = newShift
            rebuildPanel()
        }
    }

    private fun getCurrentWordPrefix(ic: InputConnection): String {
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: return ""
        val idx = before.lastIndexOfAny(charArrayOf(' ', '\n', '\t', '.', ',', '!', '?'))
        return if (idx == -1) before else before.substring(idx + 1)
    }

    private fun getPreviousCompletedWord(ic: InputConnection): String {
        val before = ic.getTextBeforeCursor(60, 0)?.toString()?.trimEnd() ?: return ""
        val idx = before.lastIndexOfAny(charArrayOf(' ', '\n', '\t'))
        return if (idx == -1) before else before.substring(idx + 1)
    }

    private fun refreshSuggestionsAndTranslate() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(300, 0)?.toString() ?: ""

        // 1. Word / Next-Word Suggestions Strip
        suggestionStrip.removeAllViews()
        val t = theme()
        val currentPrefix = getCurrentWordPrefix(ic)
        val suggestions = if (KeyboardPrefs.isSuggestionsOn(this)) {
            if (currentPrefix.isNotEmpty()) {
                WordSuggestionEngine.suggestForCurrentWord(currentPrefix)
            } else if (KeyboardPrefs.isNextWordOn(this) && before.isNotBlank()) {
                WordSuggestionEngine.suggestNextWords(getPreviousCompletedWord(ic))
            } else emptyList()
        } else emptyList()

        if (suggestions.isNotEmpty()) {
            suggestions.forEachIndexed { idx, word ->
                val chip = TextView(this).apply {
                    text = word
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setTextColor(t.text)
                    setTypeface(null, if (idx == 0) Typeface.BOLD else Typeface.NORMAL)
                    setOnClickListener {
                        performFeedback()
                        if (currentPrefix.isNotEmpty()) {
                            ic.deleteSurroundingText(currentPrefix.length, 0)
                        }
                        WordSuggestionEngine.learnWord(word)
                        ic.commitText("$word ", 1)
                        refreshSuggestionsAndTranslate()
                    }
                }
                suggestionStrip.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                if (idx < suggestions.lastIndex) {
                    suggestionStrip.addView(View(this).apply { setBackgroundColor(t.specialKeyBg) }, LinearLayout.LayoutParams(dp(1), dp(20)))
                }
            }
        } else {
            val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            for (em in quickEmojis) {
                val tv = TextView(this).apply {
                    text = em
                    textSize = 19f
                    setPadding(dp(10), 0, dp(10), 0)
                    setOnClickListener {
                        performFeedback()
                        ic.commitText(em, 1)
                    }
                }
                row.addView(tv)
            }
            scroll.addView(row)
            suggestionStrip.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // 2. Real-Time Translation + Grammar Fix Banner
        if (!KeyboardPrefs.isTranslateOn(this) || before.trim().length < 2) {
            translateJob?.cancel()
            translateBanner.visibility = View.GONE
            lastTranslatedResult = ""
            lastTranslatedSource = ""
            return
        }

        val sentence = before.substringAfterLast('\n').trim()
        if (sentence.length < 2) {
            translateBanner.visibility = View.GONE
            return
        }
        if (sentence == lastTranslatedSource && lastTranslatedResult.isNotBlank()) {
            translatePreviewText.text = lastTranslatedResult
            translateBanner.visibility = View.VISIBLE
            return
        }

        translateJob?.cancel()
        translateJob = serviceScope.launch {
            delay(450)
            val targetCode = KeyboardPrefs.getTargetLangCode(this@SmartKeyboardService)
            val targetName = KeyboardPrefs.getTargetLangName(this@SmartKeyboardService)
            val grammarOn = KeyboardPrefs.isGrammarFixOn(this@SmartKeyboardService)

            val result = withContext(Dispatchers.IO) {
                RealTimeTranslator.translateAndPolish(
                    this@SmartKeyboardService,
                    sentence,
                    targetCode,
                    targetName,
                    grammarOn
                )
            }
            if (!result.isNullOrBlank()) {
                lastTranslatedSource = sentence
                lastTranslatedResult = result
                translatePreviewText.text = result
                translateBanner.visibility = View.VISIBLE
            }
        }
    }

    private fun applyTranslatedText() {
        val ic = currentInputConnection ?: return
        if (lastTranslatedResult.isBlank()) return
        val before = ic.getTextBeforeCursor(300, 0)?.toString() ?: ""
        val currentLine = before.substringAfterLast('\n')
        if (currentLine.isNotEmpty()) {
            ic.deleteSurroundingText(currentLine.length, 0)
        }
        ic.commitText(lastTranslatedResult, 1)
        translateBanner.visibility = View.GONE
        lastTranslatedSource = ""
        lastTranslatedResult = ""
        refreshSuggestionsAndTranslate()
    }

    private fun buildMenuGridPanel() {
        val t = theme()
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(14))
        }
        val items = listOf(
            Triple("🌐", "Languages") { panelMode = PanelMode.TARGET_LANG; rebuildPanel() },
            Triple("🎨", "Themes") { panelMode = PanelMode.THEMES; rebuildPanel() },
            Triple("Aa", "Font") { panelMode = PanelMode.FONT; rebuildPanel() },
            Triple("123", "Number Row") {
                KeyboardPrefs.setNumberRow(this, !KeyboardPrefs.isNumberRow(this))
                panelMode = PanelMode.QWERTY
                rebuildPanel()
            },
            Triple("↔️", "Text Editing") { panelMode = PanelMode.TEXT_EDIT; rebuildPanel() },
            Triple("📋", "Clipboard") { panelMode = PanelMode.CLIPBOARD; rebuildPanel() },
            Triple("🔊", "Sound & Vib") { panelMode = PanelMode.SOUND_VIB; rebuildPanel() },
            Triple("↕️", "Size") { panelMode = PanelMode.SIZE; rebuildPanel() },
            Triple("#+=", "Symbols") { panelMode = PanelMode.SYMBOLS_1; rebuildPanel() },
            Triple("⚙", "Settings") { openSettings() }
        )

        for (rowIdx in 0..1) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            for (colIdx in 0..4) {
                val (icon, title, action) = items[rowIdx * 5 + colIdx]
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = roundedBg(t.keyBg, 10)
                    setPadding(dp(4), dp(12), dp(4), dp(12))
                    setOnClickListener {
                        performFeedback()
                        action()
                    }
                }
                cell.addView(TextView(this).apply {
                    text = icon
                    textSize = 20f
                    gravity = Gravity.CENTER
                    setTextColor(t.text)
                })
                cell.addView(TextView(this).apply {
                    text = title
                    textSize = 11f
                    gravity = Gravity.CENTER
                    setTextColor(t.subText)
                    setPadding(0, dp(4), 0, 0)
                })
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                })
            }
            grid.addView(row)
        }
        panelHost.addView(grid)
    }

    private fun buildEmojiPanel() {
        val t = theme()
        val categories = linkedMapOf(
            "Smileys" to listOf("😀","😃","😄","😁","😆","😅","🤣","😂","🙂","🙃","😉","😊","😇","🥰","😍","🤩","😘","😗","😚","😋","😛","😜","🤪","😝","🤑","🤗","🤭","🤫","🤔","🤐","😐","😑","😶","😏","😒","🙄","😬","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤢","🤮","🥵","🥶","🥴","😵","🤯","🤠","🥳","😎","🤓","🧐","😕","😟","🙁","😮","😯","😲","😳","🥺","😦","😧","😨","😰","😥","😢","😭","😱","😖","😣","😞","😓","😩","😫","😤","😡","😠","🤬"),
            "Hands" to listOf("👍","👎","👌","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","👇","☝️","✋","🤚","🖐️","🖖","👋","🤝","🙏","✍️","💪","👏","🙌","🫶"),
            "Hearts" to listOf("❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","🔥","✨","⭐","🌟","💯","🎉","🎊"),
            "Kaomoji" to listOf("( ͡° ͜ʖ ͡°)", "¯\\_(ツ)_/¯", "(╯°□°)╯︵ ┻━┻", "┬─┬ノ( º _ ºノ)", "(づ｡◕‿‿◕｡)づ", "(♥ω♥*)", "(ಥ﹏ಥ)", "(ง •̀_•́)ง", "ಠ_ಠ", "(¬‿¬)")
        )

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240))
        }
        val tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(t.barBg)
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val scroll = ScrollView(this)
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        scroll.addView(grid)

        fun loadCategory(cat: String) {
            grid.removeAllViews()
            val list = categories[cat].orEmpty()
            val cols = if (cat == "Kaomoji") 2 else 7
            var i = 0
            while (i < list.size) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (c in 0 until cols) {
                    val item = list.getOrNull(i + c)
                    val tv = TextView(this).apply {
                        text = item ?: ""
                        textSize = if (cat == "Kaomoji") 14f else 24f
                        gravity = Gravity.CENTER
                        setTextColor(t.text)
                        setPadding(0, dp(8), 0, dp(8))
                        if (item != null) {
                            setOnClickListener {
                                performFeedback()
                                currentInputConnection?.commitText(item, 1)
                            }
                        }
                    }
                    r.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
                grid.addView(r)
                i += cols
            }
        }

        tabBar.addView(TextView(this).apply {
            text = "ABC"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.accent)
            setPadding(dp(8), dp(4), dp(12), dp(4))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })
        for (cat in categories.keys) {
            tabBar.addView(TextView(this).apply {
                text = cat
                textSize = 12f
                setTextColor(t.text)
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { loadCategory(cat) }
            })
        }
        tabBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        tabBar.addView(TextView(this).apply {
            text = "⌫"
            textSize = 17f
            setTextColor(t.text)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { deleteOneChar() }
        })

        loadCategory("Smileys")
        outer.addView(tabBar)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        panelHost.addView(outer)
    }

    private fun buildClipboardPanel() {
        val t = theme()
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240))
            setPadding(dp(10), dp(6), dp(10), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "← Clipboard"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })
        outer.addView(header)

        val scroll = ScrollView(this)
        val listCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val clips = KeyboardPrefs.getClips(this)
        if (clips.isEmpty()) {
            listCol.addView(TextView(this).apply {
                text = "Copy any text — it will appear here."
                textSize = 13f
                setTextColor(t.subText)
                setPadding(dp(6), dp(24), dp(6), dp(24))
                gravity = Gravity.CENTER
            })
        } else {
            for (clip in clips) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = roundedBg(t.keyBg, 8)
                    setPadding(dp(10), dp(8), dp(8), dp(8))
                }
                row.addView(TextView(this).apply {
                    text = clip.text
                    textSize = 13f
                    setTextColor(t.text)
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setOnClickListener {
                        performFeedback()
                        currentInputConnection?.commitText(clip.text, 1)
                    }
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(TextView(this).apply {
                    text = if (clip.pinned) "📌" else "📍"
                    textSize = 15f
                    setPadding(dp(8), dp(2), dp(6), dp(2))
                    setOnClickListener {
                        KeyboardPrefs.togglePinClip(this@SmartKeyboardService, clip.text)
                        rebuildPanel()
                    }
                })
                row.addView(TextView(this).apply {
                    text = "🗑"
                    textSize = 15f
                    setPadding(dp(6), dp(2), dp(4), dp(2))
                    setOnClickListener {
                        KeyboardPrefs.deleteClip(this@SmartKeyboardService, clip.text)
                        rebuildPanel()
                    }
                })
                listCol.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(6)
                })
            }
        }
        scroll.addView(listCol)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        panelHost.addView(outer)
    }

    private fun buildTextEditPanel() {
        val t = theme()
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230))
            setPadding(dp(10), dp(6), dp(10), dp(10))
        }
        outer.addView(TextView(this).apply {
            text = "← Text Editing"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(6))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Left column: Select All / Copy
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        leftCol.addView(editActionBtn("SELECT ALL") { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) })
        leftCol.addView(editActionBtn("COPY") { currentInputConnection?.performContextMenuAction(android.R.id.copy) })
        body.addView(leftCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // Center D-Pad
        val dpad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        dpad.addView(editActionBtn("▲") { sendDpad(KeyEvent.KEYCODE_DPAD_UP) })
        val midRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        midRow.addView(editActionBtn("◀") { sendDpad(KeyEvent.KEYCODE_DPAD_LEFT) })
        midRow.addView(editActionBtn(if (isSelectingText) "SEL ON" else "SELECT", active = isSelectingText) {
            isSelectingText = !isSelectingText
            rebuildPanel()
        })
        midRow.addView(editActionBtn("▶") { sendDpad(KeyEvent.KEYCODE_DPAD_RIGHT) })
        dpad.addView(midRow)
        dpad.addView(editActionBtn("▼") { sendDpad(KeyEvent.KEYCODE_DPAD_DOWN) })
        body.addView(dpad, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.8f))

        // Right column: Paste / Delete
        val rightCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rightCol.addView(editActionBtn("PASTE") { currentInputConnection?.performContextMenuAction(android.R.id.paste) })
        rightCol.addView(editActionBtn("DELETE") { deleteOneChar() })
        body.addView(rightCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        outer.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        panelHost.addView(outer)
    }

    private fun editActionBtn(label: String, active: Boolean = false, onClick: () -> Unit): TextView {
        val t = theme()
        return TextView(this).apply {
            text = label
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (active) Color.WHITE else t.text)
            background = roundedBg(if (active) t.accent else t.keyBg, 8)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            setOnClickListener {
                performFeedback()
                onClick()
            }
        }
    }

    private fun sendDpad(keyCode: Int) {
        val ic = currentInputConnection ?: return
        if (isSelectingText) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_SHIFT_LEFT))
        }
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        if (isSelectingText) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_SHIFT_LEFT))
        }
    }

    private fun buildThemesPanel() {
        val t = theme()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(14))
        }
        col.addView(TextView(this).apply {
            text = "← Themes"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(10))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val activeIdx = KeyboardPrefs.getThemeIndex(this)
        themes.forEachIndexed { idx, th ->
            val card = TextView(this).apply {
                text = if (idx == activeIdx) "✓\n${th.name}" else th.name
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(th.text)
                background = roundedBg(th.keyBg, 10, if (idx == activeIdx) th.accent else 0, 2)
                setPadding(dp(6), dp(16), dp(6), dp(16))
                setOnClickListener {
                    KeyboardPrefs.setThemeIndex(this@SmartKeyboardService, idx)
                    buildRootUi()
                }
            }
            row.addView(card, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        col.addView(row)
        panelHost.addView(col)
    }

    private fun buildFontPanel() {
        val t = theme()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(14))
        }
        col.addView(TextView(this).apply {
            text = "← Font Style"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(10))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val active = KeyboardPrefs.getFontStyle(this)
        FontStyler.styleNames.forEachIndexed { idx, name ->
            val card = TextView(this).apply {
                text = FontStyler.apply(name, idx)
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (idx == active) Color.WHITE else t.text)
                background = roundedBg(if (idx == active) t.accent else t.keyBg, 10)
                setPadding(dp(6), dp(14), dp(6), dp(14))
                setOnClickListener {
                    KeyboardPrefs.setFontStyle(this@SmartKeyboardService, idx)
                    panelMode = PanelMode.QWERTY
                    rebuildPanel()
                }
            }
            row.addView(card, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        col.addView(row)
        panelHost.addView(col)
    }

    private fun buildSoundVibPanel() {
        val t = theme()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(14))
        }
        col.addView(TextView(this).apply {
            text = "← Sound & Vibration"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(8))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })

        val soundSwitch = Switch(this).apply {
            text = "Keypress Sound"
            setTextColor(t.text)
            isChecked = KeyboardPrefs.isSoundOn(this@SmartKeyboardService)
            setOnCheckedChangeListener { _, checked -> KeyboardPrefs.setSoundOn(this@SmartKeyboardService, checked) }
        }
        col.addView(soundSwitch)

        val vibSwitch = Switch(this).apply {
            text = "Keypress Vibration"
            setTextColor(t.text)
            isChecked = KeyboardPrefs.isVibrateOn(this@SmartKeyboardService)
            setOnCheckedChangeListener { _, checked -> KeyboardPrefs.setVibrateOn(this@SmartKeyboardService, checked) }
        }
        col.addView(vibSwitch)

        col.addView(TextView(this).apply {
            text = "Vibration Duration (${KeyboardPrefs.getVibrateMs(this@SmartKeyboardService)} ms)"
            textSize = 12f
            setTextColor(t.subText)
            setPadding(0, dp(8), 0, dp(4))
        })
        col.addView(SeekBar(this).apply {
            max = 50
            progress = KeyboardPrefs.getVibrateMs(this@SmartKeyboardService)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) KeyboardPrefs.setVibrateMs(this@SmartKeyboardService, p)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        panelHost.addView(col)
    }

    private fun buildSizePanel() {
        val t = theme()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(16))
        }
        val title = TextView(this).apply {
            text = "← Keyboard Height (${KeyboardPrefs.getHeightPercent(this@SmartKeyboardService)}%)"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(12))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        }
        col.addView(title)
        col.addView(SeekBar(this).apply {
            max = 45
            progress = KeyboardPrefs.getHeightPercent(this@SmartKeyboardService) - 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val pct = 80 + p
                        KeyboardPrefs.setHeightPercent(this@SmartKeyboardService, pct)
                        title.text = "← Keyboard Height ($pct%)"
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        panelHost.addView(col)
    }

    private fun buildTargetLangPanel() {
        val t = theme()
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        outer.addView(TextView(this).apply {
            text = "← Translate Target Language"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(t.text)
            setPadding(0, 0, 0, dp(6))
            setOnClickListener { panelMode = PanelMode.QWERTY; rebuildPanel() }
        })
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val activeCode = KeyboardPrefs.getTargetLangCode(this)
        for (lang in KeyboardPrefs.supportedLanguages) {
            val isSel = lang.code == activeCode
            col.addView(TextView(this).apply {
                text = if (isSel) "✓  ${lang.name} (${lang.nativeLabel})" else "${lang.name} (${lang.nativeLabel})"
                textSize = 14f
                setTextColor(if (isSel) Color.WHITE else t.text)
                background = roundedBg(if (isSel) t.accent else t.keyBg, 8)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(4)
                }
                setOnClickListener {
                    KeyboardPrefs.setTargetLangCode(this@SmartKeyboardService, lang.code)
                    KeyboardPrefs.setTranslateOn(this@SmartKeyboardService, true)
                    panelMode = PanelMode.QWERTY
                    buildRootUi()
                }
            })
        }
        scroll.addView(col)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        panelHost.addView(outer)
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private fun performFeedback() {
        if (KeyboardPrefs.isVibrateOn(this)) {
            val ms = KeyboardPrefs.getVibrateMs(this).toLong()
            if (ms > 0) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                        vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            @Suppress("DEPRECATION")
                            v.vibrate(ms)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
        if (KeyboardPrefs.isSoundOn(this)) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.playSoundEffect(AudioManager.FX_KEY_CLICK, KeyboardPrefs.getSoundVolume(this) / 100f)
            } catch (_: Exception) {}
        }
    }
}
