package com.tvplayer.app.data.parser

import android.util.Xml
import com.tvplayer.app.data.model.EpgProgramEntity
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.GZIPInputStream

object XmltvParser {
    private val dateFormats = listOf(
        "yyyyMMddHHmmss Z",
        "yyyyMMddHHmmssZ",
        "yyyyMMddHHmmss"
    )

    suspend fun parseStreaming(
        rawStream: InputStream,
        storeDescriptions: Boolean,
        onBatch: suspend (List<EpgProgramEntity>) -> Unit
    ) {
        val buffered = BufferedInputStream(rawStream, 65536)
        buffered.mark(4)
        val b0 = buffered.read()
        val b1 = buffered.read()
        buffered.reset()
        val isGzip = (b0 == 0x1f && b1 == 0x8b)
        val input: InputStream = if (isGzip) GZIPInputStream(buffered) else buffered

        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(input, "UTF-8")

        val batch = ArrayList<EpgProgramEntity>(1000)
        var eventType = parser.eventType

        var inProgramme = false
        var channelId = ""
        var startMs = 0L
        var endMs = 0L
        var title = ""
        var desc = ""
        var category = ""
        var currentTag = ""

        val nowMs = System.currentTimeMillis()
        val minKeepMs = nowMs - 7L * 24 * 3600 * 1000L
        val maxKeepMs = nowMs + 7L * 24 * 3600 * 1000L

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name?.lowercase() ?: ""
                    currentTag = tag
                    if (tag == "programme") {
                        inProgramme = true
                        channelId = parser.getAttributeValue(null, "channel") ?: ""
                        startMs = parseXmltvDate(parser.getAttributeValue(null, "start"))
                        endMs = parseXmltvDate(parser.getAttributeValue(null, "stop"))
                        title = ""
                        desc = ""
                        category = ""
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inProgramme) {
                        val txt = parser.text?.trim().orEmpty()
                        if (txt.isNotEmpty()) {
                            when (currentTag) {
                                "title" -> if (title.isEmpty()) title = txt
                                "desc" -> if (storeDescriptions && desc.isEmpty()) desc = txt
                                "category" -> if (category.isEmpty()) category = txt
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tag = parser.name?.lowercase() ?: ""
                    if (tag == "programme" && inProgramme) {
                        inProgramme = false
                        if (channelId.isNotBlank() && title.isNotBlank() && startMs > 0L && endMs > startMs) {
                            if (endMs >= minKeepMs && startMs <= maxKeepMs) {
                                batch.add(
                                    EpgProgramEntity(
                                        channelTvgId = channelId,
                                        title = title,
                                        description = desc,
                                        startTimeMs = startMs,
                                        endTimeMs = endMs,
                                        category = category
                                    )
                                )
                                if (batch.size >= 1000) {
                                    onBatch(batch.toList())
                                    batch.clear()
                                }
                            }
                        }
                    }
                    currentTag = ""
                }
            }
            eventType = parser.next()
        }
        if (batch.isNotEmpty()) {
            onBatch(batch.toList())
            batch.clear()
        }
    }

    private fun parseXmltvDate(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        val cleaned = raw.trim()
        for (fmt in dateFormats) {
            try {
                val sdf = SimpleDateFormat(fmt, Locale.US)
                if (!fmt.contains("Z")) sdf.timeZone = TimeZone.getTimeZone("UTC")
                val d = sdf.parse(cleaned)
                if (d != null) return d.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }
}
