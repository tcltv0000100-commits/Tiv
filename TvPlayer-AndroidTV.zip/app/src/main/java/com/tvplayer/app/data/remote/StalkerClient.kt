package com.tvplayer.app.data.remote

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.tvplayer.app.data.model.EpgProgramEntity
import com.tvplayer.app.data.model.SeriesEpisode
import com.tvplayer.app.data.model.SeriesSeason
import com.tvplayer.app.data.network.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class StalkerIdentity(
    val mac: String,
    val sn: String,
    val deviceId1: String,
    val deviceId2: String,
    val signature: String
)

data class StalkerSession(
    val portalBase: String,
    val portalPath: String,
    val token: String,
    val random: String,
    val identity: StalkerIdentity
)

data class StalkerCategory(val id: String, val title: String)

data class StalkerChannel(
    val id: String,
    val number: Int,
    val name: String,
    val cmd: String,
    val logo: String,
    val genreId: String
)

data class StalkerVodItem(
    val id: String,
    val title: String,
    val cmd: String,
    val categoryId: String,
    val poster: String,
    val description: String,
    val actors: String,
    val director: String,
    val year: String,
    val duration: String,
    val rating: String,
    val isSeries: Boolean,
    val seriesEpisodesArray: List<Int>
)

class StalkerClient {
    private val client = HttpClientProvider.client
    private val sessionCache = ConcurrentHashMap<String, StalkerSession>()

    private val candidatePaths = listOf(
        "portal.php",
        "stalker_portal/server/load.php",
        "server/load.php",
        "c/portal.php",
        "ministra/portal.php",
        "client/portal.php",
        "portalstb/portal.php",
        "magportal/portal.php"
    )

    fun generateIdentity(
        rawMac: String,
        customSn: String = "",
        customD1: String = "",
        customD2: String = ""
    ): StalkerIdentity {
        val mac = rawMac.trim().uppercase()
        val sn = customSn.ifBlank { md5(mac).uppercase().take(13) }
        val d1 = customD1.ifBlank { sha256(mac).uppercase() }
        // User requirement: D2 must equal D1
        val d2 = customD2.ifBlank { d1 }
        val sig = sha256("$sn$mac").uppercase()
        return StalkerIdentity(mac, sn, d1, d2, sig)
    }

    private fun md5(input: String): String =
        MessageDigest.getInstance("MD5").digest(input.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun sha256(input: String): String =
        MessageDigest.getInstance("SHA-256").digest(input.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun normalizeBase(server: String): String {
        var s = server.trim().removeSuffix("/")
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        s = s.removeSuffix("/c")
        return s
    }

    private fun buildHeaders(sessionBase: String, identity: StalkerIdentity, token: String?): Map<String, String> {
        val encodedMac = URLEncoder.encode(identity.mac, "UTF-8")
        val refererBase = if (sessionBase.contains("stalker_portal")) sessionBase else "$sessionBase/c/"
        val map = mutableMapOf(
            "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent" to "Model: MAG254; Link: Ethernet",
            "Referer" to refererBase,
            "Accept" to "application/json,application/javascript,text/javascript,*/*",
            "Cookie" to "mac=$encodedMac; stb_lang=en; timezone=UTC;",
            "Connection" to "Keep-Alive"
        )
        if (!token.isNullOrBlank()) {
            map["Authorization"] = "Bearer $token"
        }
        return map
    }

    private suspend fun executeGet(url: String, headers: Map<String, String>): String? = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        client.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext null
            resp.body?.string()
        }
    }

    suspend fun connect(
        server: String,
        mac: String,
        preferredPath: String = "",
        customSn: String = "",
        customD1: String = "",
        customD2: String = ""
    ): StalkerSession? {
        val base = normalizeBase(server)
        val identity = generateIdentity(mac, customSn, customD1, customD2)
        val pathsToTry = if (preferredPath.isNotBlank()) {
            listOf(preferredPath) + candidatePaths.filter { it != preferredPath }
        } else {
            candidatePaths
        }

        for (path in pathsToTry) {
            val cleanPath = path.removePrefix("/")
            val handshakeUrl = "$base/$cleanPath?type=stb&action=handshake&token=&prehash=false&JsHttpRequest=1-xml"
            val raw = try {
                executeGet(handshakeUrl, buildHeaders(base, identity, null))
            } catch (_: Exception) {
                null
            } ?: continue

            val parsed = try {
                JsonParser.parseString(raw).asJsonObject
            } catch (_: Exception) {
                null
            } ?: continue

            val js = parsed.getAsJsonObject("js") ?: continue
            val token = js.get("token")?.asString ?: continue
            if (token.isBlank()) continue
            val random = js.get("random")?.asString ?: ""

            val session = StalkerSession(base, cleanPath, token, random, identity)
            // Step 2: Authentic get_profile handshake
            authenticateProfile(session)
            sessionCache["$base|${identity.mac}"] = session
            return session
        }
        return null
    }

    private suspend fun authenticateProfile(session: StalkerSession) {
        val id = session.identity
        val encMac = URLEncoder.encode(id.mac, "UTF-8")
        val metrics = URLEncoder.encode(
            """{"mac":"${id.mac}","sn":"${id.sn}","model":"MAG254","type":"STB","uid":"${id.deviceId1}","random":"${session.random}"}""",
            "UTF-8"
        )
        val ts = System.currentTimeMillis() / 1000L
        val profileUrl = "${session.portalBase}/${session.portalPath}?type=stb&action=get_profile&hd=1" +
            "&sn=${id.sn}&stb_type=MAG254&client_type=STB&image_version=218&video_out=hdmi" +
            "&device_id=${id.deviceId1}&device_id2=${id.deviceId2}&signature=${id.signature}" +
            "&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&metrics=$metrics" +
            "&timestamp=$ts&JsHttpRequest=1-xml"
        try {
            executeGet(profileUrl, buildHeaders(session.portalBase, id, session.token))
        } catch (_: Exception) {
        }
    }

    private suspend fun getWithAutoRefresh(session: StalkerSession, query: String): JsonObject? {
        val url = "${session.portalBase}/${session.portalPath}?$query"
        var raw = try {
            executeGet(url, buildHeaders(session.portalBase, session.identity, session.token))
        } catch (_: Exception) {
            null
        }
        if (raw == null || raw.contains("Authorization failed", true)) {
            val refreshed = connect(
                session.portalBase,
                session.identity.mac,
                session.portalPath,
                session.identity.sn,
                session.identity.deviceId1,
                session.identity.deviceId2
            ) ?: return null
            val retryUrl = "${refreshed.portalBase}/${refreshed.portalPath}?$query"
            raw = try {
                executeGet(retryUrl, buildHeaders(refreshed.portalBase, refreshed.identity, refreshed.token))
            } catch (_: Exception) {
                null
            }
        }
        if (raw.isNullOrBlank()) return null
        return try {
            JsonParser.parseString(raw).asJsonObject
        } catch (_: Exception) {
            null
        }
    }

    suspend fun getGenres(session: StalkerSession, type: String = "itv"): List<StalkerCategory> {
        val action = if (type == "itv") "get_genres" else "get_categories"
        val obj = getWithAutoRefresh(session, "type=$type&action=$action&JsHttpRequest=1-xml") ?: return emptyList()
        val js = obj.get("js") ?: return emptyList()
        if (!js.isJsonArray) return emptyList()
        return js.asJsonArray.mapNotNull { el ->
            val o = el.asJsonObject
            val id = o.get("id")?.asString ?: return@mapNotNull null
            val title = o.get("title")?.asString ?: "General"
            if (id == "*") return@mapNotNull null
            StalkerCategory(id, title)
        }
    }

    suspend fun getAllChannels(session: StalkerSession): List<StalkerChannel> {
        val obj = getWithAutoRefresh(session, "type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=1-xml")
            ?: return emptyList()
        val js = obj.getAsJsonObject("js") ?: return emptyList()
        val data = js.getAsJsonArray("data") ?: return emptyList()
        return data.mapIndexedNotNull { idx, el ->
            val o = el.asJsonObject
            val id = o.get("id")?.asString ?: return@mapIndexedNotNull null
            StalkerChannel(
                id = id,
                number = o.get("number")?.asString?.toIntOrNull() ?: (idx + 1),
                name = o.get("name")?.asString ?: "Channel $id",
                cmd = o.get("cmd")?.asString ?: "",
                logo = normalizeLogo(session.portalBase, o.get("logo")?.asString ?: ""),
                genreId = o.get("tv_genre_id")?.asString ?: ""
            )
        }
    }

    suspend fun getOrderedList(
        session: StalkerSession,
        type: String,
        categoryId: String = "*",
        maxPages: Int = 5
    ): List<StalkerVodItem> {
        val items = mutableListOf<StalkerVodItem>()
        for (page in 1..maxPages) {
            val catEnc = URLEncoder.encode(categoryId, "UTF-8")
            val obj = getWithAutoRefresh(
                session,
                "type=$type&action=get_ordered_list&category=$catEnc&p=$page&sortby=added&JsHttpRequest=1-xml"
            ) ?: break
            val js = obj.getAsJsonObject("js") ?: break
            val data = js.getAsJsonArray("data") ?: break
            if (data.size() == 0) break

            data.forEach { el ->
                val o = el.asJsonObject
                val id = o.get("id")?.asString ?: return@forEach
                val epArr = mutableListOf<Int>()
                if (o.has("series") && o.get("series").isJsonArray) {
                    o.getAsJsonArray("series").forEach { n ->
                        n.asInt.let { epArr.add(it) }
                    }
                }
                items.add(
                    StalkerVodItem(
                        id = id,
                        title = o.get("name")?.asString ?: "Title $id",
                        cmd = o.get("cmd")?.asString ?: "",
                        categoryId = o.get("category_id")?.asString ?: categoryId,
                        poster = normalizeLogo(session.portalBase, o.get("screenshot_uri")?.asString ?: ""),
                        description = o.get("description")?.asString ?: "",
                        actors = o.get("actors")?.asString ?: "",
                        director = o.get("director")?.asString ?: "",
                        year = o.get("year")?.asString ?: "",
                        duration = o.get("time")?.asString ?: "",
                        rating = o.get("rating_imdb")?.asString ?: "",
                        isSeries = type == "series" || epArr.isNotEmpty() || (o.get("is_series")?.asInt == 1),
                        seriesEpisodesArray = epArr
                    )
                )
            }
            val totalItems = js.get("total_items")?.asInt ?: 0
            if (items.size >= totalItems) break
        }
        return items
    }

    suspend fun getSeriesSeasonsAndEpisodes(
        session: StalkerSession,
        seriesId: String,
        fallbackCmd: String = ""
    ): List<SeriesSeason> {
        // Variant A: Nested seasons via movie_id & season_id=0
        val obj = getWithAutoRefresh(
            session,
            "type=series&action=get_ordered_list&movie_id=$seriesId&season_id=0&p=1&JsHttpRequest=1-xml"
        )
        val js = obj?.getAsJsonObject("js")
        val data = js?.getAsJsonArray("data")
        if (data != null && data.size() > 0) {
            val seasons = mutableListOf<SeriesSeason>()
            data.forEachIndexed { idx, el ->
                val o = el.asJsonObject
                val seasonId = o.get("id")?.asString ?: "${idx + 1}"
                val seasonName = o.get("name")?.asString ?: "Season ${idx + 1}"
                val epObj = getWithAutoRefresh(
                    session,
                    "type=series&action=get_ordered_list&movie_id=$seriesId&season_id=$seasonId&p=1&JsHttpRequest=1-xml"
                )
                val epData = epObj?.getAsJsonObject("js")?.getAsJsonArray("data")
                val episodes = mutableListOf<SeriesEpisode>()
                epData?.forEachIndexed { eIdx, eEl ->
                    val eo = eEl.asJsonObject
                    val epNum = eo.get("episode_number")?.asInt ?: (eIdx + 1)
                    episodes.add(
                        SeriesEpisode(
                            id = eo.get("id")?.asString ?: "$epNum",
                            episodeNumber = epNum,
                            title = eo.get("name")?.asString ?: "Episode $epNum",
                            cmd = eo.get("cmd")?.asString ?: fallbackCmd,
                            thumbnailUrl = normalizeLogo(session.portalBase, eo.get("screenshot_uri")?.asString ?: "")
                        )
                    )
                }
                if (episodes.isNotEmpty()) {
                    seasons.add(SeriesSeason(idx + 1, seasonId, seasonName, episodes))
                }
            }
            if (seasons.isNotEmpty()) return seasons
        }
        return emptyList()
    }

    suspend fun createLink(
        session: StalkerSession,
        type: String,
        cmd: String,
        seriesEpisode: String = ""
    ): String? {
        val encCmd = URLEncoder.encode(cmd, "UTF-8")
        val query = "type=$type&action=create_link&cmd=$encCmd&series=$seriesEpisode&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
        val obj = getWithAutoRefresh(session, query) ?: return null
        val js = obj.getAsJsonObject("js") ?: return null
        val rawCmd = js.get("cmd")?.asString ?: return null
        return stripCommandPrefix(rawCmd)
    }

    suspend fun getShortEpg(session: StalkerSession, channelId: String, size: Int = 10): List<EpgProgramEntity> {
        val obj = getWithAutoRefresh(session, "type=itv&action=get_short_epg&ch_id=$channelId&size=$size&JsHttpRequest=1-xml")
            ?: return emptyList()
        val js = obj.get("js") ?: return emptyList()
        if (!js.isJsonArray) return emptyList()
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return js.asJsonArray.mapNotNull { el ->
            val o = el.asJsonObject
            val title = o.get("name")?.asString ?: return@mapNotNull null
            val startStr = o.get("time")?.asString ?: return@mapNotNull null
            val stopStr = o.get("time_to")?.asString ?: return@mapNotNull null
            val startMs = try { sdf.parse(startStr)?.time ?: 0L } catch (_: Exception) { 0L }
            val endMs = try { sdf.parse(stopStr)?.time ?: 0L } catch (_: Exception) { 0L }
            if (startMs == 0L || endMs <= startMs) return@mapNotNull null
            EpgProgramEntity(
                channelTvgId = "stalker_$channelId",
                title = title,
                description = o.get("descr")?.asString ?: "",
                startTimeMs = startMs,
                endTimeMs = endMs,
                category = o.get("category")?.asString ?: ""
            )
        }
    }

    private fun stripCommandPrefix(raw: String): String {
        val cleaned = raw.replace("\\/", "/").trim()
        val prefixes = listOf("ffmpeg ", "ffrt ", "ffrt2 ", "ffrt3 ", "auto ")
        for (p in prefixes) {
            if (cleaned.startsWith(p, ignoreCase = true)) {
                return cleaned.substring(p.length).trim()
            }
        }
        return cleaned
    }

    private fun normalizeLogo(base: String, logo: String): String {
        if (logo.isBlank()) return ""
        if (logo.startsWith("http://") || logo.startsWith("https://")) return logo
        return "$base/${logo.removePrefix("/")}"
    }
}
