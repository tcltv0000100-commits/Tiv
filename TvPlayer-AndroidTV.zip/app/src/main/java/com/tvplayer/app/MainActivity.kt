package com.tvplayer.app

import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewModelScope
import com.tvplayer.app.ui.screens.*
import com.tvplayer.app.ui.theme.TvPalette
import com.tvplayer.app.ui.theme.TvPlayerTheme
import com.tvplayer.app.ui.viewmodel.MainViewModel
import com.tvplayer.app.ui.viewmodel.NavSection
import com.tvplayer.app.ui.viewmodel.RightDrawerType
import com.tvplayer.app.ui.viewmodel.WizardStep
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var lastBackPressMs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = ActivityInfo.COLOR_MODE_HDR
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    vm.rightDrawer.value != RightDrawerType.NONE -> vm.openDrawer(RightDrawerType.NONE)
                    vm.wizardStep.value != WizardStep.NONE -> vm.openWizard(WizardStep.NONE)
                    vm.showQuickChannelOverlay.value -> vm.toggleQuickChannelOverlay()
                    vm.isFullscreenPlayer.value -> vm.exitFullscreenToGuide()
                    vm.selectedVodDetail.value != null -> vm.closeVodDetail()
                    vm.settings.value.confirmExitOnBack -> {
                        val now = System.currentTimeMillis()
                        if (now - lastBackPressMs < 2000L) finish()
                        else {
                            lastBackPressMs = now
                            Toast.makeText(this@MainActivity, "Press Back again to exit", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else -> finish()
                }
            }
        })

        setContent {
            val settings by vm.settings.collectAsState()
            val playlists by vm.playlists.collectAsState()
            val section by vm.currentSection.collectAsState()
            val wizardStep by vm.wizardStep.collectAsState()
            val syncProgress by vm.syncProgress.collectAsState()
            val rightDrawer by vm.rightDrawer.collectAsState()
            val isFullscreen by vm.isFullscreenPlayer.collectAsState()
            val showQuickChannels by vm.showQuickChannelOverlay.collectAsState()
            val activePlayback by vm.activePlayback.collectAsState()
            val activeChannel by vm.activeChannel.collectAsState()
            val selectedVod by vm.selectedVodDetail.collectAsState()
            val seriesSeasons by vm.seriesSeasons.collectAsState()
            val loadingSeries by vm.loadingSeries.collectAsState()
            val epgMap by vm.epgMap.collectAsState()

            val channels by vm.displayedChannels.collectAsState()
            val movies by vm.displayedMovies.collectAsState()
            val shows by vm.displayedShows.collectAsState()
            val liveGroups by vm.liveGroups.collectAsState()
            val movieGroups by vm.movieGroups.collectAsState()
            val showGroups by vm.showGroups.collectAsState()
            val selectedGroupId by vm.selectedGroupId.collectAsState()
            val selectedPlaylistId by vm.selectedPlaylistFilterId.collectAsState()
            val history by vm.channelHistory.collectAsState()
            val searchQuery by vm.searchQuery.collectAsState()
            val searchResults by vm.searchResults.collectAsState()

            var railExpanded by remember { mutableStateOf(false) }

            TvPlayerTheme(fontScale = settings.fontSizeScale, accentHex = settings.accentColorHex) {
                Box(modifier = Modifier.fillMaxSize().background(TvPalette.Background)) {
                    when {
                        !settings.termsAccepted -> {
                            TermsOfUseOverlay(
                                onAccept = { vm.acceptTerms() },
                                onDecline = { finish() }
                            )
                        }

                        wizardStep != WizardStep.NONE -> {
                            AddPlaylistWizardOverlay(
                                step = wizardStep,
                                syncProgress = syncProgress,
                                onSelectStep = { vm.openWizard(it) },
                                onSubmitM3u = { n, u, e -> vm.submitM3u(n, u, e) },
                                onSubmitXtream = { n, s, u, p, tv, vod -> vm.submitXtream(n, s, u, p, tv, vod) },
                                onSubmitStalker = { n, s, m, tv, vod -> vm.submitStalker(n, s, m, tv, vod) },
                                onClose = { vm.openWizard(WizardStep.NONE) }
                            )
                        }

                        playlists.isEmpty() -> {
                            EmptyHomeScreen(
                                onAddPlaylist = { vm.openWizard(WizardStep.PLAYLIST_TYPE) },
                                onOpenSettings = { vm.openDrawer(RightDrawerType.SETTINGS) }
                            )
                        }

                        isFullscreen -> {
                            FullscreenPlayerScreen(
                                playback = activePlayback,
                                playerController = vm.playerController,
                                settings = settings,
                                channels = channels,
                                history = history,
                                showQuickChannels = showQuickChannels,
                                onToggleQuickChannels = { vm.toggleQuickChannelOverlay() },
                                onSelectChannel = { vm.playChannel(it, fullscreen = true) },
                                onOpenGuide = { vm.exitFullscreenToGuide() },
                                onOpenDrawer = { vm.openDrawer(it) },
                                onToggleHdrBoost = { vm.toggleHdrColorBoost() }
                            )
                        }

                        selectedVod != null -> {
                            VodDetailScreen(
                                vod = selectedVod!!,
                                seasons = seriesSeasons,
                                loadingSeries = loadingSeries,
                                onPlayMovie = { vm.playVod(selectedVod!!) },
                                onPlayEpisode = { ep -> vm.playVod(selectedVod!!, ep) },
                                onToggleMyList = { vm.viewModelScope.launch { vm.repo.toggleVodMyList(selectedVod!!) } },
                                onBack = { vm.closeVodDetail() }
                            )
                        }

                        else -> {
                            Row(modifier = Modifier.fillMaxSize()) {
                                LeftNavigationRail(
                                    currentSection = section,
                                    expanded = railExpanded,
                                    onToggleExpand = { railExpanded = it },
                                    onSelectSection = { vm.selectSection(it) }
                                )

                                when (section) {
                                    NavSection.TV -> {
                                        GroupSidebar(
                                            playlists = playlists,
                                            groups = liveGroups,
                                            selectedGroupId = selectedGroupId,
                                            selectedPlaylistId = selectedPlaylistId,
                                            allLabel = "All channels",
                                            myListLabel = "Favorites",
                                            onSelectGroup = { g, p -> vm.selectGroup(g, p) }
                                        )
                                        TvGuideScreen(
                                            channels = channels,
                                            activeChannel = activeChannel,
                                            epgMap = epgMap,
                                            settings = settings,
                                            player = vm.playerController.player,
                                            onChannelFocused = { ch ->
                                                if (activeChannel?.id != ch.id) {
                                                    vm.playChannel(ch, fullscreen = false)
                                                }
                                            },
                                            onChannelClicked = { ch -> vm.playChannel(ch, fullscreen = true) },
                                            onOpenContextMenu = { _ -> vm.openDrawer(RightDrawerType.SETTINGS) },
                                            onRequestEpgWindow = { vm.loadEpgWindow(it) }
                                        )
                                    }

                                    NavSection.MOVIES -> {
                                        GroupSidebar(
                                            playlists = playlists,
                                            groups = movieGroups,
                                            selectedGroupId = selectedGroupId,
                                            selectedPlaylistId = selectedPlaylistId,
                                            allLabel = "All movies",
                                            myListLabel = "My list",
                                            onSelectGroup = { g, p -> vm.selectGroup(g, p) }
                                        )
                                        VodCatalogScreen(
                                            items = movies,
                                            categoryTitle = "Movies",
                                            onSearchClick = { vm.selectSection(NavSection.SEARCH) },
                                            onSortClick = { vm.openDrawer(RightDrawerType.SORTING) },
                                            onItemClick = { vm.openVodDetail(it) }
                                        )
                                    }

                                    NavSection.SHOWS -> {
                                        GroupSidebar(
                                            playlists = playlists,
                                            groups = showGroups,
                                            selectedGroupId = selectedGroupId,
                                            selectedPlaylistId = selectedPlaylistId,
                                            allLabel = "All shows",
                                            myListLabel = "My list",
                                            onSelectGroup = { g, p -> vm.selectGroup(g, p) }
                                        )
                                        VodCatalogScreen(
                                            items = shows,
                                            categoryTitle = "Shows",
                                            onSearchClick = { vm.selectSection(NavSection.SEARCH) },
                                            onSortClick = { vm.openDrawer(RightDrawerType.SORTING) },
                                            onItemClick = { vm.openVodDetail(it) }
                                        )
                                    }

                                    NavSection.SEARCH -> {
                                        SearchScreen(
                                            query = searchQuery,
                                            results = searchResults,
                                            onQueryChange = { vm.updateSearch(it) },
                                            onChannelClick = { vm.playChannel(it, fullscreen = true) },
                                            onVodClick = { vm.openVodDetail(it) }
                                        )
                                    }

                                    NavSection.RECORDINGS -> {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            Text("No recordings", style = MaterialTheme.typography.bodyLarge, color = TvPalette.TextSecondary)
                                        }
                                    }

                                    NavSection.MY_LIST -> {
                                        VodCatalogScreen(
                                            items = movies.filter { it.isInMyList } + shows.filter { it.isInMyList },
                                            categoryTitle = "My list",
                                            onSearchClick = { vm.selectSection(NavSection.SEARCH) },
                                            onSortClick = { vm.openDrawer(RightDrawerType.SORTING) },
                                            onItemClick = { vm.openVodDetail(it) }
                                        )
                                    }

                                    NavSection.SETTINGS -> {
                                        Box(Modifier.fillMaxSize())
                                    }
                                }
                            }
                        }
                    }

                    RightSideDrawerHost(
                        drawerType = rightDrawer,
                        settings = settings,
                        playlists = playlists,
                        playerController = vm.playerController,
                        onUpdateSettings = { vm.settingsStore.update(it) },
                        onAddPlaylist = {
                            vm.openDrawer(RightDrawerType.NONE)
                            vm.openWizard(WizardStep.PLAYLIST_TYPE)
                        },
                        onDeletePlaylist = { id -> vm.viewModelScope.launch { vm.repo.deletePlaylist(id) } },
                        onSyncXmltv = { url -> vm.viewModelScope.launch { vm.repo.syncXmltv(url, settings.storeProgramDescriptions) } },
                        onToggleHdrBoost = { vm.toggleHdrColorBoost() },
                        onClose = { vm.openDrawer(RightDrawerType.NONE) }
                    )
                }
            }
        }
    }
}
