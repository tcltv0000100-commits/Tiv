package com.tvplayer.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.tvplayer.app.data.model.*

class Converters {
    @TypeConverter
    fun fromPlaylistType(v: PlaylistType): String = v.name
    @TypeConverter
    fun toPlaylistType(v: String): PlaylistType = PlaylistType.valueOf(v)

    @TypeConverter
    fun fromContentType(v: ContentType): String = v.name
    @TypeConverter
    fun toContentType(v: String): ContentType = ContentType.valueOf(v)
}

@Database(
    entities = [
        PlaylistEntity::class,
        GroupEntity::class,
        ChannelEntity::class,
        VodEntity::class,
        EpgProgramEntity::class,
        HistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun groupDao(): GroupDao
    abstract fun channelDao(): ChannelDao
    abstract fun vodDao(): VodDao
    abstract fun epgDao(): EpgDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tvplayer_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
