package com.tvplayer.app.ui.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tvplayer.app.data.model.DisplayModeOption
import com.tvplayer.app.ui.theme.TvPalette

@Composable
fun TvFocusButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSelected: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val bg = when {
        focused || isSelected -> TvPalette.FocusWhite
        else -> TvPalette.SurfaceElevated
    }
    val fg = when {
        focused || isSelected -> TvPalette.FocusTextDark
        else -> TvPalette.TextPrimary
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = fg,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TvFocusRow(
    title: String,
    subtitle: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    val bg = if (focused) TvPalette.FocusWhite else Color.Transparent
    val titleColor = if (focused) TvPalette.FocusTextDark else TvPalette.TextPrimary
    val subColor = if (focused) Color(0xFF4A4D57) else TvPalette.TextSecondary

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = titleColor,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    color = subColor,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
fun TvToggleRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    TvFocusRow(
        title = title,
        subtitle = subtitle,
        onClick = { onToggle(!checked) },
        trailing = {
            Switch(
                checked = checked,
                onCheckedChange = null,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = TvPalette.AccentBlue,
                    uncheckedThumbColor = Color.LightGray,
                    uncheckedTrackColor = TvPalette.SurfaceElevated
                )
            )
        }
    )
}

@OptIn(UnstableApi::class)
@Composable
fun TvVideoSurface(
    player: ExoPlayer,
    displayMode: DisplayModeOption = DisplayModeOption.NORMAL,
    modifier: Modifier = Modifier
) {
    val resizeMode = when (displayMode) {
        DisplayModeOption.NORMAL, DisplayModeOption.REDUCED -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        DisplayModeOption.FULL, DisplayModeOption.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        DisplayModeOption.ZOOM, DisplayModeOption.ZOOM_120 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        DisplayModeOption.RATIO_4_3, DisplayModeOption.RATIO_235 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                this.player = player
                this.resizeMode = resizeMode
            }
        },
        update = { view ->
            if (view.player !== player) view.player = player
            if (view.resizeMode != resizeMode) view.resizeMode = resizeMode
        },
        modifier = modifier
    )
}
