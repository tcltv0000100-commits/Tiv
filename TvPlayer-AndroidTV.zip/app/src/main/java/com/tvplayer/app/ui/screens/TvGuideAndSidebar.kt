package com.tvplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import com.tvplayer.app.data.model.*
import com.tvplayer.app.ui.components.TvVideoSurface
import com.tvplayer.app.ui.theme.TvPalette
import com.tvplayer.app.ui.viewmodel.NavSection
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun LeftNavigationRail(
    currentSection: NavSection,
    expanded: Boolean,
    onToggleExpand: (Boolean) -> Unit,
    onSelectSection: (NavSection) -> Unit
) {
    val items = listOf(
        Triple(NavSection.SEARCH, "Search", Icons.Default.Search),
        Triple(NavSection.TV, "TV", Icons.Default.Tv),
        Triple(NavSection.MOVIES, "Movies", Icons.Default.Movie),
        Triple(NavSection.SHOWS, "Shows", Icons.Default.LiveTv),
        Triple(NavSection.RECORDINGS, "Recordings", Icons.Default.Dvr),
        Triple(NavSection.MY_LIST, "My list", Icons.Default.BookmarkBorder),
        Triple(NavSection.SETTINGS, "Settings", Icons.Default.Settings)
    )

    Column(
        modifier = Modifier
            .width(if (expanded) 168.dp else 56.dp)
            .fillMaxHeight()
            .background(Color(0xFF101115))
            .onFocusChanged { if (it.hasFocus != expanded) onToggleExpand(it.hasFocus) }
            .padding(vertical = 16.dp, horizontal = 8.dp),
        horizontalAlignment = if (expanded) Alignment.Start else Alignment.CenterHorizontally
    ) {
        // Brand Logo "tv" / "tivimate"
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
            Text(
                text = "tv",
                color = TvPalette.AccentBlue,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
            )
            if (expanded) {
                Text(
                    text = "mate",
                    color = TvPalette.TextPrimary,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        items.forEach { (section, label, icon) ->
            var focused by remember { mutableStateOf(false) }
            val active = currentSection == section
            val bg = when {
                focused -> TvPalette.FocusWhite
                active -> TvPalette.SurfaceElevated
                else -> Color.Transparent
            }
            val fg = if (focused) TvPalette.FocusTextDark else if (active) TvPalette.TextPrimary else TvPalette.TextSecondary

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(bg)
                    .onFocusChanged { focused = it.isFocused }
                    .focusable()
                    .clickable { onSelectSection(section) }
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = label, tint = fg, modifier = Modifier.size(20.dp))
                if (expanded) {
                    Spacer(Modifier.width(12.dp))
                    Text(text = label, color = fg, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
fun GroupSidebar(
    playlists: List<PlaylistEntity>,
    groups: List<GroupEntity>,
    selectedGroupId: Long?,
    selectedPlaylistId: Long?,
    allLabel: String,
    myListLabel: String,
    onSelectGroup: (groupId: Long?, playlistId: Long?) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .width(210.dp)
            .fillMaxHeight()
            .background(TvPalette.Surface)
            .padding(vertical = 12.dp, horizontal = 8.dp)
    ) {
        item {
            SidebarGroupItem(
                label = myListLabel,
                selected = selectedGroupId == -1L,
                onClick = { onSelectGroup(-1L, null) }
            )
            SidebarGroupItem(
                label = allLabel,
                selected = selectedGroupId == null && selectedPlaylistId == null,
                onClick = { onSelectGroup(null, null) }
            )
        }

        playlists.filter { it.isEnabled }.forEach { pl ->
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = pl.name,
                    color = TvPalette.AccentBlue,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            val plGroups = groups.filter { it.playlistId == pl.id }
            items(plGroups, key = { it.id }) { g ->
                SidebarGroupItem(
                    label = g.name,
                    selected = selectedGroupId == g.id,
                    onClick = { onSelectGroup(g.id, pl.id) }
                )
            }
        }
    }
}

@Composable
private fun SidebarGroupItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val bg = when {
        focused -> TvPalette.FocusWhite
        selected -> TvPalette.SurfaceElevated
        else -> Color.Transparent
    }
    val fg = if (focused) TvPalette.FocusTextDark else TvPalette.TextPrimary
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = fg,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TvGuideScreen(
    channels: List<ChannelEntity>,
    activeChannel: ChannelEntity?,
    epgMap: Map<String, List<EpgProgramEntity>>,
    settings: AppSettings,
    player: ExoPlayer,
    onChannelFocused: (ChannelEntity) -> Unit,
    onChannelClicked: (ChannelEntity) -> Unit,
    onOpenContextMenu: (ChannelEntity) -> Unit,
    onRequestEpgWindow: (List<ChannelEntity>) -> Unit
) {
    var focusedChannel by remember { mutableStateOf(activeChannel ?: channels.firstOrNull()) }

    LaunchedEffect(channels.size) {
        if (channels.isNotEmpty()) {
            onRequestEpgWindow(channels)
        }
    }

    val nowMs = System.currentTimeMillis()
    val timeFmt = remember(settings.use24HourFormat) {
        SimpleDateFormat(if (settings.use24HourFormat) "HH:mm" else "hh:mm a", Locale.US)
    }
    val headerDateFmt = remember(settings.use24HourFormat) {
        SimpleDateFormat(if (settings.use24HourFormat) "EEE, d MMM, HH:mm" else "EEE, d MMM, h:mm a", Locale.US)
    }

    val previewPrograms = focusedChannel?.let { epgMap[it.tvgId] }.orEmpty()
    val currentProg = previewPrograms.firstOrNull { nowMs in it.startTimeMs..it.endTimeMs }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background)
            .padding(start = 16.dp, top = 12.dp, end = 16.dp)
    ) {
        // Top Preview + Program Info Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(172.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .width(304.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
                    .clickable { focusedChannel?.let(onChannelClicked) }
            ) {
                TvVideoSurface(player = player, displayMode = settings.displayMode, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentProg?.title ?: "No information",
                        style = MaterialTheme.typography.titleLarge,
                        color = TvPalette.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = focusedChannel?.groupName.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TvPalette.TextSecondary
                    )
                }
                Spacer(Modifier.height(6.dp))
                val slotText = if (currentProg != null) {
                    "${timeFmt.format(Date(currentProg.startTimeMs))} – ${timeFmt.format(Date(currentProg.endTimeMs))}"
                } else {
                    "${timeFmt.format(Date(nowMs))} – ${timeFmt.format(Date(nowMs + 3600_000L))}"
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = slotText, style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary)
                    Spacer(Modifier.width(12.dp))
                    val progress = if (currentProg != null && currentProg.endTimeMs > currentProg.startTimeMs) {
                        ((nowMs - currentProg.startTimeMs).toFloat() / (currentProg.endTimeMs - currentProg.startTimeMs)).coerceIn(0f, 1f)
                    } else 0.1f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.width(100.dp).height(3.dp),
                        color = TvPalette.AccentBlue,
                        trackColor = TvPalette.SurfaceElevated
                    )
                }
                if (settings.showProgramDescription && !currentProg?.description.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = currentProg?.description.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TvPalette.TextSecondary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Timeline Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = headerDateFmt.format(Date(nowMs)),
                color = TvPalette.AccentBlue,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                modifier = Modifier.width(230.dp)
            )
            listOf(0, 30, 60, 90, 120).forEach { mins ->
                Text(
                    text = timeFmt.format(Date(nowMs + mins * 60_000L)),
                    color = TvPalette.TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // EPG Channel + Program Rows
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(channels, key = { it.id }) { ch ->
                val isPlaying = activeChannel?.id == ch.id
                val chPrograms = epgMap[ch.tvgId].orEmpty()
                val cur = chPrograms.firstOrNull { nowMs in it.startTimeMs..it.endTimeMs }
                val nxt = chPrograms.firstOrNull { it.startTimeMs >= (cur?.endTimeMs ?: nowMs) }
                var rowFocused by remember { mutableStateOf(false) }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Channel Cell
                    Row(
                        modifier = Modifier
                            .width(230.dp)
                            .fillMaxHeight()
                            .padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (settings.showChannelNumbers) {
                            Text(
                                text = "${ch.number}",
                                color = TvPalette.TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.width(34.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(34.dp, 24.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TvPalette.SurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            if (ch.logoUrl.isNotBlank()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(2.dp)
                                )
                            } else {
                                Icon(Icons.Default.Tv, contentDescription = null, tint = TvPalette.TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        if (settings.showChannelNames) {
                            Text(
                                text = ch.name,
                                color = if (isPlaying && settings.highlightCurrentChannel) TvPalette.AccentBlue else TvPalette.TextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = if (settings.twoLineChannelNames) 2 else 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (isPlaying) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TvPalette.AccentBlue, modifier = Modifier.size(16.dp))
                        }
                    }

                    // Current + Next EPG Slot Blocks
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (rowFocused) TvPalette.FocusWhite else TvPalette.EpgSlot)
                                .onFocusChanged {
                                    rowFocused = it.isFocused
                                    if (it.isFocused) {
                                        focusedChannel = ch
                                        onChannelFocused(ch)
                                    }
                                }
                                .focusable()
                                .clickable { onChannelClicked(ch) }
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = cur?.title ?: "No information",
                                color = if (rowFocused) TvPalette.FocusTextDark else TvPalette.TextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = if (settings.twoLineProgramTitles) 2 else 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TvPalette.EpgSlot)
                                .clickable { onOpenContextMenu(ch) }
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = nxt?.title ?: "No information",
                                color = TvPalette.TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
