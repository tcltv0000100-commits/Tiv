package com.tvplayer.app.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class PlaylistType { M3U, XTREAM, STALKER }
enum class ContentType { LIVE, MOVIE, SHOW }

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: PlaylistType,
    val url: String = "",
    val serverUrl: String = "",
    val username: String = "",
    val password: String = "",
    val macAddress: String = "",
    val deviceId1: String = "",
    val deviceId2: String = "",
    val serialNumber: String = "",
    val resolvedPortalPath: String = "portal.php",
    val epgUrl: String = "",
    val userAgent: String = "",
    val isEnabled: Boolean = true,
    val includeTv: Boolean = true,
    val includeVod: Boolean = true,
    val outputFormat: String = "ts",
    val catchupType: String = "Auto",
    val catchupDays: Int = 7,
    val updateIntervalHours: Int = 24,
    val updateOnStart: Boolean = false,
    val lastUpdatedMs: Long = 0L,
    val channelCount: Int = 0,
    val movieCount: Int = 0,
    val showCount: Int = 0
)

@Entity(
    tableName = "groups",
    indices = [
        Index(value = ["playlistId", "contentType"]),
        Index(value = ["name"])
    ]
)
data class GroupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val contentType: ContentType,
    val remoteId: String,
    val name: String,
    val isHidden: Boolean = false,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "channels",
    indices = [
        Index(value = ["playlistId"]),
        Index(value = ["groupId"]),
        Index(value = ["groupName"]),
        Index(value = ["tvgId"]),
        Index(value = ["isFavorite"]),
        Index(value = ["name"])
    ]
)
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val groupId: Long,
    val groupName: String,
    val remoteId: String = "",
    val number: Int = 0,
    val name: String,
    val streamUrl: String = "",
    val cmd: String = "",
    val logoUrl: String = "",
    val tvgId: String = "",
    val drmScheme: String = "",
    val drmLicenseUrl: String = "",
    val drmHeadersJson: String = "",
    val userAgent: String = "",
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isBlocked: Boolean = false,
    val catchupDays: Int = 0,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "vod_items",
    indices = [
        Index(value = ["playlistId", "contentType"]),
        Index(value = ["groupId"]),
        Index(value = ["groupName"]),
        Index(value = ["isInMyList"]),
        Index(value = ["title"])
    ]
)
data class VodEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val groupId: Long,
    val groupName: String,
    val contentType: ContentType,
    val remoteId: String,
    val title: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val genre: String = "",
    val year: String = "",
    val duration: String = "",
    val rating: String = "",
    val streamUrl: String = "",
    val cmd: String = "",
    val containerExtension: String = "mp4",
    val seasonCount: Int = 0,
    val isInMyList: Boolean = false,
    val addedAtMs: Long = 0L,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "epg_programs",
    indices = [
        Index(value = ["channelTvgId", "startTimeMs", "endTimeMs"]),
        Index(value = ["endTimeMs"])
    ]
)
data class EpgProgramEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelTvgId: String,
    val title: String,
    val description: String = "",
    val startTimeMs: Long,
    val endTimeMs: Long,
    val category: String = ""
)

@Entity(
    tableName = "history",
    indices = [Index(value = ["itemType", "lastWatchedMs"])]
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemType: ContentType,
    val itemId: Long,
    val playlistId: Long,
    val title: String,
    val subtitle: String = "",
    val logoUrl: String = "",
    val streamUrl: String = "",
    val lastWatchedMs: Long = System.currentTimeMillis(),
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

data class SeriesSeason(
    val seasonNumber: Int,
    val seasonId: String,
    val name: String,
    val episodes: List<SeriesEpisode> = emptyList()
)

data class SeriesEpisode(
    val id: String,
    val episodeNumber: Int,
    val title: String,
    val plot: String = "",
    val duration: String = "",
    val thumbnailUrl: String = "",
    val streamUrl: String = "",
    val cmd: String = "",
    val containerExtension: String = "mp4"
)

data class StreamPlaybackInfo(
    val url: String,
    val title: String,
    val subtitle: String = "",
    val channelNumber: Int = 0,
    val groupName: String = "",
    val logoUrl: String = "",
    val userAgent: String = "",
    val headers: Map<String, String> = emptyMap(),
    val drmScheme: String = "",
    val drmLicenseUrl: String = "",
    val drmHeaders: Map<String, String> = emptyMap(),
    val isLive: Boolean = true
)
