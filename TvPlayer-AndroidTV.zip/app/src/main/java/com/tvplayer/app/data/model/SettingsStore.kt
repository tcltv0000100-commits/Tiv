package com.tvplayer.app.data.model

import android.content.Context
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class FontSizeScale(val label: String, val multiplier: Float) {
    SMALL("Small", 0.88f),
    MEDIUM("Medium", 1.0f),
    LARGE("Large", 1.14f),
    VERY_LARGE("Very large", 1.28f)
}

enum class BufferPreset(val label: String, val minBufferMs: Int, val maxBufferMs: Int, val playbackMs: Int) {
    NONE("None", 500, 2000, 250),
    SMALL("Small", 1500, 5000, 500),
    MEDIUM("Medium", 3000, 15000, 1500),
    LARGE("Large", 5000, 30000, 2500),
    VERY_LARGE("Very large", 10000, 60000, 5000)
}

enum class DisplayModeOption(val label: String) {
    NORMAL("Normal"),
    FULL("Full"),
    ZOOM("Zoom"),
    ZOOM_120("Zoom 120%"),
    REDUCED("Reduced"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3"),
    RATIO_235("2.35:1")
}

enum class VodSortOrder(val label: String) {
    PLAYLIST("By order in playlist"),
    NAME("By name"),
    RATING("By rating"),
    DATE_ADDED("By date added")
}

data class AppSettings(
    val termsAccepted: Boolean = false,
    val autoStartOnBoot: Boolean = false,
    val autoStartOnWake: Boolean = false,
    val turnOnLastChannel: Boolean = true,
    val pipOnHome: Boolean = false,
    val confirmExitOnBack: Boolean = true,
    val defaultUserAgent: String = "",
    val udpProxy: String = "",
    val epgPastDays: Int = 7,
    val storeProgramDescriptions: Boolean = true,
    val epgUpdateIntervalHours: Int = 24,
    val epgUpdateOnStart: Boolean = true,
    val showChannelNumbers: Boolean = true,
    val showChannelNames: Boolean = true,
    val twoLineChannelNames: Boolean = false,
    val showCatchupIcon: Boolean = true,
    val highlightCurrentChannel: Boolean = true,
    val twoLineProgramTitles: Boolean = false,
    val highlightCurrentProgram: Boolean = true,
    val animatedScrolling: Boolean = true,
    val showProgramDescription: Boolean = true,
    val use24HourFormat: Boolean = false,
    val showTimeInTvGuide: Boolean = true,
    val showAllPlaylistsCategory: Boolean = true,
    val showFavoritesCategory: Boolean = true,
    val showAllChannelsCategory: Boolean = true,
    val fontSizeScale: FontSizeScale = FontSizeScale.MEDIUM,
    val backgroundColorHex: String = "#14151A",
    val accentColorHex: String = "#2196F3",
    val uiTransparencyPercent: Int = 50,
    val bufferPreset: BufferPreset = BufferPreset.SMALL,
    val hardwareVideoDecoder: Boolean = true,
    val hardwareAudioDecoder: Boolean = true,
    val autoFrameRate: Boolean = false,
    val hdrColorBoost: Boolean = true, // ON by default per user request
    val surroundAudioDefault: Boolean = false,
    val audioPassthrough: Boolean = false,
    val displayMode: DisplayModeOption = DisplayModeOption.NORMAL,
    val vodSortOrder: VodSortOrder = VodSortOrder.PLAYLIST,
    val parentalPin: String = "",
    val lastChannelId: Long = -1L
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tvplayer_settings", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun load(): AppSettings {
        val raw = prefs.getString("app_settings_json", null) ?: return AppSettings()
        return try {
            gson.fromJson(raw, AppSettings::class.java) ?: AppSettings()
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        prefs.edit().putString("app_settings_json", gson.toJson(updated)).apply()
    }
}
