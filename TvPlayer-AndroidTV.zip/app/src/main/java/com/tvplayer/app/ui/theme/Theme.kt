package com.tvplayer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.tvplayer.app.data.model.FontSizeScale

object TvPalette {
    val Background = Color(0xFF14151A)
    val Surface = Color(0xFF1B1C21)
    val SurfaceElevated = Color(0xFF25262B)
    val EpgSlot = Color(0xFF1E1F24)
    val FocusWhite = Color(0xFFFFFFFF)
    val FocusTextDark = Color(0xFF14151A)
    val AccentBlue = Color(0xFF2196F3)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF8E929B)
    val Divider = Color(0xFF2A2C33)
}

@Composable
fun TvPlayerTheme(
    fontScale: FontSizeScale = FontSizeScale.MEDIUM,
    accentHex: String = "#2196F3",
    content: @Composable () -> Unit
) {
    val m = fontScale.multiplier
    val accentColor = try {
        Color(android.graphics.Color.parseColor(accentHex))
    } catch (_: Exception) {
        TvPalette.AccentBlue
    }

    val colorScheme = darkColorScheme(
        primary = accentColor,
        background = TvPalette.Background,
        surface = TvPalette.Surface,
        surfaceVariant = TvPalette.SurfaceElevated,
        onPrimary = Color.White,
        onBackground = TvPalette.TextPrimary,
        onSurface = TvPalette.TextPrimary
    )

    val typography = Typography(
        headlineMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            fontSize = (24 * m).sp,
            color = TvPalette.TextPrimary
        ),
        titleLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = (20 * m).sp,
            color = TvPalette.TextPrimary
        ),
        titleMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = (16 * m).sp,
            color = TvPalette.TextPrimary
        ),
        bodyLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (15 * m).sp,
            color = TvPalette.TextPrimary
        ),
        bodyMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (13 * m).sp,
            color = TvPalette.TextSecondary
        ),
        labelSmall = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = (11 * m).sp,
            color = TvPalette.TextSecondary
        )
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}
