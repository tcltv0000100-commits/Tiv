package com.tvplayer.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tvplayer.app.data.db.AppDatabase
import com.tvplayer.app.data.model.*
import com.tvplayer.app.data.network.HttpClientProvider
import com.tvplayer.app.data.parser.M3uParser
import com.tvplayer.app.data.parser.XmltvParser
import com.tvplayer.app.data.remote.StalkerClient
import com.tvplayer.app.data.remote.XtreamClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.Request

data class SyncProgress(
    val isProcessing: Boolean = false,
    val message: String = "",
    val channelCount: Int = 0,
    val movieCount: Int = 0,
    val showCount: Int = 0,
    val error: String? = null
)

class IptvRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val playlistDao = db.playlistDao()
    private val groupDao = db.groupDao()
    private val channelDao = db.channelDao()
    private val vodDao = db.vodDao()
    private val epgDao = db.epgDao()
    private val historyDao = db.historyDao()

    val xtreamClient = XtreamClient()
    val stalkerClient = StalkerClient()
    private val http = HttpClientProvider.client
    private val gson = Gson()

    fun observePlaylists(): Flow<List<PlaylistEntity>> = playlistDao.observeAll()
    fun observeGroups(type: ContentType): Flow<List<GroupEntity>> = groupDao.observeVisibleByType(type)
    fun observeAllChannels(): Flow<List<ChannelEntity>> = channelDao.observeAllVisible()
    fun observeFavoriteChannels(): Flow<List<ChannelEntity>> = channelDao.observeFavorites()
    fun observeChannelsByGroup(groupId: Long): Flow<List<ChannelEntity>> = channelDao.observeByGroup(groupId)
    fun observeChannelsByPlaylist(playlistId: Long): Flow<List<ChannelEntity>> = channelDao.observeByPlaylist(playlistId)
    fun observeAllVod(type: ContentType): Flow<List<VodEntity>> = vodDao.observeAllByType(type)
    fun observeVodByGroup(groupId: Long, type: ContentType): Flow<List<VodEntity>> = vodDao.observeByGroup(groupId, type)
    fun observeVodByPlaylist(playlistId: Long, type: ContentType): Flow<List<VodEntity>> = vodDao.observeByPlaylist(playlistId, type)
    fun observeMyList(type: ContentType): Flow<List<VodEntity>> = vodDao.observeMyList(type)
    fun observeHistory(type: ContentType): Flow<List<HistoryEntity>> = historyDao.observeRecent(type)

    suspend fun toggleChannelFavorite(channel: ChannelEntity) =
        channelDao.setFavorite(channel.id, !channel.isFavorite)

    suspend fun toggleVodMyList(vod: VodEntity) =
        vodDao.setMyList(vod.id, !vod.isInMyList)

    suspend fun setGroupHidden(groupId: Long, hidden: Boolean) =
        groupDao.setHidden(groupId, hidden)

    suspend fun recordHistory(
        type: ContentType,
        itemId: Long,
        playlistId: Long,
        title: String,
        subtitle: String,
        logoUrl: String,
        streamUrl: String
    ) {
        historyDao.insert(
            HistoryEntity(
                itemType = type,
                itemId = itemId,
                playlistId = playlistId,
                title = title,
                subtitle = subtitle,
                logoUrl = logoUrl,
                streamUrl = streamUrl,
                lastWatchedMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun addM3uPlaylist(
        name: String,
        url: String,
        epgUrl: String = ""
    ): SyncProgress = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url.trim()).header("User-Agent", "TiviMate/5.0").build()
            val parsed = http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext SyncProgress(error = "HTTP ${resp.code}")
                val body = resp.body ?: return@withContext SyncProgress(error = "Empty response")
                M3uParser.parse(body.byteStream())
            }
            val resolvedEpg = epgUrl.ifBlank { parsed.epgUrl.orEmpty() }
            val playlistId = playlistDao.insert(
                PlaylistEntity(
                    name = name.ifBlank { "M3U Playlist" },
                    type = PlaylistType.M3U,
                    url = url.trim(),
                    epgUrl = resolvedEpg,
                    lastUpdatedMs = System.currentTimeMillis(),
                    channelCount = parsed.channels.size
                )
            )

            val distinctGroups = parsed.channels.map { it.groupName }.distinct()
            val groupEntities = distinctGroups.mapIndexed { idx, gName ->
                GroupEntity(
                    playlistId = playlistId,
                    contentType = ContentType.LIVE,
                    remoteId = gName,
                    name = gName,
                    sortOrder = idx
                )
            }
            val insertedGroupIds = groupDao.insertAll(groupEntities)
            val groupMap = distinctGroups.zip(insertedGroupIds).toMap()

            val channelEntities = parsed.channels.mapIndexed { idx, ch ->
                ChannelEntity(
                    playlistId = playlistId,
                    groupId = groupMap[ch.groupName] ?: 0L,
                    groupName = ch.groupName,
                    number = idx + 1,
                    name = ch.name,
                    streamUrl = ch.streamUrl,
                    logoUrl = ch.logoUrl,
                    tvgId = ch.tvgId,
                    drmScheme = ch.drmScheme,
                    drmLicenseUrl = ch.drmLicenseUrl,
                    drmHeadersJson = ch.drmHeadersJson,
                    userAgent = ch.userAgent,
                    catchupDays = ch.catchupDays,
                    sortOrder = idx
                )
            }
            channelDao.insertChunked(channelEntities)

            if (resolvedEpg.isNotBlank()) {
                syncXmltv(resolvedEpg, storeDescriptions = true)
            }

            SyncProgress(channelCount = channelEntities.size)
        } catch (e: Exception) {
            SyncProgress(error = e.message ?: "Failed to load M3U")
        }
    }

    suspend fun addXtreamPlaylist(
        name: String,
        server: String,
        username: String,
        password: String,
        includeTv: Boolean,
        includeVod: Boolean
    ): SyncProgress = withContext(Dispatchers.IO) {
        try {
            val ok = xtreamClient.authenticate(server, username, password)
            if (!ok) return@withContext SyncProgress(error = "Xtream authentication failed")

            val playlistId = playlistDao.insert(
                PlaylistEntity(
                    name = name.ifBlank { server.removePrefix("http://").removePrefix("https://") },
                    type = PlaylistType.XTREAM,
                    serverUrl = server.trim(),
                    username = username.trim(),
                    password = password.trim(),
                    epgUrl = xtreamClient.buildXmltvUrl(server.trim(), username.trim(), password.trim()),
                    includeTv = includeTv,
                    includeVod = includeVod,
                    lastUpdatedMs = System.currentTimeMillis()
                )
            )

            var chCount = 0
            var mvCount = 0
            var shCount = 0

            if (includeTv) {
                val cats = xtreamClient.getCategories(server, username, password, "get_live_categories")
                val groupEntities = cats.mapIndexed { idx, c ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.LIVE, remoteId = c.id, name = c.name, sortOrder = idx)
                }
                val gIds = groupDao.insertAll(groupEntities)
                val catMap = cats.map { it.id }.zip(gIds).toMap()
                val catNameMap = cats.associate { it.id to it.name }

                val streams = xtreamClient.getLiveStreams(server, username, password)
                val channels = streams.mapIndexed { idx, s ->
                    ChannelEntity(
                        playlistId = playlistId,
                        groupId = catMap[s.categoryId] ?: 0L,
                        groupName = catNameMap[s.categoryId] ?: "Live TV",
                        remoteId = s.streamId,
                        number = s.num,
                        name = s.name,
                        streamUrl = xtreamClient.buildLiveUrl(server, username, password, s.streamId, "ts"),
                        logoUrl = s.icon,
                        tvgId = s.epgChannelId.ifBlank { s.streamId },
                        catchupDays = s.catchupDays,
                        sortOrder = idx
                    )
                }
                channelDao.insertChunked(channels)
                chCount = channels.size
            }

            if (includeVod) {
                val mCats = xtreamClient.getCategories(server, username, password, "get_vod_categories")
                val mGroups = mCats.mapIndexed { idx, c ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.MOVIE, remoteId = c.id, name = c.name, sortOrder = idx)
                }
                val mIds = groupDao.insertAll(mGroups)
                val mCatMap = mCats.map { it.id }.zip(mIds).toMap()
                val mNameMap = mCats.associate { it.id to it.name }

                val vods = xtreamClient.getVodStreams(server, username, password)
                val movieEntities = vods.mapIndexed { idx, v ->
                    VodEntity(
                        playlistId = playlistId,
                        groupId = mCatMap[v.categoryId] ?: 0L,
                        groupName = mNameMap[v.categoryId] ?: "Movies",
                        contentType = ContentType.MOVIE,
                        remoteId = v.id,
                        title = v.title,
                        posterUrl = v.icon,
                        backdropUrl = v.icon,
                        rating = v.rating,
                        streamUrl = xtreamClient.buildVodUrl(server, username, password, v.id, v.containerExtension),
                        containerExtension = v.containerExtension,
                        addedAtMs = v.added * 1000L,
                        sortOrder = idx
                    )
                }
                vodDao.insertChunked(movieEntities)
                mvCount = movieEntities.size

                val sCats = xtreamClient.getCategories(server, username, password, "get_series_categories")
                val sGroups = sCats.mapIndexed { idx, c ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.SHOW, remoteId = c.id, name = c.name, sortOrder = idx)
                }
                val sIds = groupDao.insertAll(sGroups)
                val sCatMap = sCats.map { it.id }.zip(sIds).toMap()
                val sNameMap = sCats.associate { it.id to it.name }

                val series = xtreamClient.getSeries(server, username, password)
                val showEntities = series.mapIndexed { idx, sr ->
                    VodEntity(
                        playlistId = playlistId,
                        groupId = sCatMap[sr.categoryId] ?: 0L,
                        groupName = sNameMap[sr.categoryId] ?: "Shows",
                        contentType = ContentType.SHOW,
                        remoteId = sr.seriesId,
                        title = sr.title,
                        posterUrl = sr.cover,
                        backdropUrl = sr.cover,
                        plot = sr.plot,
                        cast = sr.cast,
                        director = sr.director,
                        genre = sr.genre,
                        year = sr.releaseDate.take(4),
                        rating = sr.rating,
                        sortOrder = idx
                    )
                }
                vodDao.insertChunked(showEntities)
                shCount = showEntities.size
            }

            val existing = playlistDao.getById(playlistId)
            if (existing != null) {
                playlistDao.update(existing.copy(channelCount = chCount, movieCount = mvCount, showCount = shCount))
            }

            SyncProgress(channelCount = chCount, movieCount = mvCount, showCount = shCount)
        } catch (e: Exception) {
            SyncProgress(error = e.message ?: "Xtream sync error")
        }
    }

    suspend fun addStalkerPlaylist(
        name: String,
        server: String,
        mac: String,
        includeTv: Boolean,
        includeVod: Boolean
    ): SyncProgress = withContext(Dispatchers.IO) {
        try {
            val session = stalkerClient.connect(server, mac)
                ?: return@withContext SyncProgress(error = "Stalker handshake failed. Check Portal URL / MAC.")

            val playlistId = playlistDao.insert(
                PlaylistEntity(
                    name = name.ifBlank { session.portalBase.removePrefix("http://").removePrefix("https://") },
                    type = PlaylistType.STALKER,
                    serverUrl = session.portalBase,
                    macAddress = session.identity.mac,
                    deviceId1 = session.identity.deviceId1,
                    deviceId2 = session.identity.deviceId2,
                    serialNumber = session.identity.sn,
                    resolvedPortalPath = session.portalPath,
                    includeTv = includeTv,
                    includeVod = includeVod,
                    lastUpdatedMs = System.currentTimeMillis()
                )
            )

            var chCount = 0
            var mvCount = 0
            var shCount = 0

            if (includeTv) {
                val genres = stalkerClient.getGenres(session, "itv")
                val gEntities = genres.mapIndexed { idx, g ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.LIVE, remoteId = g.id, name = g.title, sortOrder = idx)
                }
                val gIds = groupDao.insertAll(gEntities)
                val gMap = genres.map { it.id }.zip(gIds).toMap()
                val gNameMap = genres.associate { it.id to it.title }

                val channels = stalkerClient.getAllChannels(session)
                val chEntities = channels.mapIndexed { idx, ch ->
                    ChannelEntity(
                        playlistId = playlistId,
                        groupId = gMap[ch.genreId] ?: 0L,
                        groupName = gNameMap[ch.genreId] ?: "Live TV",
                        remoteId = ch.id,
                        number = ch.number,
                        name = ch.name,
                        cmd = ch.cmd,
                        logoUrl = ch.logo,
                        tvgId = "stalker_${ch.id}",
                        sortOrder = idx
                    )
                }
                channelDao.insertChunked(chEntities)
                chCount = chEntities.size
            }

            if (includeVod) {
                val vCats = stalkerClient.getGenres(session, "vod")
                val vGroups = vCats.mapIndexed { idx, g ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.MOVIE, remoteId = g.id, name = g.title, sortOrder = idx)
                }
                val vIds = groupDao.insertAll(vGroups)
                val vMap = vCats.map { it.id }.zip(vIds).toMap()
                val vNameMap = vCats.associate { it.id to it.title }

                val vItems = stalkerClient.getOrderedList(session, "vod", "*", maxPages = 6)
                val mvEntities = vItems.mapIndexed { idx, v ->
                    VodEntity(
                        playlistId = playlistId,
                        groupId = vMap[v.categoryId] ?: 0L,
                        groupName = vNameMap[v.categoryId] ?: "Movies",
                        contentType = ContentType.MOVIE,
                        remoteId = v.id,
                        title = v.title,
                        posterUrl = v.poster,
                        backdropUrl = v.poster,
                        plot = v.description,
                        cast = v.actors,
                        director = v.director,
                        year = v.year,
                        duration = v.duration,
                        rating = v.rating,
                        cmd = v.cmd,
                        sortOrder = idx
                    )
                }
                vodDao.insertChunked(mvEntities)
                mvCount = mvEntities.size

                val sCats = stalkerClient.getGenres(session, "series")
                val sGroups = sCats.mapIndexed { idx, g ->
                    GroupEntity(playlistId = playlistId, contentType = ContentType.SHOW, remoteId = g.id, name = g.title, sortOrder = idx)
                }
                val sIds = groupDao.insertAll(sGroups)
                val sMap = sCats.map { it.id }.zip(sIds).toMap()
                val sNameMap = sCats.associate { it.id to it.title }

                val sItems = stalkerClient.getOrderedList(session, "series", "*", maxPages = 6)
                val shEntities = sItems.mapIndexed { idx, s ->
                    VodEntity(
                        playlistId = playlistId,
                        groupId = sMap[s.categoryId] ?: 0L,
                        groupName = sNameMap[s.categoryId] ?: "Shows",
                        contentType = ContentType.SHOW,
                        remoteId = s.id,
                        title = s.title,
                        posterUrl = s.poster,
                        backdropUrl = s.poster,
                        plot = s.description,
                        cast = s.actors,
                        director = s.director,
                        year = s.year,
                        duration = s.duration,
                        rating = s.rating,
                        cmd = s.cmd,
                        sortOrder = idx
                    )
                }
                vodDao.insertChunked(shEntities)
                shCount = shEntities.size
            }

            val existing = playlistDao.getById(playlistId)
            if (existing != null) {
                playlistDao.update(existing.copy(channelCount = chCount, movieCount = mvCount, showCount = shCount))
            }

            SyncProgress(channelCount = chCount, movieCount = mvCount, showCount = shCount)
        } catch (e: Exception) {
            SyncProgress(error = e.message ?: "Stalker sync error")
        }
    }

    suspend fun resolveChannelPlayback(channel: ChannelEntity): StreamPlaybackInfo? = withContext(Dispatchers.IO) {
        val playlist = playlistDao.getById(channel.playlistId) ?: return@withContext null
        val url = when (playlist.type) {
            PlaylistType.M3U, PlaylistType.XTREAM -> channel.streamUrl
            PlaylistType.STALKER -> {
                val session = stalkerClient.connect(
                    playlist.serverUrl,
                    playlist.macAddress,
                    playlist.resolvedPortalPath,
                    playlist.serialNumber,
                    playlist.deviceId1,
                    playlist.deviceId2
                ) ?: return@withContext null
                stalkerClient.createLink(session, "itv", channel.cmd) ?: return@withContext null
            }
        }
        val headers: Map<String, String> = if (channel.drmHeadersJson.isNotBlank()) {
            try {
                gson.fromJson(channel.drmHeadersJson, object : TypeToken<Map<String, String>>() {}.type)
            } catch (_: Exception) {
                emptyMap()
            }
        } else emptyMap()

        StreamPlaybackInfo(
            url = url,
            title = channel.name,
            channelNumber = channel.number,
            groupName = channel.groupName,
            logoUrl = channel.logoUrl,
            userAgent = channel.userAgent.ifBlank { playlist.userAgent },
            headers = headers,
            drmScheme = channel.drmScheme,
            drmLicenseUrl = channel.drmLicenseUrl,
            drmHeaders = headers,
            isLive = true
        )
    }

    suspend fun resolveVodPlayback(vod: VodEntity, episode: SeriesEpisode? = null): StreamPlaybackInfo? =
        withContext(Dispatchers.IO) {
            val playlist = playlistDao.getById(vod.playlistId) ?: return@withContext null
            val url = when (playlist.type) {
                PlaylistType.M3U, PlaylistType.XTREAM -> episode?.streamUrl ?: vod.streamUrl
                PlaylistType.STALKER -> {
                    val session = stalkerClient.connect(
                        playlist.serverUrl,
                        playlist.macAddress,
                        playlist.resolvedPortalPath,
                        playlist.serialNumber,
                        playlist.deviceId1,
                        playlist.deviceId2
                    ) ?: return@withContext null
                    val targetCmd = episode?.cmd?.ifBlank { vod.cmd } ?: vod.cmd
                    val epArg = episode?.episodeNumber?.toString() ?: ""
                    stalkerClient.createLink(session, "vod", targetCmd, epArg) ?: return@withContext null
                }
            }
            val displayTitle = if (episode != null) "${vod.title} - S1 E${episode.episodeNumber}" else vod.title
            StreamPlaybackInfo(
                url = url,
                title = displayTitle,
                groupName = vod.groupName,
                logoUrl = vod.posterUrl,
                userAgent = playlist.userAgent,
                isLive = false
            )
        }

    suspend fun loadSeriesSeasons(show: VodEntity): List<SeriesSeason> = withContext(Dispatchers.IO) {
        val playlist = playlistDao.getById(show.playlistId) ?: return@withContext emptyList()
        when (playlist.type) {
            PlaylistType.XTREAM -> xtreamClient.getSeriesInfo(
                playlist.serverUrl,
                playlist.username,
                playlist.password,
                show.remoteId
            )
            PlaylistType.STALKER -> {
                val session = stalkerClient.connect(
                    playlist.serverUrl,
                    playlist.macAddress,
                    playlist.resolvedPortalPath,
                    playlist.serialNumber,
                    playlist.deviceId1,
                    playlist.deviceId2
                ) ?: return@withContext emptyList()
                stalkerClient.getSeriesSeasonsAndEpisodes(session, show.remoteId, show.cmd)
            }
            PlaylistType.M3U -> emptyList()
        }
    }

    suspend fun syncXmltv(epgUrl: String, storeDescriptions: Boolean) = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(epgUrl.trim()).header("User-Agent", "TiviMate/5.0").build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext
                val stream = resp.body?.byteStream() ?: return@withContext
                XmltvParser.parseStreaming(stream, storeDescriptions) { batch ->
                    epgDao.insertChunked(batch)
                }
            }
        } catch (_: Exception) {
        }
    }

    suspend fun getEpgForChannels(tvgIds: List<String>, fromMs: Long, toMs: Long): Map<String, List<EpgProgramEntity>> =
        withContext(Dispatchers.IO) {
            if (tvgIds.isEmpty()) return@withContext emptyMap()
            epgDao.getProgramsForChannels(tvgIds, fromMs, toMs).groupBy { it.channelTvgId }
        }

    suspend fun searchAll(query: String): Triple<List<ChannelEntity>, List<VodEntity>, List<VodEntity>> =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isBlank()) return@withContext Triple(emptyList(), emptyList(), emptyList())
            val ch = channelDao.search(q)
            val mv = vodDao.search(ContentType.MOVIE, q)
            val sh = vodDao.search(ContentType.SHOW, q)
            Triple(ch, mv, sh)
        }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        channelDao.deleteByPlaylist(playlistId)
        vodDao.deleteByPlaylist(playlistId)
        groupDao.deleteByPlaylist(playlistId)
        playlistDao.deleteById(playlistId)
    }
}
