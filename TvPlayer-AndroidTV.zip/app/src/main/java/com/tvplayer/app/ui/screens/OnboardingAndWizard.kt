package com.tvplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Login
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tvplayer.app.data.repository.SyncProgress
import com.tvplayer.app.ui.components.TvFocusButton
import com.tvplayer.app.ui.components.TvFocusRow
import com.tvplayer.app.ui.theme.TvPalette
import com.tvplayer.app.ui.viewmodel.WizardStep

@Composable
fun TermsOfUseOverlay(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(TvPalette.Surface)
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Terms of Use",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = TvPalette.TextPrimary
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "This application is a media player only and does not provide any TV channels, movies, or media content. " +
                    "To watch content, you must add your own playlists (M3U, Xtream Codes, or Stalker Portal). " +
                    "You are solely responsible for ensuring you have the legal rights to access any streams you load.",
                style = MaterialTheme.typography.bodyMedium,
                color = TvPalette.TextSecondary
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvFocusButton(text = "DISAGREE AND EXIT", onClick = onDecline)
                TvFocusButton(text = "ACCEPT", onClick = onAccept, isSelected = true)
            }
        }
    }
}

@Composable
fun EmptyHomeScreen(
    onAddPlaylist: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "TiviMate does not provide any content",
                style = MaterialTheme.typography.titleLarge,
                color = TvPalette.TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Add your playlist",
                style = MaterialTheme.typography.bodyMedium,
                color = TvPalette.TextSecondary
            )
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvFocusButton(text = "Add playlist", onClick = onAddPlaylist, isSelected = true)
                TvFocusButton(text = "Settings", onClick = onOpenSettings)
            }
        }
    }
}

@Composable
fun AddPlaylistWizardOverlay(
    step: WizardStep,
    syncProgress: SyncProgress,
    onSelectStep: (WizardStep) -> Unit,
    onSubmitM3u: (name: String, url: String, epgUrl: String) -> Unit,
    onSubmitXtream: (name: String, server: String, user: String, pass: String, tv: Boolean, vod: Boolean) -> Unit,
    onSubmitStalker: (name: String, server: String, mac: String, tv: Boolean, vod: Boolean) -> Unit,
    onClose: () -> Unit
) {
    var m3uUrl by remember { mutableStateOf("") }
    var m3uName by remember { mutableStateOf("My M3U Playlist") }
    var epgUrl by remember { mutableStateOf("") }

    var xcServer by remember { mutableStateOf("") }
    var xcUser by remember { mutableStateOf("") }
    var xcPass by remember { mutableStateOf("") }
    var xcTv by remember { mutableStateOf(true) }
    var xcVod by remember { mutableStateOf(true) }

    var stServer by remember { mutableStateOf("") }
    var stMac by remember { mutableStateOf("") }
    var stTv by remember { mutableStateOf(true) }
    var stVod by remember { mutableStateOf(true) }

    val leftIcon: ImageVector = when (step) {
        WizardStep.PLAYLIST_TYPE -> Icons.AutoMirrored.Filled.PlaylistAdd
        WizardStep.M3U_FORM, WizardStep.EPG_URL -> Icons.Default.Link
        WizardStep.XTREAM_FORM, WizardStep.STALKER_FORM -> Icons.Default.Login
        WizardStep.PROCESSING, WizardStep.PROCESSED_SUMMARY -> Icons.Default.CloudDownload
        WizardStep.NONE -> Icons.AutoMirrored.Filled.PlaylistAdd
    }

    val leftTitle = when (step) {
        WizardStep.PLAYLIST_TYPE -> "Playlist type"
        WizardStep.M3U_FORM -> "M3U playlist"
        WizardStep.XTREAM_FORM -> "Xtream Codes"
        WizardStep.STALKER_FORM -> "Stalker Portal"
        WizardStep.PROCESSING -> "Processing..."
        WizardStep.PROCESSED_SUMMARY -> "Playlist is processed"
        WizardStep.EPG_URL -> "EPG URL"
        WizardStep.NONE -> ""
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background)
    ) {
        // Left 40% Panel
        Box(
            modifier = Modifier
                .weight(0.4f)
                .fillMaxHeight()
                .background(TvPalette.Surface)
                .padding(32.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = leftIcon,
                        contentDescription = null,
                        tint = TvPalette.TextPrimary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.width(16.dp))
                    Text(
                        text = leftTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = TvPalette.TextPrimary
                    )
                }
                if (step == WizardStep.PROCESSED_SUMMARY) {
                    Spacer(Modifier.height(16.dp))
                    Text("Channels: ${syncProgress.channelCount}", style = MaterialTheme.typography.bodyMedium)
                    if (syncProgress.movieCount > 0) Text("Movies: ${syncProgress.movieCount}", style = MaterialTheme.typography.bodyMedium)
                    if (syncProgress.showCount > 0) Text("Shows: ${syncProgress.showCount}", style = MaterialTheme.typography.bodyMedium)
                }
                if (!syncProgress.error.isNullOrBlank()) {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = syncProgress.error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Middle 42% Form/Options Panel
        Column(
            modifier = Modifier
                .weight(0.42f)
                .fillMaxHeight()
                .background(TvPalette.Background)
                .padding(28.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                WizardStep.PLAYLIST_TYPE -> {
                    TvFocusRow(title = "M3U playlist", onClick = { onSelectStep(WizardStep.M3U_FORM) })
                    TvFocusRow(title = "Xtream Codes", onClick = { onSelectStep(WizardStep.XTREAM_FORM) })
                    TvFocusRow(title = "Stalker Portal", onClick = { onSelectStep(WizardStep.STALKER_FORM) })
                }

                WizardStep.M3U_FORM -> {
                    OutlinedTextField(
                        value = m3uUrl,
                        onValueChange = { m3uUrl = it },
                        label = { Text("Enter URL (http://...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = m3uName,
                        onValueChange = { m3uName = it },
                        label = { Text("Playlist name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = epgUrl,
                        onValueChange = { epgUrl = it },
                        label = { Text("EPG URL (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                WizardStep.XTREAM_FORM -> {
                    OutlinedTextField(
                        value = xcServer,
                        onValueChange = { xcServer = it },
                        label = { Text("Server address (http://host:port)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = xcUser,
                        onValueChange = { xcUser = it },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = xcPass,
                        onValueChange = { xcPass = it },
                        label = { Text("Password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = xcTv, onCheckedChange = { xcTv = it })
                        Text("Include TV channels", color = TvPalette.TextPrimary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = xcVod, onCheckedChange = { xcVod = it })
                        Text("Include VOD", color = TvPalette.TextPrimary)
                    }
                }

                WizardStep.STALKER_FORM -> {
                    OutlinedTextField(
                        value = stServer,
                        onValueChange = { stServer = it },
                        label = { Text("Server address (Portal URL)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = stMac,
                        onValueChange = { stMac = it },
                        label = { Text("MAC address (00:1A:79:XX:XX:XX)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "SN, Device ID 1 & Device ID 2 (D2=D1) auto-generated from MAC",
                        style = MaterialTheme.typography.labelSmall,
                        color = TvPalette.TextSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = stTv, onCheckedChange = { stTv = it })
                        Text("Include TV channels", color = TvPalette.TextPrimary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = stVod, onCheckedChange = { stVod = it })
                        Text("Include VOD", color = TvPalette.TextPrimary)
                    }
                }

                WizardStep.PROCESSING -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = TvPalette.AccentBlue)
                        Spacer(Modifier.width(16.dp))
                        Text("Syncing channels, VOD & EPG...", color = TvPalette.TextPrimary)
                    }
                }

                WizardStep.PROCESSED_SUMMARY -> {
                    Text(
                        text = "Ready to watch!",
                        style = MaterialTheme.typography.titleLarge,
                        color = TvPalette.TextPrimary
                    )
                }

                WizardStep.EPG_URL, WizardStep.NONE -> {}
            }
        }

        // Right 18% Action Column (Next / Back / Cancel)
        Column(
            modifier = Modifier
                .weight(0.18f)
                .fillMaxHeight()
                .background(TvPalette.Background)
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                WizardStep.PLAYLIST_TYPE -> {
                    TvFocusRow(title = "Cancel", onClick = onClose)
                }
                WizardStep.M3U_FORM -> {
                    TvFocusButton(
                        text = "Next",
                        isSelected = true,
                        onClick = { if (m3uUrl.isNotBlank()) onSubmitM3u(m3uName, m3uUrl, epgUrl) }
                    )
                    Spacer(Modifier.height(10.dp))
                    TvFocusButton(text = "Back", onClick = { onSelectStep(WizardStep.PLAYLIST_TYPE) })
                }
                WizardStep.XTREAM_FORM -> {
                    TvFocusButton(
                        text = "Next",
                        isSelected = true,
                        onClick = {
                            if (xcServer.isNotBlank() && xcUser.isNotBlank()) {
                                onSubmitXtream(xcServer, xcServer, xcUser, xcPass, xcTv, xcVod)
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    TvFocusButton(text = "Back", onClick = { onSelectStep(WizardStep.PLAYLIST_TYPE) })
                }
                WizardStep.STALKER_FORM -> {
                    TvFocusButton(
                        text = "Next",
                        isSelected = true,
                        onClick = {
                            if (stServer.isNotBlank() && stMac.isNotBlank()) {
                                onSubmitStalker(stServer, stServer, stMac, stTv, stVod)
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    TvFocusButton(text = "Back", onClick = { onSelectStep(WizardStep.PLAYLIST_TYPE) })
                }
                WizardStep.PROCESSED_SUMMARY -> {
                    TvFocusButton(text = "Done", isSelected = true, onClick = onClose)
                }
                else -> {}
            }
        }
    }
}
