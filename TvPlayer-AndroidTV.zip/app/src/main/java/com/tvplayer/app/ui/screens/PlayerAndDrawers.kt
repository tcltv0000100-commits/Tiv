package com.tvplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.tvplayer.app.data.model.*
import com.tvplayer.app.player.ExoPlayerController
import com.tvplayer.app.ui.components.TvFocusButton
import com.tvplayer.app.ui.components.TvFocusRow
import com.tvplayer.app.ui.components.TvToggleRow
import com.tvplayer.app.ui.components.TvVideoSurface
import com.tvplayer.app.ui.theme.TvPalette
import com.tvplayer.app.ui.viewmodel.RightDrawerType
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun FullscreenPlayerScreen(
    playback: StreamPlaybackInfo?,
    playerController: ExoPlayerController,
    settings: AppSettings,
    channels: List<ChannelEntity>,
    history: List<HistoryEntity>,
    showQuickChannels: Boolean,
    onToggleQuickChannels: () -> Unit,
    onSelectChannel: (ChannelEntity) -> Unit,
    onOpenGuide: () -> Unit,
    onOpenDrawer: (RightDrawerType) -> Unit,
    onToggleHdrBoost: () -> Unit
) {
    var showOsd by remember { mutableStateOf(true) }
    val isPlaying by playerController.isPlaying.collectAsState()
    val isBuffering by playerController.isBuffering.collectAsState()
    val videoBadge by playerController.videoBadge.collectAsState()
    val errorMsg by playerController.playerError.collectAsState()

    LaunchedEffect(showOsd) {
        if (showOsd) {
            delay(5000)
            showOsd = false
        }
    }

    val dateFmt = remember(settings.use24HourFormat) {
        SimpleDateFormat(if (settings.use24HourFormat) "EEE, d MMM, HH:mm" else "EEE, d MMM, h:mm a", Locale.US)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { showOsd = !showOsd }
    ) {
        TvVideoSurface(
            player = playerController.player,
            displayMode = settings.displayMode,
            modifier = Modifier.fillMaxSize()
        )

        if (isBuffering) {
            CircularProgressIndicator(
                color = TvPalette.AccentBlue,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (!errorMsg.isNullOrBlank()) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xCC14151A))
                    .padding(16.dp)
            ) {
                Text(text = errorMsg!!, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Quick Channel List Overlay (Left 2-column style)
        if (showQuickChannels) {
            LazyColumn(
                modifier = Modifier
                    .width(290.dp)
                    .fillMaxHeight()
                    .background(Color(0xE614151A))
                    .padding(12.dp)
            ) {
                item {
                    Text(
                        text = playback?.groupName?.ifBlank { "Channels" } ?: "Channels",
                        style = MaterialTheme.typography.titleMedium,
                        color = TvPalette.AccentBlue,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                items(channels, key = { it.id }) { ch ->
                    TvFocusRow(
                        title = "${ch.number}. ${ch.name}",
                        onClick = { onSelectChannel(ch) }
                    )
                }
            }
        }

        // OSD Overlay
        if (showOsd && playback != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x66000000))
                    .padding(24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(playback.groupName, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                    Text(dateFmt.format(Date()), style = MaterialTheme.typography.bodyMedium, color = Color.White)
                }

                // Bottom Info + Controls
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (playback.logoUrl.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp, 48.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = playback.logoUrl,
                                    contentDescription = playback.title,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize().padding(4.dp)
                                )
                            }
                            Spacer(Modifier.width(16.dp))
                        }
                        Column {
                            Text(playback.title, style = MaterialTheme.typography.titleLarge, color = Color.White)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (videoBadge.isNotBlank()) {
                                    BadgeChip(videoBadge)
                                }
                                if (settings.hdrColorBoost) {
                                    BadgeChip("HDR BOOST")
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { if (playback.isLive) 1f else 0.35f },
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                        color = TvPalette.AccentBlue,
                        trackColor = Color(0x55FFFFFF)
                    )
                    Spacer(Modifier.height(12.dp))

                    // Quick Action Bar
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        item { OsdActionChip("TV guide", Icons.Default.List) { onOpenGuide() } }
                        item { OsdActionChip("Channels", Icons.Default.Tv) { onToggleQuickChannels() } }
                        item {
                            OsdActionChip(
                                if (isPlaying) "Pause" else "Play",
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow
                            ) { playerController.togglePlayPause() }
                        }
                        if (!playback.isLive) {
                            item { OsdActionChip("-10s", Icons.Default.Replay10) { playerController.seekBy(-10_000L) } }
                            item { OsdActionChip("+10s", Icons.Default.Forward10) { playerController.seekBy(10_000L) } }
                        }
                        item { OsdActionChip("Video tracks", Icons.Default.HighQuality) { onOpenDrawer(RightDrawerType.VIDEO_TRACKS) } }
                        item { OsdActionChip("Audio tracks", Icons.Default.Audiotrack) { onOpenDrawer(RightDrawerType.AUDIO_TRACKS) } }
                        item { OsdActionChip("Closed captions", Icons.Default.ClosedCaption) { onOpenDrawer(RightDrawerType.CAPTIONS) } }
                        item { OsdActionChip("Display mode", Icons.Default.AspectRatio) { onOpenDrawer(RightDrawerType.DISPLAY_MODE) } }
                        item {
                            OsdActionChip(
                                if (settings.hdrColorBoost) "HDR: ON" else "HDR: OFF",
                                Icons.Default.AutoAwesome
                            ) { onToggleHdrBoost() }
                        }
                        item { OsdActionChip("Settings", Icons.Default.Settings) { onOpenDrawer(RightDrawerType.SETTINGS) } }
                    }

                    if (history.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(history.take(6), key = { it.id }) { h ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xCC1B1C21))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(h.title, color = Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BadgeChip(label: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0x883A3D47))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun OsdActionChip(label: String, icon: ImageVector, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (focused) TvPalette.FocusWhite else Color(0xCC1B1C21))
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (focused) TvPalette.FocusTextDark else Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (focused) TvPalette.FocusTextDark else Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
fun RightSideDrawerHost(
    drawerType: RightDrawerType,
    settings: AppSettings,
    playlists: List<PlaylistEntity>,
    playerController: ExoPlayerController,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onAddPlaylist: () -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onSyncXmltv: (String) -> Unit,
    onToggleHdrBoost: () -> Unit,
    onClose: () -> Unit
) {
    if (drawerType == RightDrawerType.NONE) return
    var settingsSubMenu by remember(drawerType) { mutableStateOf("ROOT") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable { onClose() },
        contentAlignment = Alignment.CenterEnd
    ) {
        Column(
            modifier = Modifier
                .width(340.dp)
                .fillMaxHeight()
                .background(TvPalette.Surface)
                .clickable(enabled = false) {}
                .padding(vertical = 16.dp)
        ) {
            when (drawerType) {
                RightDrawerType.VIDEO_TRACKS -> {
                    val tracks by playerController.videoTracks.collectAsState()
                    DrawerHeader("Video tracks")
                    LazyColumn {
                        items(tracks) { t ->
                            TvFocusRow(
                                title = t.label,
                                trailing = { RadioButton(selected = t.isSelected, onClick = null) },
                                onClick = { playerController.selectTrack(t); onClose() }
                            )
                        }
                    }
                }
                RightDrawerType.AUDIO_TRACKS -> {
                    val tracks by playerController.audioTracks.collectAsState()
                    DrawerHeader("Audio tracks")
                    LazyColumn {
                        items(tracks) { t ->
                            TvFocusRow(
                                title = t.label,
                                trailing = { RadioButton(selected = t.isSelected, onClick = null) },
                                onClick = { playerController.selectTrack(t); onClose() }
                            )
                        }
                    }
                }
                RightDrawerType.CAPTIONS -> {
                    val tracks by playerController.textTracks.collectAsState()
                    DrawerHeader("Closed captions")
                    LazyColumn {
                        items(tracks) { t ->
                            TvFocusRow(
                                title = t.label,
                                trailing = { RadioButton(selected = t.isSelected, onClick = null) },
                                onClick = { playerController.selectTrack(t); onClose() }
                            )
                        }
                    }
                }
                RightDrawerType.DISPLAY_MODE -> {
                    DrawerHeader("Display mode")
                    LazyColumn {
                        items(DisplayModeOption.entries) { mode ->
                            TvFocusRow(
                                title = mode.label,
                                trailing = { RadioButton(selected = settings.displayMode == mode, onClick = null) },
                                onClick = { onUpdateSettings { it.copy(displayMode = mode) }; onClose() }
                            )
                        }
                    }
                }
                RightDrawerType.SORTING -> {
                    DrawerHeader("Sorting")
                    LazyColumn {
                        items(VodSortOrder.entries) { order ->
                            TvFocusRow(
                                title = order.label,
                                trailing = { RadioButton(selected = settings.vodSortOrder == order, onClick = null) },
                                onClick = { onUpdateSettings { it.copy(vodSortOrder = order) }; onClose() }
                            )
                        }
                    }
                }
                RightDrawerType.SETTINGS -> {
                    DrawerHeader(if (settingsSubMenu == "ROOT") "Settings" else settingsSubMenu)
                    LazyColumn {
                        when (settingsSubMenu) {
                            "ROOT" -> {
                                item {
                                    TvFocusRow("General", onClick = { settingsSubMenu = "General" })
                                    TvFocusRow("Playlists", subtitle = "${playlists.size} added", onClick = { settingsSubMenu = "Playlists" })
                                    TvFocusRow("EPG", onClick = { settingsSubMenu = "EPG" })
                                    TvFocusRow("Appearance", onClick = { settingsSubMenu = "Appearance" })
                                    TvFocusRow("Playback", onClick = { settingsSubMenu = "Playback" })
                                    TvFocusRow("About", subtitle = "v1.0.0", onClick = { settingsSubMenu = "About" })
                                }
                            }
                            "General" -> {
                                item {
                                    TvToggleRow("Auto start app on boot", checked = settings.autoStartOnBoot) { v -> onUpdateSettings { it.copy(autoStartOnBoot = v) } }
                                    TvToggleRow("Turn on last channel on app start", checked = settings.turnOnLastChannel) { v -> onUpdateSettings { it.copy(turnOnLastChannel = v) } }
                                    TvToggleRow("Confirm exit by second press Back", checked = settings.confirmExitOnBack) { v -> onUpdateSettings { it.copy(confirmExitOnBack = v) } }
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                            "Playlists" -> {
                                items(playlists, key = { it.id }) { pl ->
                                    TvFocusRow(
                                        title = pl.name,
                                        subtitle = "${pl.type.name} • Ch: ${pl.channelCount}, Mv: ${pl.movieCount}, Sh: ${pl.showCount}",
                                        onClick = { onDeletePlaylist(pl.id) }
                                    )
                                }
                                item {
                                    TvFocusRow("Add playlist", onClick = onAddPlaylist)
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                            "EPG" -> {
                                item {
                                    TvToggleRow("Store program descriptions", checked = settings.storeProgramDescriptions) { v -> onUpdateSettings { it.copy(storeProgramDescriptions = v) } }
                                    TvToggleRow("Update on app start", checked = settings.epgUpdateOnStart) { v -> onUpdateSettings { it.copy(epgUpdateOnStart = v) } }
                                    TvFocusRow("Update EPG now", onClick = {
                                        playlists.mapNotNull { it.epgUrl.ifBlank { null } }.forEach(onSyncXmltv)
                                    })
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                            "Appearance" -> {
                                item {
                                    TvToggleRow("Show channel numbers", checked = settings.showChannelNumbers) { v -> onUpdateSettings { it.copy(showChannelNumbers = v) } }
                                    TvToggleRow("Show channel names", checked = settings.showChannelNames) { v -> onUpdateSettings { it.copy(showChannelNames = v) } }
                                    TvToggleRow("Use 24-hour format", checked = settings.use24HourFormat) { v -> onUpdateSettings { it.copy(use24HourFormat = v) } }
                                    FontSizeScale.entries.forEach { fs ->
                                        TvFocusRow(
                                            title = "Font size: ${fs.label}",
                                            trailing = { RadioButton(selected = settings.fontSizeScale == fs, onClick = null) },
                                            onClick = { onUpdateSettings { it.copy(fontSizeScale = fs) } }
                                        )
                                    }
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                            "Playback" -> {
                                item {
                                    TvToggleRow("HDR Color Boost (Vivid)", subtitle = "ON by default for richer colors", checked = settings.hdrColorBoost) {
                                        onToggleHdrBoost()
                                    }
                                    TvToggleRow("Hardware video decoder", checked = settings.hardwareVideoDecoder) { v -> onUpdateSettings { it.copy(hardwareVideoDecoder = v) } }
                                    TvToggleRow("Auto frame rate (AFR)", checked = settings.autoFrameRate) { v -> onUpdateSettings { it.copy(autoFrameRate = v) } }
                                    BufferPreset.entries.forEach { bp ->
                                        TvFocusRow(
                                            title = "Buffer: ${bp.label}",
                                            trailing = { RadioButton(selected = settings.bufferPreset == bp, onClick = null) },
                                            onClick = {
                                                onUpdateSettings { it.copy(bufferPreset = bp) }
                                                playerController.updateBufferPreset(bp)
                                            }
                                        )
                                    }
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                            "About" -> {
                                item {
                                    TvFocusRow("Version", subtitle = "1.0.0 (Media3 + Stalker/XC/M3U)", onClick = {})
                                    TvFocusRow("Back", onClick = { settingsSubMenu = "ROOT" })
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun DrawerHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        color = TvPalette.TextPrimary,
        modifier = Modifier
            .fillMaxWidth()
            .background(TvPalette.SurfaceElevated)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    )
}

@Composable
fun SearchScreen(
    query: String,
    results: Triple<List<ChannelEntity>, List<VodEntity>, List<VodEntity>>,
    onQueryChange: (String) -> Unit,
    onChannelClick: (ChannelEntity) -> Unit,
    onVodClick: (VodEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background)
            .padding(24.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            label = { Text("Search TV, Movies, Shows...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        val (chs, mvs, shs) = results
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (chs.isNotEmpty()) {
                item { Text("TV Channels", style = MaterialTheme.typography.titleMedium, color = TvPalette.AccentBlue) }
                items(chs, key = { "c_${it.id}" }) { ch ->
                    TvFocusRow(title = ch.name, subtitle = ch.groupName, onClick = { onChannelClick(ch) })
                }
            }
            if (mvs.isNotEmpty()) {
                item { Text("Movies", style = MaterialTheme.typography.titleMedium, color = TvPalette.AccentBlue) }
                items(mvs, key = { "m_${it.id}" }) { m ->
                    TvFocusRow(title = m.title, subtitle = m.groupName, onClick = { onVodClick(m) })
                }
            }
            if (shs.isNotEmpty()) {
                item { Text("Shows", style = MaterialTheme.typography.titleMedium, color = TvPalette.AccentBlue) }
                items(shs, key = { "s_${it.id}" }) { s ->
                    TvFocusRow(title = s.title, subtitle = s.groupName, onClick = { onVodClick(s) })
                }
            }
        }
    }
}
