package com.tvplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.tvplayer.app.data.model.ContentType
import com.tvplayer.app.data.model.SeriesEpisode
import com.tvplayer.app.data.model.SeriesSeason
import com.tvplayer.app.data.model.VodEntity
import com.tvplayer.app.ui.components.TvFocusButton
import com.tvplayer.app.ui.theme.TvPalette

@Composable
fun VodCatalogScreen(
    items: List<VodEntity>,
    categoryTitle: String,
    onSearchClick: () -> Unit,
    onSortClick: () -> Unit,
    onItemClick: (VodEntity) -> Unit
) {
    var focusedItem by remember(items) { mutableStateOf(items.firstOrNull()) }
    var focusedIdx by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        // Top Hero Info
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(0.78f)) {
                val hero = focusedItem
                Text(
                    text = hero?.title ?: categoryTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TvPalette.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                if (hero != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (hero.rating.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TvPalette.SurfaceElevated)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(hero.rating, style = MaterialTheme.typography.labelSmall, color = TvPalette.TextPrimary)
                            }
                        }
                        val meta = listOfNotNull(
                            hero.year.ifBlank { null },
                            hero.duration.ifBlank { null },
                            hero.genre.ifBlank { null }
                        ).joinToString(" • ")
                        if (meta.isNotBlank()) {
                            Text(meta, style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary)
                        }
                    }
                    if (hero.cast.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Cast: ${hero.cast}", style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (hero.director.isNotBlank()) {
                        Text("Director: ${hero.director}", style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (hero.plot.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(hero.plot, style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = onSearchClick) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = TvPalette.TextPrimary)
                }
                IconButton(onClick = onSortClick) {
                    Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort", tint = TvPalette.TextPrimary)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = categoryTitle, style = MaterialTheme.typography.titleMedium, color = TvPalette.TextPrimary)
            if (items.isNotEmpty()) {
                Text(text = "${focusedIdx + 1} / ${items.size}", style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary)
            }
        }
        Spacer(Modifier.height(10.dp))

        // 2:3 Poster Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 128.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(items, key = { _, item -> item.id }) { idx, vod ->
                VodPosterCard(
                    vod = vod,
                    onFocused = {
                        focusedItem = vod
                        focusedIdx = idx
                    },
                    onClick = { onItemClick(vod) }
                )
            }
        }
    }
}

@Composable
private fun VodPosterCard(
    vod: VodEntity,
    onFocused: () -> Unit,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .then(
                if (focused) Modifier.border(2.dp, TvPalette.FocusWhite, RoundedCornerShape(6.dp))
                else Modifier
            )
            .background(TvPalette.SurfaceElevated)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .focusable()
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .background(TvPalette.Surface)
        ) {
            if (vod.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = vod.posterUrl,
                    contentDescription = vod.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (vod.rating.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(TvPalette.AccentBlue)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = vod.rating.take(3),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (focused) TvPalette.FocusWhite else Color(0xFF1F2026))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                text = vod.title,
                color = if (focused) TvPalette.FocusTextDark else TvPalette.TextPrimary,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun VodDetailScreen(
    vod: VodEntity,
    seasons: List<SeriesSeason>,
    loadingSeries: Boolean,
    onPlayMovie: () -> Unit,
    onPlayEpisode: (SeriesEpisode) -> Unit,
    onToggleMyList: () -> Unit,
    onBack: () -> Unit
) {
    var selectedSeasonIdx by remember { mutableIntStateOf(0) }
    val activeSeason = seasons.getOrNull(selectedSeasonIdx)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TvPalette.Background)
            .padding(32.dp)
    ) {
        Text(text = vod.title, style = MaterialTheme.typography.headlineMedium, color = TvPalette.TextPrimary)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (vod.rating.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TvPalette.SurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(vod.rating, style = MaterialTheme.typography.labelSmall, color = TvPalette.TextPrimary)
                }
            }
            val meta = listOfNotNull(
                vod.year.ifBlank { null },
                if (vod.contentType == ContentType.SHOW && seasons.isNotEmpty()) "${seasons.size} seasons" else vod.duration.ifBlank { null },
                vod.genre.ifBlank { null }
            ).joinToString(" • ")
            Text(meta, style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary)
        }
        if (vod.cast.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text("Cast: ${vod.cast}", style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary, maxLines = 2)
        }
        if (vod.plot.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(vod.plot, style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary, maxLines = 4, overflow = TextOverflow.Ellipsis)
        }

        Spacer(Modifier.height(24.dp))

        // Action Buttons Row
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (vod.contentType == ContentType.MOVIE) {
                TvFocusButton(text = "Play", isSelected = true, onClick = onPlayMovie)
            } else {
                val firstEp = activeSeason?.episodes?.firstOrNull()
                TvFocusButton(
                    text = if (firstEp != null) "Play S${activeSeason.seasonNumber} E${firstEp.episodeNumber}" else "Play S1 E1",
                    isSelected = true,
                    onClick = { if (firstEp != null) onPlayEpisode(firstEp) }
                )
            }
            TvFocusButton(
                text = if (vod.isInMyList) "Remove from My list" else "Add to My list",
                onClick = onToggleMyList
            )
            TvFocusButton(text = "Back", onClick = onBack)
        }

        if (vod.contentType == ContentType.SHOW) {
            Spacer(Modifier.height(24.dp))
            if (loadingSeries) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(color = TvPalette.AccentBlue, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Loading seasons & episodes...", color = TvPalette.TextSecondary)
                }
            } else if (seasons.isNotEmpty()) {
                // Season Tabs
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(seasons) { idx, season ->
                        TvFocusButton(
                            text = season.name,
                            isSelected = idx == selectedSeasonIdx,
                            onClick = { selectedSeasonIdx = idx }
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                val eps = activeSeason?.episodes.orEmpty()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(activeSeason?.name ?: "Season 1", style = MaterialTheme.typography.titleMedium, color = TvPalette.TextPrimary)
                    Text("1 / ${eps.size}", style = MaterialTheme.typography.bodyMedium, color = TvPalette.TextSecondary)
                }
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(eps, key = { it.id }) { ep ->
                        var epFocused by remember { mutableStateOf(false) }
                        Column(
                            modifier = Modifier
                                .width(200.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .then(if (epFocused) Modifier.border(2.dp, TvPalette.FocusWhite, RoundedCornerShape(6.dp)) else Modifier)
                                .background(TvPalette.SurfaceElevated)
                                .onFocusChanged { epFocused = it.isFocused }
                                .focusable()
                                .clickable { onPlayEpisode(ep) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(112.dp)
                                    .background(TvPalette.Surface),
                                contentAlignment = Alignment.Center
                            ) {
                                if (ep.thumbnailUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = ep.thumbnailUrl,
                                        contentDescription = ep.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TvPalette.TextSecondary)
                                }
                            }
                            Text(
                                text = "E${ep.episodeNumber} • ${ep.title}",
                                color = TvPalette.TextPrimary,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
