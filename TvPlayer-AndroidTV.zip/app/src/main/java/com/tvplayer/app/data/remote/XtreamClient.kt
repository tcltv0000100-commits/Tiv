package com.tvplayer.app.data.remote

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.tvplayer.app.data.model.SeriesEpisode
import com.tvplayer.app.data.model.SeriesSeason
import com.tvplayer.app.data.network.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

data class XtreamCategory(val id: String, val name: String)

data class XtreamLiveStream(
    val streamId: String,
    val num: Int,
    val name: String,
    val icon: String,
    val epgChannelId: String,
    val categoryId: String,
    val catchupDays: Int
)

data class XtreamVodItem(
    val id: String,
    val title: String,
    val categoryId: String,
    val icon: String,
    val rating: String,
    val containerExtension: String,
    val added: Long
)

data class XtreamSeriesItem(
    val seriesId: String,
    val title: String,
    val categoryId: String,
    val cover: String,
    val plot: String,
    val cast: String,
    val director: String,
    val genre: String,
    val releaseDate: String,
    val rating: String
)

class XtreamClient {
    private val client = HttpClientProvider.client
    private val gson = Gson()

    private fun normalizeBase(server: String): String {
        var s = server.trim().removeSuffix("/")
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "http://$s"
        }
        return s
    }

    private suspend fun getJson(url: String, userAgent: String = ""): String? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent.ifBlank { "Mozilla/5.0" })
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext null
            resp.body?.string()
        }
    }

    suspend fun authenticate(server: String, user: String, pass: String, userAgent: String = ""): Boolean {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass", userAgent) ?: return false
        return try {
            val obj = JsonParser.parseString(raw).asJsonObject
            val userInfo = obj.getAsJsonObject("user_info") ?: return false
            val auth = userInfo.get("auth")?.asInt ?: 0
            auth == 1
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getCategories(server: String, user: String, pass: String, action: String): List<XtreamCategory> {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass&action=$action") ?: return emptyList()
        return try {
            val arr = JsonParser.parseString(raw).asJsonArray
            arr.mapNotNull { el ->
                val o = el.asJsonObject
                val id = o.get("category_id")?.asString ?: return@mapNotNull null
                val name = o.get("category_name")?.asString ?: "General"
                XtreamCategory(id, name)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getLiveStreams(server: String, user: String, pass: String): List<XtreamLiveStream> {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams") ?: return emptyList()
        return try {
            val arr = JsonParser.parseString(raw).asJsonArray
            arr.mapIndexedNotNull { idx, el ->
                val o = el.asJsonObject
                val sid = o.get("stream_id")?.asString ?: return@mapIndexedNotNull null
                XtreamLiveStream(
                    streamId = sid,
                    num = o.get("num")?.asInt ?: (idx + 1),
                    name = o.get("name")?.asString ?: "Channel $sid",
                    icon = o.get("stream_icon")?.asString ?: "",
                    epgChannelId = o.get("epg_channel_id")?.asString ?: "",
                    categoryId = o.get("category_id")?.asString ?: "",
                    catchupDays = o.get("tv_archive_duration")?.asInt ?: 0
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getVodStreams(server: String, user: String, pass: String): List<XtreamVodItem> {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass&action=get_vod_streams") ?: return emptyList()
        return try {
            val arr = JsonParser.parseString(raw).asJsonArray
            arr.mapNotNull { el ->
                val o = el.asJsonObject
                val sid = o.get("stream_id")?.asString ?: return@mapNotNull null
                XtreamVodItem(
                    id = sid,
                    title = o.get("name")?.asString ?: "Movie $sid",
                    categoryId = o.get("category_id")?.asString ?: "",
                    icon = o.get("stream_icon")?.asString ?: "",
                    rating = o.get("rating")?.asString ?: "",
                    containerExtension = o.get("container_extension")?.asString ?: "mp4",
                    added = o.get("added")?.asString?.toLongOrNull() ?: 0L
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getSeries(server: String, user: String, pass: String): List<XtreamSeriesItem> {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass&action=get_series") ?: return emptyList()
        return try {
            val arr = JsonParser.parseString(raw).asJsonArray
            arr.mapNotNull { el ->
                val o = el.asJsonObject
                val sid = o.get("series_id")?.asString ?: return@mapNotNull null
                XtreamSeriesItem(
                    seriesId = sid,
                    title = o.get("name")?.asString ?: "Series $sid",
                    categoryId = o.get("category_id")?.asString ?: "",
                    cover = o.get("cover")?.asString ?: "",
                    plot = o.get("plot")?.asString ?: "",
                    cast = o.get("cast")?.asString ?: "",
                    director = o.get("director")?.asString ?: "",
                    genre = o.get("genre")?.asString ?: "",
                    releaseDate = o.get("releaseDate")?.asString ?: "",
                    rating = o.get("rating")?.asString ?: ""
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getSeriesInfo(server: String, user: String, pass: String, seriesId: String): List<SeriesSeason> {
        val base = normalizeBase(server)
        val raw = getJson("$base/player_api.php?username=$user&password=$pass&action=get_series_info&series_id=$seriesId")
            ?: return emptyList()
        return try {
            val obj = JsonParser.parseString(raw).asJsonObject
            val episodesObj = obj.getAsJsonObject("episodes") ?: return emptyList()
            val result = mutableListOf<SeriesSeason>()
            for ((seasonKey, epElement) in episodesObj.entrySet()) {
                val seasonNum = seasonKey.toIntOrNull() ?: 1
                val epArray: JsonArray = if (epElement.isJsonArray) epElement.asJsonArray else continue
                val episodes = epArray.mapIndexedNotNull { idx, item ->
                    val eo = item.asJsonObject
                    val epId = eo.get("id")?.asString ?: return@mapIndexedNotNull null
                    val ext = eo.get("container_extension")?.asString ?: "mp4"
                    val info = if (eo.has("info") && eo.get("info").isJsonObject) eo.getAsJsonObject("info") else null
                    val epNum = eo.get("episode_num")?.asInt ?: (idx + 1)
                    SeriesEpisode(
                        id = epId,
                        episodeNumber = epNum,
                        title = eo.get("title")?.asString ?: "Episode $epNum",
                        plot = info?.get("plot")?.asString ?: "",
                        duration = info?.get("duration")?.asString ?: "",
                        thumbnailUrl = info?.get("movie_image")?.asString ?: "",
                        streamUrl = "$base/series/$user/$pass/$epId.$ext",
                        containerExtension = ext
                    )
                }.sortedBy { it.episodeNumber }
                result.add(
                    SeriesSeason(
                        seasonNumber = seasonNum,
                        seasonId = seasonKey,
                        name = "Season $seasonNum",
                        episodes = episodes
                    )
                )
            }
            result.sortedBy { it.seasonNumber }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun buildLiveUrl(server: String, user: String, pass: String, streamId: String, outputFormat: String): String {
        val base = normalizeBase(server)
        val ext = if (outputFormat == "m3u8") "m3u8" else "ts"
        return "$base/live/$user/$pass/$streamId.$ext"
    }

    fun buildVodUrl(server: String, user: String, pass: String, streamId: String, ext: String): String {
        val base = normalizeBase(server)
        val cleanExt = ext.ifBlank { "mp4" }
        return "$base/movie/$user/$pass/$streamId.$cleanExt"
    }

    fun buildXmltvUrl(server: String, user: String, pass: String): String {
        val base = normalizeBase(server)
        return "$base/xmltv.php?username=$user&password=$pass"
    }
}
