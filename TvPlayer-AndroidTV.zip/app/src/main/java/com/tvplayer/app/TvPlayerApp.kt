package com.tvplayer.app

import android.app.Application
import android.content.Intent
import com.tvplayer.app.data.model.SettingsStore
import com.tvplayer.app.data.repository.IptvRepository
import java.io.PrintWriter
import java.io.StringWriter

class TvPlayerApp : Application() {
    lateinit var settingsStore: SettingsStore
        private set
    lateinit var repository: IptvRepository
        private set

    override fun onCreate() {
        super.onCreate()

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val intent = Intent(this, CrashActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    putExtra("stacktrace", sw.toString())
                }
                startActivity(intent)
                android.os.Process.killProcess(android.os.Process.myPid())
            } catch (_: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }

        settingsStore = SettingsStore(this)
        repository = IptvRepository(this)
    }
}
