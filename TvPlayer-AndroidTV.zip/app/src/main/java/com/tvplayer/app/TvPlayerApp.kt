package com.tvplayer.app

import android.app.Application
import com.tvplayer.app.data.model.SettingsStore
import com.tvplayer.app.data.repository.IptvRepository

class TvPlayerApp : Application() {
    lateinit var settingsStore: SettingsStore
        private set
    lateinit var repository: IptvRepository
        private set

    override fun onCreate() {
        super.onCreate()
        settingsStore = SettingsStore(this)
        repository = IptvRepository(this)
    }
}
