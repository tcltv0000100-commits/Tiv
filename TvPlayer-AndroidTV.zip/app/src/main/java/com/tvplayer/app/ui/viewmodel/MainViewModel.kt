package com.tvplayer.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvplayer.app.TvPlayerApp
import com.tvplayer.app.data.model.*
import com.tvplayer.app.data.repository.SyncProgress
import com.tvplayer.app.player.ExoPlayerController
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class NavSection { SEARCH, TV, MOVIES, SHOWS, RECORDINGS, MY_LIST, SETTINGS }
enum class WizardStep { NONE, PLAYLIST_TYPE, M3U_FORM, XTREAM_FORM, STALKER_FORM, PROCESSING, PROCESSED_SUMMARY, EPG_URL }
enum class RightDrawerType { NONE, SETTINGS, CONTEXT_MENU, VIDEO_TRACKS, AUDIO_TRACKS, CAPTIONS, DISPLAY_MODE, SORTING }

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as TvPlayerApp
    val repo = app.repository
    val settingsStore = app.settingsStore
    val playerController = ExoPlayerController(application)

    val settings: StateFlow<AppSettings> = settingsStore.settings
    val playlists: StateFlow<List<PlaylistEntity>> = repo.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSection = MutableStateFlow(NavSection.TV)
    val currentSection: StateFlow<NavSection> = _currentSection.asStateFlow()

    private val _selectedGroupId = MutableStateFlow<Long?>(null) // null = All, -1 = Favorites/MyList
    val selectedGroupId: StateFlow<Long?> = _selectedGroupId.asStateFlow()

    private val _selectedPlaylistFilterId = MutableStateFlow<Long?>(null)
    val selectedPlaylistFilterId: StateFlow<Long?> = _selectedPlaylistFilterId.asStateFlow()

    private val _wizardStep = MutableStateFlow(WizardStep.NONE)
    val wizardStep: StateFlow<WizardStep> = _wizardStep.asStateFlow()

    private val _syncProgress = MutableStateFlow(SyncProgress())
    val syncProgress: StateFlow<SyncProgress> = _syncProgress.asStateFlow()

    private val _rightDrawer = MutableStateFlow(RightDrawerType.NONE)
    val rightDrawer: StateFlow<RightDrawerType> = _rightDrawer.asStateFlow()

    private val _isFullscreenPlayer = MutableStateFlow(false)
    val isFullscreenPlayer: StateFlow<Boolean> = _isFullscreenPlayer.asStateFlow()

    private val _showQuickChannelOverlay = MutableStateFlow(false)
    val showQuickChannelOverlay: StateFlow<Boolean> = _showQuickChannelOverlay.asStateFlow()

    private val _activePlayback = MutableStateFlow<StreamPlaybackInfo?>(null)
    val activePlayback: StateFlow<StreamPlaybackInfo?> = _activePlayback.asStateFlow()

    private val _activeChannel = MutableStateFlow<ChannelEntity?>(null)
    val activeChannel: StateFlow<ChannelEntity?> = _activeChannel.asStateFlow()

    private val _selectedVodDetail = MutableStateFlow<VodEntity?>(null)
    val selectedVodDetail: StateFlow<VodEntity?> = _selectedVodDetail.asStateFlow()

    private val _seriesSeasons = MutableStateFlow<List<SeriesSeason>>(emptyList())
    val seriesSeasons: StateFlow<List<SeriesSeason>> = _seriesSeasons.asStateFlow()

    private val _loadingSeries = MutableStateFlow(false)
    val loadingSeries: StateFlow<Boolean> = _loadingSeries.asStateFlow()

    private val _epgMap = MutableStateFlow<Map<String, List<EpgProgramEntity>>>(emptyMap())
    val epgMap: StateFlow<Map<String, List<EpgProgramEntity>>> = _epgMap.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<Triple<List<ChannelEntity>, List<VodEntity>, List<VodEntity>>>(
        Triple(emptyList(), emptyList(), emptyList())
    )
    val searchResults: StateFlow<Triple<List<ChannelEntity>, List<VodEntity>, List<VodEntity>>> = _searchResults.asStateFlow()

    val liveGroups: StateFlow<List<GroupEntity>> = repo.observeGroups(ContentType.LIVE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val movieGroups: StateFlow<List<GroupEntity>> = repo.observeGroups(ContentType.MOVIE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val showGroups: StateFlow<List<GroupEntity>> = repo.observeGroups(ContentType.SHOW)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val displayedChannels: StateFlow<List<ChannelEntity>> = combine(
        _selectedGroupId,
        _selectedPlaylistFilterId
    ) { gId, pId -> gId to pId }.flatMapLatest { (gId, pId) ->
        when {
            gId == -1L -> repo.observeFavoriteChannels()
            gId != null -> repo.observeChannelsByGroup(gId)
            pId != null -> repo.observeChannelsByPlaylist(pId)
            else -> repo.observeAllChannels()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val displayedMovies: StateFlow<List<VodEntity>> = combine(
        _selectedGroupId,
        _selectedPlaylistFilterId,
        settings
    ) { gId, pId, s -> Triple(gId, pId, s.vodSortOrder) }.flatMapLatest { (gId, pId, sortOrder) ->
        val flow = when {
            gId == -1L -> repo.observeMyList(ContentType.MOVIE)
            gId != null -> repo.observeVodByGroup(gId, ContentType.MOVIE)
            pId != null -> repo.observeVodByPlaylist(pId, ContentType.MOVIE)
            else -> repo.observeAllVod(ContentType.MOVIE)
        }
        flow.map { list -> sortVod(list, sortOrder) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val displayedShows: StateFlow<List<VodEntity>> = combine(
        _selectedGroupId,
        _selectedPlaylistFilterId,
        settings
    ) { gId, pId, s -> Triple(gId, pId, s.vodSortOrder) }.flatMapLatest { (gId, pId, sortOrder) ->
        val flow = when {
            gId == -1L -> repo.observeMyList(ContentType.SHOW)
            gId != null -> repo.observeVodByGroup(gId, ContentType.SHOW)
            pId != null -> repo.observeVodByPlaylist(pId, ContentType.SHOW)
            else -> repo.observeAllVod(ContentType.SHOW)
        }
        flow.map { list -> sortVod(list, sortOrder) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val channelHistory: StateFlow<List<HistoryEntity>> = repo.observeHistory(ContentType.LIVE)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun sortVod(list: List<VodEntity>, order: VodSortOrder): List<VodEntity> = when (order) {
        VodSortOrder.PLAYLIST -> list
        VodSortOrder.NAME -> list.sortedBy { it.title.lowercase() }
        VodSortOrder.RATING -> list.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
        VodSortOrder.DATE_ADDED -> list.sortedByDescending { it.addedAtMs }
    }

    fun acceptTerms() {
        settingsStore.update { it.copy(termsAccepted = true) }
    }

    fun selectSection(section: NavSection) {
        _currentSection.value = section
        _selectedGroupId.value = null
        _selectedPlaylistFilterId.value = null
        _selectedVodDetail.value = null
        _rightDrawer.value = if (section == NavSection.SETTINGS) RightDrawerType.SETTINGS else RightDrawerType.NONE
    }

    fun selectGroup(groupId: Long?, playlistId: Long? = null) {
        _selectedGroupId.value = groupId
        _selectedPlaylistFilterId.value = playlistId
    }

    fun openWizard(step: WizardStep) {
        _wizardStep.value = step
        _syncProgress.value = SyncProgress()
    }

    fun openDrawer(drawer: RightDrawerType) {
        _rightDrawer.value = drawer
    }

    fun submitM3u(name: String, url: String, epgUrl: String) {
        viewModelScope.launch {
            _wizardStep.value = WizardStep.PROCESSING
            _syncProgress.value = SyncProgress(isProcessing = true, message = "Processing...")
            val res = repo.addM3uPlaylist(name, url, epgUrl)
            _syncProgress.value = res
            _wizardStep.value = if (res.error == null) WizardStep.PROCESSED_SUMMARY else WizardStep.M3U_FORM
        }
    }

    fun submitXtream(name: String, server: String, user: String, pass: String, includeTv: Boolean, includeVod: Boolean) {
        viewModelScope.launch {
            _wizardStep.value = WizardStep.PROCESSING
            _syncProgress.value = SyncProgress(isProcessing = true, message = "Processing...")
            val res = repo.addXtreamPlaylist(name, server, user, pass, includeTv, includeVod)
            _syncProgress.value = res
            _wizardStep.value = if (res.error == null) WizardStep.PROCESSED_SUMMARY else WizardStep.XTREAM_FORM
        }
    }

    fun submitStalker(name: String, server: String, mac: String, includeTv: Boolean, includeVod: Boolean) {
        viewModelScope.launch {
            _wizardStep.value = WizardStep.PROCESSING
            _syncProgress.value = SyncProgress(isProcessing = true, message = "Processing...")
            val res = repo.addStalkerPlaylist(name, server, mac, includeTv, includeVod)
            _syncProgress.value = res
            _wizardStep.value = if (res.error == null) WizardStep.PROCESSED_SUMMARY else WizardStep.STALKER_FORM
        }
    }

    fun playChannel(channel: ChannelEntity, fullscreen: Boolean) {
        _activeChannel.value = channel
        _isFullscreenPlayer.value = fullscreen
        _showQuickChannelOverlay.value = false
        viewModelScope.launch {
            val info = repo.resolveChannelPlayback(channel) ?: return@launch
            _activePlayback.value = info
            playerController.play(info, settings.value.hdrColorBoost)
            repo.recordHistory(ContentType.LIVE, channel.id, channel.playlistId, channel.name, channel.groupName, channel.logoUrl, info.url)
        }
    }

    fun openVodDetail(vod: VodEntity) {
        _selectedVodDetail.value = vod
        if (vod.contentType == ContentType.SHOW) {
            _loadingSeries.value = true
            _seriesSeasons.value = emptyList()
            viewModelScope.launch {
                _seriesSeasons.value = repo.loadSeriesSeasons(vod)
                _loadingSeries.value = false
            }
        }
    }

    fun closeVodDetail() {
        _selectedVodDetail.value = null
    }

    fun playVod(vod: VodEntity, episode: SeriesEpisode? = null) {
        _isFullscreenPlayer.value = true
        viewModelScope.launch {
            val info = repo.resolveVodPlayback(vod, episode) ?: return@launch
            _activePlayback.value = info
            playerController.play(info, settings.value.hdrColorBoost)
            repo.recordHistory(vod.contentType, vod.id, vod.playlistId, info.title, vod.groupName, vod.posterUrl, info.url)
        }
    }

    fun exitFullscreenToGuide() {
        _isFullscreenPlayer.value = false
        _rightDrawer.value = RightDrawerType.NONE
        _showQuickChannelOverlay.value = false
    }

    fun toggleQuickChannelOverlay() {
        _showQuickChannelOverlay.value = !_showQuickChannelOverlay.value
    }

    fun toggleHdrColorBoost() {
        val next = !settings.value.hdrColorBoost
        settingsStore.update { it.copy(hdrColorBoost = next) }
        playerController.setHdrColorBoost(next)
    }

    fun loadEpgWindow(channels: List<ChannelEntity>) {
        val tvgIds = channels.take(40).mapNotNull { it.tvgId.ifBlank { null } }.distinct()
        if (tvgIds.isEmpty()) return
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            _epgMap.value = repo.getEpgForChannels(tvgIds, now - 2 * 3600_000L, now + 8 * 3600_000L)
        }
    }

    fun updateSearch(q: String) {
        _searchQuery.value = q
        viewModelScope.launch {
            _searchResults.value = repo.searchAll(q)
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerController.release()
    }
}
