package com.tvplayer.app.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.tvplayer.app.data.model.BufferPreset
import com.tvplayer.app.data.model.StreamPlaybackInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TrackOption(
    val id: String,
    val label: String,
    val groupIndex: Int,
    val trackIndex: Int,
    val isSelected: Boolean
)

@OptIn(UnstableApi::class)
class ExoPlayerController(private val context: Context) {
    private val trackSelector = DefaultTrackSelector(context)
    private var currentBufferPreset = BufferPreset.SMALL
    var player: ExoPlayer = createPlayer(currentBufferPreset)
        private set

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _videoTracks = MutableStateFlow<List<TrackOption>>(emptyList())
    val videoTracks: StateFlow<List<TrackOption>> = _videoTracks.asStateFlow()

    private val _audioTracks = MutableStateFlow<List<TrackOption>>(emptyList())
    val audioTracks: StateFlow<List<TrackOption>> = _audioTracks.asStateFlow()

    private val _textTracks = MutableStateFlow<List<TrackOption>>(emptyList())
    val textTracks: StateFlow<List<TrackOption>> = _textTracks.asStateFlow()

    private val _videoBadge = MutableStateFlow("")
    val videoBadge: StateFlow<String> = _videoBadge.asStateFlow()

    private val _playerError = MutableStateFlow<String?>(null)
    val playerError: StateFlow<String?> = _playerError.asStateFlow()

    private fun createPlayer(preset: BufferPreset): ExoPlayer {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(preset.minBufferMs, preset.maxBufferMs, preset.playbackMs, preset.playbackMs)
            .build()
        return ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .build().apply {
                addListener(playerListener)
            }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            _isPlaying.value = playing
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _isBuffering.value = playbackState == Player.STATE_BUFFERING
        }

        override fun onTracksChanged(tracks: Tracks) {
            parseTracks(tracks)
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _playerError.value = error.localizedMessage ?: "Playback error"
        }
    }

    fun updateBufferPreset(preset: BufferPreset) {
        if (preset == currentBufferPreset) return
        currentBufferPreset = preset
        val old = player
        old.removeListener(playerListener)
        old.release()
        player = createPlayer(preset)
    }

    fun play(info: StreamPlaybackInfo, hdrColorBoost: Boolean) {
        _playerError.value = null
        val ua = info.userAgent.ifBlank { "TiviMate/5.0 (Android TV)" }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
        if (info.headers.isNotEmpty()) {
            httpFactory.setDefaultRequestProperties(info.headers)
        }

        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)
        player.stop()

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(info.url))
        val lowerUrl = info.url.lowercase()
        when {
            lowerUrl.contains(".m3u8") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            lowerUrl.contains(".mpd") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
            lowerUrl.contains(".ism") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_SS)
        }

        if (info.drmScheme.isNotBlank() && info.drmLicenseUrl.isNotBlank()) {
            val uuid = when (info.drmScheme.lowercase()) {
                "widevine" -> C.WIDEVINE_UUID
                "clearkey" -> C.CLEARKEY_UUID
                "playready" -> C.PLAYREADY_UUID
                else -> C.WIDEVINE_UUID
            }
            val drmBuilder = MediaItem.DrmConfiguration.Builder(uuid)
                .setLicenseUri(info.drmLicenseUrl)
            if (info.drmHeaders.isNotEmpty()) {
                drmBuilder.setLicenseRequestHeaders(info.drmHeaders)
            }
            mediaItemBuilder.setDrmConfiguration(drmBuilder.build())
        }

        setHdrColorBoost(hdrColorBoost)

        val mediaSource = mediaSourceFactory.createMediaSource(mediaItemBuilder.build())
        player.setMediaSource(mediaSource)
        player.prepare()
        player.playWhenReady = true
    }

    fun setHdrColorBoost(enabled: Boolean) {
        try {
            if (enabled) {
                player.setVideoEffects(
                    listOf<Effect>(
                        HslAdjustment.Builder().adjustSaturation(14f).build(),
                        Contrast(0.08f)
                    )
                )
            } else {
                player.setVideoEffects(emptyList())
            }
        } catch (_: Throwable) {
            // Device does not support Media3 GL VideoEffects; continue playback safely
        }
    }

    private fun parseTracks(tracks: Tracks) {
        val vList = mutableListOf<TrackOption>()
        val aList = mutableListOf<TrackOption>()
        val tList = mutableListOf<TrackOption>()
        var badge = ""

        tracks.groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val selected = group.isTrackSelected(tIdx)
                when (group.type) {
                    C.TRACK_TYPE_VIDEO -> {
                        val w = fmt.width
                        val h = fmt.height
                        val mbps = if (fmt.bitrate > 0) String.format("%.2f Mbps", fmt.bitrate / 1_000_000f) else ""
                        val label = listOfNotNull(
                            if (w > 0 && h > 0) "${w}x$h" else "Video ${tIdx + 1}",
                            mbps.ifBlank { null }
                        ).joinToString(", ")
                        vList.add(TrackOption("v_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                        if (selected && h > 0) {
                            val resTag = when {
                                h >= 2160 -> "4K"
                                h >= 1080 -> "FHD"
                                h >= 720 -> "HD"
                                else -> "SD"
                            }
                            val fpsTag = if (fmt.frameRate > 0) "${fmt.frameRate.toInt()} FPS" else ""
                            badge = listOfNotNull(resTag, fpsTag.ifBlank { null }).joinToString(" • ")
                        }
                    }
                    C.TRACK_TYPE_AUDIO -> {
                        val lang = fmt.language ?: "Audio ${tIdx + 1}"
                        val ch = if (fmt.channelCount > 2) "5.1" else "Stereo"
                        val kbps = if (fmt.bitrate > 0) "${fmt.bitrate / 1000} kbps" else ""
                        val label = listOfNotNull(lang, ch, kbps.ifBlank { null }).joinToString(", ")
                        aList.add(TrackOption("a_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                    }
                    C.TRACK_TYPE_TEXT -> {
                        val lang = fmt.language ?: fmt.label ?: "Subtitle ${tIdx + 1}"
                        tList.add(TrackOption("t_${gIdx}_$tIdx", lang, gIdx, tIdx, selected))
                    }
                }
            }
        }
        _videoTracks.value = vList
        _audioTracks.value = aList
        _textTracks.value = tList
        _videoBadge.value = badge
    }

    fun selectTrack(option: TrackOption) {
        val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
        val params = trackSelector.parameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
        trackSelector.parameters = params
    }

    fun seekBy(deltaMs: Long) {
        val target = (player.currentPosition + deltaMs).coerceAtLeast(0L)
        player.seekTo(target)
    }

    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun stop() {
        player.stop()
    }

    fun release() {
        player.removeListener(playerListener)
        player.release()
    }
}
