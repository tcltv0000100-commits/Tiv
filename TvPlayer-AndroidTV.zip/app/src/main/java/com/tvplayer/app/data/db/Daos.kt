package com.tvplayer.app.data.db

import androidx.room.*
import com.tvplayer.app.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY id ASC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY id ASC")
    suspend fun getAll(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(playlist: PlaylistEntity): Long

    @Update
    suspend fun update(playlist: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface GroupDao {
    @Query("SELECT g.* FROM groups g INNER JOIN playlists p ON g.playlistId = p.id WHERE p.isEnabled = 1 AND g.contentType = :type AND g.isHidden = 0 ORDER BY g.sortOrder ASC, g.name ASC")
    fun observeVisibleByType(type: ContentType): Flow<List<GroupEntity>>

    @Query("SELECT * FROM groups WHERE playlistId = :playlistId AND contentType = :type ORDER BY sortOrder ASC, name ASC")
    fun observeByPlaylistAndType(playlistId: Long, type: ContentType): Flow<List<GroupEntity>>

    @Query("SELECT * FROM groups WHERE playlistId = :playlistId AND contentType = :type")
    suspend fun getByPlaylistAndType(playlistId: Long, type: ContentType): List<GroupEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(groups: List<GroupEntity>): List<Long>

    @Query("UPDATE groups SET isHidden = :hidden WHERE id = :groupId")
    suspend fun setHidden(groupId: Long, hidden: Boolean)

    @Query("UPDATE groups SET isHidden = :hidden WHERE playlistId = :playlistId AND contentType = :type")
    suspend fun setAllHidden(playlistId: Long, type: ContentType, hidden: Boolean)

    @Query("DELETE FROM groups WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: Long)
}

@Dao
interface ChannelDao {
    @Query("SELECT c.* FROM channels c INNER JOIN playlists p ON c.playlistId = p.id LEFT JOIN groups g ON c.groupId = g.id WHERE p.isEnabled = 1 AND c.isHidden = 0 AND (g.isHidden IS NULL OR g.isHidden = 0) ORDER BY c.playlistId ASC, c.sortOrder ASC LIMIT :limit")
    fun observeAllVisible(limit: Int = 5000): Flow<List<ChannelEntity>>

    @Query("SELECT c.* FROM channels c INNER JOIN playlists p ON c.playlistId = p.id WHERE p.isEnabled = 1 AND c.isFavorite = 1 AND c.isHidden = 0 ORDER BY c.name ASC")
    fun observeFavorites(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE groupId = :groupId AND isHidden = 0 ORDER BY sortOrder ASC")
    fun observeByGroup(groupId: Long): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId AND isHidden = 0 ORDER BY sortOrder ASC LIMIT :limit")
    fun observeByPlaylist(playlistId: Long, limit: Int = 5000): Flow<List<ChannelEntity>>

    @Query("SELECT c.* FROM channels c INNER JOIN playlists p ON c.playlistId = p.id WHERE p.isEnabled = 1 AND c.isHidden = 0 AND c.name LIKE '%' || :query || '%' ORDER BY c.name ASC LIMIT 200")
    suspend fun search(query: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ChannelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(channels: List<ChannelEntity>)

    @Transaction
    suspend fun insertChunked(channels: List<ChannelEntity>) {
        channels.chunked(500).forEach { insertBatch(it) }
    }

    @Query("UPDATE channels SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("UPDATE channels SET isHidden = :hidden WHERE id = :id")
    suspend fun setHidden(id: Long, hidden: Boolean)

    @Query("UPDATE channels SET isBlocked = :blocked WHERE id = :id")
    suspend fun setBlocked(id: Long, blocked: Boolean)

    @Query("UPDATE channels SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: Long)
}

@Dao
interface VodDao {
    @Query("SELECT v.* FROM vod_items v INNER JOIN playlists p ON v.playlistId = p.id LEFT JOIN groups g ON v.groupId = g.id WHERE p.isEnabled = 1 AND v.contentType = :type AND (g.isHidden IS NULL OR g.isHidden = 0) ORDER BY v.sortOrder ASC LIMIT :limit")
    fun observeAllByType(type: ContentType, limit: Int = 2000): Flow<List<VodEntity>>

    @Query("SELECT * FROM vod_items WHERE groupId = :groupId AND contentType = :type ORDER BY sortOrder ASC LIMIT :limit")
    fun observeByGroup(groupId: Long, type: ContentType, limit: Int = 2000): Flow<List<VodEntity>>

    @Query("SELECT * FROM vod_items WHERE playlistId = :playlistId AND contentType = :type ORDER BY sortOrder ASC LIMIT :limit")
    fun observeByPlaylist(playlistId: Long, type: ContentType, limit: Int = 2000): Flow<List<VodEntity>>

    @Query("SELECT v.* FROM vod_items v INNER JOIN playlists p ON v.playlistId = p.id WHERE p.isEnabled = 1 AND v.contentType = :type AND v.isInMyList = 1 ORDER BY v.title ASC")
    fun observeMyList(type: ContentType): Flow<List<VodEntity>>

    @Query("SELECT v.* FROM vod_items v INNER JOIN playlists p ON v.playlistId = p.id WHERE p.isEnabled = 1 AND v.contentType = :type AND v.title LIKE '%' || :query || '%' ORDER BY v.title ASC LIMIT 150")
    suspend fun search(type: ContentType, query: String): List<VodEntity>

    @Query("SELECT * FROM vod_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VodEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(items: List<VodEntity>)

    @Transaction
    suspend fun insertChunked(items: List<VodEntity>) {
        items.chunked(500).forEach { insertBatch(it) }
    }

    @Query("UPDATE vod_items SET isInMyList = :inList WHERE id = :id")
    suspend fun setMyList(id: Long, inList: Boolean)

    @Query("DELETE FROM vod_items WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: Long)
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId AND endTimeMs >= :fromMs AND startTimeMs <= :toMs ORDER BY startTimeMs ASC")
    suspend fun getProgramsForChannel(tvgId: String, fromMs: Long, toMs: Long): List<EpgProgramEntity>

    @Query("SELECT * FROM epg_programs WHERE channelTvgId IN (:tvgIds) AND endTimeMs >= :fromMs AND startTimeMs <= :toMs ORDER BY startTimeMs ASC")
    suspend fun getProgramsForChannels(tvgIds: List<String>, fromMs: Long, toMs: Long): List<EpgProgramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBatch(programs: List<EpgProgramEntity>)

    @Transaction
    suspend fun insertChunked(programs: List<EpgProgramEntity>) {
        programs.chunked(500).forEach { insertBatch(it) }
    }

    @Query("DELETE FROM epg_programs WHERE endTimeMs < :olderThanMs")
    suspend fun deleteExpired(olderThanMs: Long)

    @Query("DELETE FROM epg_programs")
    suspend fun clearAll()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history WHERE itemType = :type ORDER BY lastWatchedMs DESC LIMIT :limit")
    fun observeRecent(type: ContentType, limit: Int = 20): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: HistoryEntity)

    @Query("DELETE FROM history WHERE itemType = :type")
    suspend fun clearType(type: ContentType)

    @Query("DELETE FROM history")
    suspend fun clearAll()
}
