package com.tvplayer.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class CrashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra("stacktrace") ?: "Unknown error"
        setContent {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF14151A))
                    .padding(20.dp)
            ) {
                Text(
                    text = "App Error Report (Copy & Share)",
                    color = Color.White,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("CrashLog", trace))
                    Toast.makeText(this@CrashActivity, "Copied!", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Copy Error Log")
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = trace,
                    color = Color(0xFFFF8A80),
                    fontSize = 12.sp,
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                )
            }
        }
    }
}
