package com.tvplayer.app.data.parser

import com.google.gson.Gson
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

data class ParsedM3uChannel(
    val name: String,
    val streamUrl: String,
    val groupName: String,
    val logoUrl: String,
    val tvgId: String,
    val catchupDays: Int,
    val userAgent: String,
    val drmScheme: String,
    val drmLicenseUrl: String,
    val drmHeadersJson: String
)

data class ParsedM3uResult(
    val epgUrl: String?,
    val channels: List<ParsedM3uChannel>
)

object M3uParser {
    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")
    private val gson = Gson()

    fun parse(inputStream: InputStream): ParsedM3uResult {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8), 65536)
        val channels = ArrayList<ParsedM3uChannel>(1024)
        var headerEpgUrl: String? = null

        var currentName = ""
        var currentGroup = "Uncategorized"
        var currentLogo = ""
        var currentTvgId = ""
        var currentCatchupDays = 0
        var currentUserAgent = ""
        var currentDrmScheme = ""
        var currentDrmLicense = ""
        val currentHeaders = mutableMapOf<String, String>()

        reader.useLines { lines ->
            lines.forEach { rawLine ->
                val line = rawLine.trim()
                if (line.isEmpty()) return@forEach

                when {
                    line.startsWith("#EXTM3U", ignoreCase = true) -> {
                        attrRegex.findAll(line).forEach { m ->
                            val k = m.groupValues[1].lowercase()
                            val v = m.groupValues[2]
                            if ((k == "url-tvg" || k == "x-tvg-url") && v.isNotBlank()) {
                                headerEpgUrl = v.split(",").firstOrNull()?.trim()
                            }
                        }
                    }

                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        val commaIdx = line.lastIndexOf(',')
                        val metaPart = if (commaIdx > 0) line.substring(0, commaIdx) else line
                        currentName = if (commaIdx > 0 && commaIdx + 1 < line.length) {
                            line.substring(commaIdx + 1).trim()
                        } else {
                            "Channel"
                        }
                        currentGroup = "Uncategorized"
                        currentLogo = ""
                        currentTvgId = ""
                        currentCatchupDays = 0

                        attrRegex.findAll(metaPart).forEach { m ->
                            when (m.groupValues[1].lowercase()) {
                                "tvg-id" -> currentTvgId = m.groupValues[2].trim()
                                "tvg-name" -> if (currentName == "Channel" && m.groupValues[2].isNotBlank()) {
                                    currentName = m.groupValues[2].trim()
                                }
                                "tvg-logo" -> currentLogo = m.groupValues[2].trim()
                                "group-title" -> if (m.groupValues[2].isNotBlank()) {
                                    currentGroup = m.groupValues[2].trim()
                                }
                                "catchup-days" -> currentCatchupDays = m.groupValues[2].toIntOrNull() ?: 0
                            }
                        }
                    }

                    line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                        val opt = line.substringAfter("#EXTVLCOPT:").trim()
                        if (opt.startsWith("http-user-agent=", ignoreCase = true)) {
                            currentUserAgent = opt.substringAfter("=").trim()
                        } else if (opt.startsWith("http-referrer=", ignoreCase = true)) {
                            currentHeaders["Referer"] = opt.substringAfter("=").trim()
                        }
                    }

                    line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                        val prop = line.substringAfter("#KODIPROP:").trim()
                        val key = prop.substringBefore("=").trim()
                        val value = prop.substringAfter("=", "").trim()
                        when (key) {
                            "inputstream.adaptive.license_type" -> {
                                currentDrmScheme = when {
                                    value.contains("widevine", ignoreCase = true) -> "widevine"
                                    value.contains("clearkey", ignoreCase = true) -> "clearkey"
                                    value.contains("playready", ignoreCase = true) -> "playready"
                                    else -> value.lowercase()
                                }
                            }
                            "inputstream.adaptive.license_key" -> {
                                currentDrmLicense = value
                            }
                        }
                    }

                    !line.startsWith("#") -> {
                        if (line.startsWith("http://", true) ||
                            line.startsWith("https://", true) ||
                            line.startsWith("rtsp://", true) ||
                            line.startsWith("rtmp://", true) ||
                            line.startsWith("udp://", true)
                        ) {
                            val cleanUrl = line.substringBefore("|")
                            if (line.contains("|")) {
                                val pipePart = line.substringAfter("|")
                                pipePart.split("&").forEach { kv ->
                                    val k = kv.substringBefore("=").trim()
                                    val v = kv.substringAfter("=", "").trim()
                                    if (k.equals("User-Agent", true)) currentUserAgent = v
                                    else if (k.isNotBlank() && v.isNotBlank()) currentHeaders[k] = v
                                }
                            }
                            channels.add(
                                ParsedM3uChannel(
                                    name = currentName.ifBlank { "Channel ${channels.size + 1}" },
                                    streamUrl = cleanUrl,
                                    groupName = currentGroup,
                                    logoUrl = currentLogo,
                                    tvgId = currentTvgId,
                                    catchupDays = currentCatchupDays,
                                    userAgent = currentUserAgent,
                                    drmScheme = currentDrmScheme,
                                    drmLicenseUrl = currentDrmLicense,
                                    drmHeadersJson = if (currentHeaders.isEmpty()) "" else gson.toJson(currentHeaders)
                                )
                            )
                        }
                        // Reset per-channel extras
                        currentUserAgent = ""
                        currentDrmScheme = ""
                        currentDrmLicense = ""
                        currentHeaders.clear()
                    }
                }
            }
        }
        return ParsedM3uResult(headerEpgUrl, channels)
    }
}
