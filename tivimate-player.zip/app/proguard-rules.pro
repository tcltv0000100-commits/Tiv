# Keep Gson and Media3 models
-keepattributes Signature
-keep class com.tiviplayer.app.data.** { *; }
