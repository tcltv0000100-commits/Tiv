package com.tiviplayer.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PlaylistDatabase(context: Context) : SQLiteOpenHelper(context, "tivimate_media.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE groups_tbl (
                id TEXT PRIMARY KEY,
                playlistId TEXT NOT NULL,
                name TEXT NOT NULL,
                categoryType TEXT NOT NULL,
                visible INTEGER NOT NULL,
                orderIndex INTEGER NOT NULL,
                rawId TEXT NOT NULL
            )
        """)
        db.execSQL("CREATE INDEX idx_grp_pl ON groups_tbl(playlistId, categoryType)")

        db.execSQL("""
            CREATE TABLE channels_tbl (
                id TEXT PRIMARY KEY,
                playlistId TEXT NOT NULL,
                number INTEGER NOT NULL,
                name TEXT NOT NULL,
                groupId TEXT NOT NULL,
                groupName TEXT NOT NULL,
                logoUrl TEXT NOT NULL,
                streamUrl TEXT NOT NULL,
                cmd TEXT NOT NULL,
                tvgId TEXT NOT NULL,
                hasCatchup INTEGER NOT NULL,
                customName TEXT,
                audioDecoder TEXT NOT NULL,
                videoDecoder TEXT NOT NULL,
                useExternalPlayer TEXT NOT NULL,
                epgOffsetMinutes INTEGER NOT NULL,
                userAgent TEXT NOT NULL,
                referer TEXT NOT NULL,
                drmLicenseType TEXT NOT NULL,
                drmLicenseUrl TEXT NOT NULL
            )
        """)
        db.execSQL("CREATE INDEX idx_ch_pl_grp ON channels_tbl(playlistId, groupId)")

        db.execSQL("""
            CREATE TABLE vod_tbl (
                id TEXT PRIMARY KEY,
                playlistId TEXT NOT NULL,
                title TEXT NOT NULL,
                isSeries INTEGER NOT NULL,
                groupId TEXT NOT NULL,
                groupName TEXT NOT NULL,
                posterUrl TEXT NOT NULL,
                backdropUrl TEXT NOT NULL,
                rating TEXT NOT NULL,
                year TEXT NOT NULL,
                durationOrSeasons TEXT NOT NULL,
                genres TEXT NOT NULL,
                castText TEXT NOT NULL,
                description TEXT NOT NULL,
                streamUrl TEXT NOT NULL,
                cmd TEXT NOT NULL,
                containerExt TEXT NOT NULL,
                addedTimestamp INTEGER NOT NULL
            )
        """)
        db.execSQL("CREATE INDEX idx_vod_pl_ser_grp ON vod_tbl(playlistId, isSeries, groupId)")

        db.execSQL("""
            CREATE TABLE epg_tbl (
                channelId TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                startTimeMs INTEGER NOT NULL,
                endTimeMs INTEGER NOT NULL
            )
        """)
        db.execSQL("CREATE INDEX idx_epg_ch ON epg_tbl(channelId)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS groups_tbl")
        db.execSQL("DROP TABLE IF EXISTS channels_tbl")
        db.execSQL("DROP TABLE IF EXISTS vod_tbl")
        db.execSQL("DROP TABLE IF EXISTS epg_tbl")
        onCreate(db)
    }

    fun replacePlaylistData(
        playlistId: String,
        groups: List<GroupItem>,
        channels: List<ChannelItem>,
        movies: List<VodItem>,
        shows: List<VodItem>,
        epgPrograms: List<EpgProgram>
    ) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("groups_tbl", "playlistId=?", arrayOf(playlistId))
            db.delete("channels_tbl", "playlistId=?", arrayOf(playlistId))
            db.delete("vod_tbl", "playlistId=?", arrayOf(playlistId))

            val grpStmt = db.compileStatement("INSERT OR REPLACE INTO groups_tbl VALUES (?,?,?,?,?,?,?)")
            for (g in groups) {
                grpStmt.clearBindings()
                grpStmt.bindString(1, g.id)
                grpStmt.bindString(2, g.playlistId)
                grpStmt.bindString(3, g.name)
                grpStmt.bindString(4, g.categoryType)
                grpStmt.bindLong(5, if (g.visible) 1L else 0L)
                grpStmt.bindLong(6, g.orderIndex.toLong())
                grpStmt.bindString(7, g.rawId)
                grpStmt.executeInsert()
            }

            val chStmt = db.compileStatement("INSERT OR REPLACE INTO channels_tbl VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            for (c in channels) {
                chStmt.clearBindings()
                chStmt.bindString(1, c.id)
                chStmt.bindString(2, c.playlistId)
                chStmt.bindLong(3, c.number.toLong())
                chStmt.bindString(4, c.name)
                chStmt.bindString(5, c.groupId)
                chStmt.bindString(6, c.groupName)
                chStmt.bindString(7, c.logoUrl)
                chStmt.bindString(8, c.streamUrl)
                chStmt.bindString(9, c.cmd)
                chStmt.bindString(10, c.tvgId)
                chStmt.bindLong(11, if (c.hasCatchup) 1L else 0L)
                if (c.customName != null) chStmt.bindString(12, c.customName) else chStmt.bindNull(12)
                chStmt.bindString(13, c.audioDecoder)
                chStmt.bindString(14, c.videoDecoder)
                chStmt.bindString(15, c.useExternalPlayer)
                chStmt.bindLong(16, c.epgOffsetMinutes.toLong())
                chStmt.bindString(17, c.userAgent)
                chStmt.bindString(18, c.referer)
                chStmt.bindString(19, c.drmLicenseType)
                chStmt.bindString(20, c.drmLicenseUrl)
                chStmt.executeInsert()
            }

            val vodStmt = db.compileStatement("INSERT OR REPLACE INTO vod_tbl VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            for (v in movies + shows) {
                vodStmt.clearBindings()
                vodStmt.bindString(1, v.id)
                vodStmt.bindString(2, v.playlistId)
                vodStmt.bindString(3, v.title)
                vodStmt.bindLong(4, if (v.isSeries) 1L else 0L)
                vodStmt.bindString(5, v.groupId)
                vodStmt.bindString(6, v.groupName)
                vodStmt.bindString(7, v.posterUrl)
                vodStmt.bindString(8, v.backdropUrl)
                vodStmt.bindString(9, v.rating)
                vodStmt.bindString(10, v.year)
                vodStmt.bindString(11, v.durationOrSeasons)
                vodStmt.bindString(12, v.genres)
                vodStmt.bindString(13, v.cast)
                vodStmt.bindString(14, v.description)
                vodStmt.bindString(15, v.streamUrl)
                vodStmt.bindString(16, v.cmd)
                vodStmt.bindString(17, v.containerExt)
                vodStmt.bindLong(18, v.addedTimestamp)
                vodStmt.executeInsert()
            }

            if (epgPrograms.isNotEmpty()) {
                val epgStmt = db.compileStatement("INSERT INTO epg_tbl VALUES (?,?,?,?,?)")
                for (e in epgPrograms) {
                    epgStmt.clearBindings()
                    epgStmt.bindString(1, e.channelId)
                    epgStmt.bindString(2, e.title)
                    epgStmt.bindString(3, e.description)
                    epgStmt.bindLong(4, e.startTimeMs)
                    epgStmt.bindLong(5, e.endTimeMs)
                    epgStmt.executeInsert()
                }
            }

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun appendVodItems(items: List<VodItem>) {
        if (items.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val vodStmt = db.compileStatement("INSERT OR REPLACE INTO vod_tbl VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            for (v in items) {
                vodStmt.clearBindings()
                vodStmt.bindString(1, v.id)
                vodStmt.bindString(2, v.playlistId)
                vodStmt.bindString(3, v.title)
                vodStmt.bindLong(4, if (v.isSeries) 1L else 0L)
                vodStmt.bindString(5, v.groupId)
                vodStmt.bindString(6, v.groupName)
                vodStmt.bindString(7, v.posterUrl)
                vodStmt.bindString(8, v.backdropUrl)
                vodStmt.bindString(9, v.rating)
                vodStmt.bindString(10, v.year)
                vodStmt.bindString(11, v.durationOrSeasons)
                vodStmt.bindString(12, v.genres)
                vodStmt.bindString(13, v.cast)
                vodStmt.bindString(14, v.description)
                vodStmt.bindString(15, v.streamUrl)
                vodStmt.bindString(16, v.cmd)
                vodStmt.bindString(17, v.containerExt)
                vodStmt.bindLong(18, v.addedTimestamp)
                vodStmt.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun deletePlaylistData(playlistId: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("groups_tbl", "playlistId=?", arrayOf(playlistId))
            db.delete("channels_tbl", "playlistId=?", arrayOf(playlistId))
            db.delete("vod_tbl", "playlistId=?", arrayOf(playlistId))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun updateChannelCustomName(channelId: String, customName: String?) {
        val cv = ContentValues().apply {
            if (customName != null) put("customName", customName) else putNull("customName")
        }
        writableDatabase.update("channels_tbl", cv, "id=?", arrayOf(channelId))
    }

    fun updateChannelTvgId(channelId: String, tvgId: String) {
        val cv = ContentValues().apply { put("tvgId", tvgId) }
        writableDatabase.update("channels_tbl", cv, "id=?", arrayOf(channelId))
    }

    fun loadAllGroups(): List<GroupItem> {
        val list = mutableListOf<GroupItem>()
        readableDatabase.rawQuery("SELECT * FROM groups_tbl ORDER BY orderIndex ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    GroupItem(
                        id = c.getString(0),
                        playlistId = c.getString(1),
                        name = c.getString(2),
                        categoryType = c.getString(3),
                        visible = c.getInt(4) == 1,
                        orderIndex = c.getInt(5),
                        rawId = c.getString(6)
                    )
                )
            }
        }
        return list
    }

    fun loadAllChannels(): List<ChannelItem> {
        val list = mutableListOf<ChannelItem>()
        readableDatabase.rawQuery("SELECT * FROM channels_tbl ORDER BY number ASC", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    ChannelItem(
                        id = c.getString(0),
                        playlistId = c.getString(1),
                        number = c.getInt(2),
                        name = c.getString(3),
                        groupId = c.getString(4),
                        groupName = c.getString(5),
                        logoUrl = c.getString(6),
                        streamUrl = c.getString(7),
                        cmd = c.getString(8),
                        tvgId = c.getString(9),
                        hasCatchup = c.getInt(10) == 1,
                        customName = if (c.isNull(11)) null else c.getString(11),
                        audioDecoder = c.getString(12),
                        videoDecoder = c.getString(13),
                        useExternalPlayer = c.getString(14),
                        epgOffsetMinutes = c.getInt(15),
                        userAgent = c.getString(16),
                        referer = c.getString(17),
                        drmLicenseType = c.getString(18),
                        drmLicenseUrl = c.getString(19)
                    )
                )
            }
        }
        return list
    }

    fun loadVod(isSeries: Boolean): List<VodItem> {
        val list = mutableListOf<VodItem>()
        readableDatabase.rawQuery(
            "SELECT * FROM vod_tbl WHERE isSeries=?",
            arrayOf(if (isSeries) "1" else "0")
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    VodItem(
                        id = c.getString(0),
                        playlistId = c.getString(1),
                        title = c.getString(2),
                        isSeries = c.getInt(3) == 1,
                        groupId = c.getString(4),
                        groupName = c.getString(5),
                        posterUrl = c.getString(6),
                        backdropUrl = c.getString(7),
                        rating = c.getString(8),
                        year = c.getString(9),
                        durationOrSeasons = c.getString(10),
                        genres = c.getString(11),
                        cast = c.getString(12),
                        description = c.getString(13),
                        streamUrl = c.getString(14),
                        cmd = c.getString(15),
                        containerExt = c.getString(16),
                        addedTimestamp = c.getLong(17)
                    )
                )
            }
        }
        return list
    }

    fun loadEpgPrograms(): List<EpgProgram> {
        val list = mutableListOf<EpgProgram>()
        readableDatabase.rawQuery("SELECT * FROM epg_tbl LIMIT 10000", null).use { c ->
            while (c.moveToNext()) {
                list.add(
                    EpgProgram(
                        channelId = c.getString(0),
                        title = c.getString(1),
                        description = c.getString(2),
                        startTimeMs = c.getLong(3),
                        endTimeMs = c.getLong(4)
                    )
                )
            }
        }
        return list
    }
}
