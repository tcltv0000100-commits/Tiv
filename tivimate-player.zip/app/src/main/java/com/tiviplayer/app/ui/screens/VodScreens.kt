package com.tiviplayer.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviplayer.app.data.EpisodeItem
import com.tiviplayer.app.data.VodItem
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.components.DrawerRadioItem
import com.tiviplayer.app.ui.components.DrawerToggleItem
import com.tiviplayer.app.ui.components.TiviRightDrawer
import com.tiviplayer.app.ui.theme.TiviColors
import kotlinx.coroutines.launch

@Composable
fun VodBrowseScreen(
    viewModel: MainViewModel,
    isSeries: Boolean,
    onPlayVod: (VodItem, EpisodeItem?) -> Unit,
    onOpenSearch: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val groups by viewModel.groups.collectAsState()
    val items by (if (isSeries) viewModel.shows else viewModel.movies).collectAsState()
    val myList by viewModel.myListVod.collectAsState()
    val history by viewModel.vodHistory.collectAsState()

    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedVod by remember { mutableStateOf<VodItem?>(null) }
    var detailVod by remember { mutableStateOf<VodItem?>(null) }
    var showSortDrawer by remember { mutableStateOf(false) }

    val catType = if (isSeries) "Shows" else "Movies"
    val vodGroups = remember(groups, catType) { groups.filter { it.categoryType == catType && it.visible } }

    val filteredItems = remember(items, selectedCategory, myList, history, settings.vodSorting) {
        val base = when (selectedCategory) {
            "MY_LIST" -> items.filter { myList.contains(it.id) }
            "HISTORY" -> history.mapNotNull { hid -> items.find { it.id == hid } }
            "ALL" -> items
            else -> items.filter { it.groupId == selectedCategory || it.groupName == selectedCategory }
        }
        when (settings.vodSorting) {
            "By name" -> base.sortedBy { it.title }
            "By rating" -> base.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }
            "By date added" -> base.sortedByDescending { it.addedTimestamp }
            else -> base
        }
    }

    LaunchedEffect(filteredItems) {
        if (selectedVod == null && filteredItems.isNotEmpty()) selectedVod = filteredItems.first()
    }

    if (detailVod != null) {
        VodDetailScreen(
            vod = detailVod!!,
            viewModel = viewModel,
            isInMyList = myList.contains(detailVod!!.id),
            isInHistory = history.contains(detailVod!!.id),
            onBack = { detailVod = null },
            onPlay = { ep -> onPlayVod(detailVod!!, ep) }
        )
        return
    }

    Row(modifier = Modifier.fillMaxSize().background(TiviColors.BgRoot)) {
        // Left Categories Sidebar
        LazyColumn(
            modifier = Modifier
                .width(205.dp)
                .fillMaxHeight()
                .background(TiviColors.BgSurface)
                .padding(vertical = 12.dp)
        ) {
            item { VodCategoryChip("My list", selectedCategory == "MY_LIST") { selectedCategory = "MY_LIST" } }
            item { VodCategoryChip("History", selectedCategory == "HISTORY") { selectedCategory = "HISTORY" } }
            item { VodCategoryChip(if (isSeries) "All shows" else "All movies", selectedCategory == "ALL") { selectedCategory = "ALL" } }

            playlists.filter { it.enabled }.forEach { pl ->
                item {
                    Text(
                        pl.name,
                        color = TiviColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        maxLines = 1
                    )
                }
                val plGroups = vodGroups.filter { it.playlistId == pl.id }
                items(plGroups) { grp ->
                    VodCategoryChip(grp.name, selectedCategory == grp.id) { selectedCategory = grp.id }
                }
            }
        }

        // Right Showcase + Grid
        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
            // Hero Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(215.dp)
                    .background(TiviColors.BgRoot)
            ) {
                val hero = selectedVod
                if (hero != null) {
                    AsyncImage(
                        model = hero.backdropUrl.ifBlank { hero.posterUrl },
                        contentDescription = hero.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxWidth(0.62f)
                            .fillMaxHeight()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(TiviColors.BgRoot, TiviColors.BgRoot.copy(alpha = 0.85f), Color.Transparent)
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.60f)
                            .padding(20.dp)
                    ) {
                        Text(hero.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (hero.rating.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(TiviColors.AccentBlue)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(hero.rating, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (hero.year.isNotBlank()) Text(hero.year, color = TiviColors.TextSecondary, fontSize = 12.sp)
                            if (hero.genres.isNotBlank()) Text("• ${hero.genres}", color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                        }
                        if (hero.cast.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Cast: ${hero.cast}", color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (hero.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(hero.description, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }

                // Top-Right Search & Sort Icons
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(14.dp)
                ) {
                    IconButton(onClick = onOpenSearch) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    }
                    IconButton(onClick = { showSortDrawer = true }) {
                        Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort", tint = Color.White)
                    }
                }
            }

            // Category Heading & Counter
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (selectedCategory == "ALL") (if (isSeries) "All shows" else "All movies") else selectedCategory,
                    color = TiviColors.TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${if (filteredItems.isEmpty()) 0 else 1} / ${filteredItems.size}",
                    color = TiviColors.TextSecondary,
                    fontSize = 12.sp
                )
            }

            if (filteredItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (isSeries) "No shows" else "No movies", color = TiviColors.TextSecondary, fontSize = 14.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 115.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredItems, key = { it.id }) { item ->
                        VodPosterCard(
                            item = item,
                            selected = selectedVod?.id == item.id,
                            onClick = {
                                selectedVod = item
                                detailVod = item
                            }
                        )
                    }
                }
            }
        }
    }

    if (showSortDrawer) {
        TiviRightDrawer("Sorting", onDismiss = { showSortDrawer = false }) {
            listOf("By order in playlist", "By name", "By rating", "By date added").forEach { opt ->
                DrawerRadioItem(opt, selected = settings.vodSorting == opt) {
                    viewModel.updateSettings { it.copy(vodSorting = opt) }
                    showSortDrawer = false
                }
            }
            HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 8.dp))
            DrawerToggleItem(
                title = if (isSeries) "Group \"All shows\" by categories" else "Group \"All movies\" by categories",
                checked = settings.groupAllMoviesByCategories,
                onCheckedChange = { v -> viewModel.updateSettings { it.copy(groupAllMoviesByCategories = v) } }
            )
        }
    }
}

@Composable
fun VodPosterCard(item: VodItem, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(115.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(165.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(TiviColors.BgCard)
        ) {
            AsyncImage(
                model = item.posterUrl,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.rating.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(TiviColors.AccentBlue)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(item.rating, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            item.title,
            color = if (selected) Color.White else TiviColors.TextPrimary,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun VodDetailScreen(
    vod: VodItem,
    viewModel: MainViewModel,
    isInMyList: Boolean,
    isInHistory: Boolean,
    onBack: () -> Unit,
    onPlay: (EpisodeItem?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var episodes by remember { mutableStateOf<List<EpisodeItem>>(emptyList()) }
    var selectedSeason by remember { mutableIntStateOf(1) }

    LaunchedEffect(vod.id) {
        if (vod.isSeries) {
            episodes = viewModel.loadSeriesEpisodes(vod)
            episodes.firstOrNull()?.let { selectedSeason = it.season }
        }
    }

    val seasons = remember(episodes) { episodes.map { it.season }.distinct().sorted() }
    val seasonEpisodes = remember(episodes, selectedSeason) { episodes.filter { it.season == selectedSeason } }

    Box(modifier = Modifier.fillMaxSize().background(TiviColors.BgRoot)) {
        AsyncImage(
            model = vod.backdropUrl.ifBlank { vod.posterUrl },
            contentDescription = vod.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Black.copy(alpha = 0.55f), TiviColors.BgRoot.copy(alpha = 0.92f), TiviColors.BgRoot)
                    )
                )
        )

        Column(modifier = Modifier.fillMaxSize().padding(28.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.height(12.dp))
            Text(vod.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (vod.rating.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TiviColors.AccentBlue)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(vod.rating, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (vod.year.isNotBlank()) Text(vod.year, color = TiviColors.TextSecondary, fontSize = 13.sp)
                if (seasons.isNotEmpty()) Text("${seasons.size} Seasons", color = TiviColors.TextSecondary, fontSize = 13.sp)
                if (vod.genres.isNotBlank()) Text("• ${vod.genres}", color = TiviColors.TextSecondary, fontSize = 13.sp)
            }
            if (vod.cast.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("Cast: ${vod.cast}", color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 2)
            }
            if (vod.description.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(vod.description, color = TiviColors.TextPrimary, fontSize = 13.sp, maxLines = 4, modifier = Modifier.fillMaxWidth(0.75f))
            }

            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { onPlay(seasonEpisodes.firstOrNull()) },
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgHighlight, contentColor = Color.Black),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (vod.isSeries) "Play S${selectedSeason} E1" else "Play")
                }
                Button(
                    onClick = {
                        scope.launch {
                            val url = seasonEpisodes.firstOrNull()?.streamUrl ?: viewModel.resolveVodPlayableUrl(vod)
                            if (url.isNotBlank()) {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(url), "video/*")
                                }
                                runCatching { context.startActivity(intent) }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgCard, contentColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("Open in external player")
                }
                Button(
                    onClick = { viewModel.toggleMyListVod(vod.id) },
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgCard, contentColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(if (isInMyList) "Remove from My list" else "Add to My list")
                }
                if (isInHistory) {
                    Button(
                        onClick = { viewModel.removeVodHistory(vod.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgCard, contentColor = Color.White),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("Remove from History")
                    }
                }
            }

            if (vod.isSeries && seasonEpisodes.isNotEmpty()) {
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    seasons.forEach { s ->
                        FilterChip(
                            selected = selectedSeason == s,
                            onClick = { selectedSeason = s },
                            label = { Text("Season $s") }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text("1 / ${seasonEpisodes.size}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(seasonEpisodes) { ep ->
                        Column(
                            modifier = Modifier
                                .width(175.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TiviColors.BgCard)
                                .clickable { onPlay(ep) }
                                .padding(12.dp)
                        ) {
                            Text("S%02dE%02d".format(ep.season, ep.episodeNum), color = TiviColors.AccentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(ep.title, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VodCategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) TiviColors.BgHighlight else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Text(
            label,
            color = if (selected) Color.Black else TiviColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
