package com.tiviplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviplayer.app.data.RecordingItem
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.theme.TiviColors
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordingsScreen(
    viewModel: MainViewModel,
    onPlayRecording: (RecordingItem) -> Unit
) {
    val recordings by viewModel.recordings.collectAsState()
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, h:mm a", Locale.US) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.BgRoot)
            .padding(24.dp)
    ) {
        Text("Recordings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))

        if (recordings.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No recordings", color = TiviColors.TextSecondary, fontSize = 15.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(recordings, key = { it.id }) { rec ->
                    val sizeMb = "%.1f MB".format(
                        (if (rec.isRecording) File(rec.filePath).length() else rec.bytesWritten) / (1024f * 1024f)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TiviColors.BgSurface)
                            .clickable { onPlayRecording(rec) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (rec.isRecording) Icons.Default.FiberManualRecord else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (rec.isRecording) Color(0xFFE53935) else TiviColors.AccentBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "${rec.channelName} • ${fmt.format(Date(rec.startedAtMs))} • $sizeMb" +
                                    if (rec.isRecording) " • Recording..." else "",
                                color = TiviColors.TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        if (rec.isRecording) {
                            IconButton(onClick = { viewModel.stopRecording(rec.id) }) {
                                Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color(0xFFE53935))
                            }
                        }
                        IconButton(onClick = { viewModel.deleteRecording(rec.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TiviColors.TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
