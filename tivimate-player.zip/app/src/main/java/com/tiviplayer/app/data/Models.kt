package com.tiviplayer.app.data

import java.security.MessageDigest
import java.util.UUID

enum class PlaylistType { M3U, XTREAM, STALKER }

enum class DisplayMode(val label: String) {
    NORMAL("Normal"),
    FULL("Full"),
    ZOOM("Zoom"),
    ZOOM_235("Zoom - 2.35:1"),
    REDUCED("Reduced"),
    RATIO_4_3("4:3"),
    RATIO_16_9("16:9"),
    RATIO_235_1("2.35:1")
}

data class StalkerDerivedIds(
    val macUpper: String,
    val serialNumber: String,
    val deviceId: String,
    val deviceId2: String
)

object StalkerDeviceUtils {
    fun deriveFromMac(mac: String): StalkerDerivedIds {
        val macUpper = mac.trim().uppercase()
        if (macUpper.isEmpty()) {
            return StalkerDerivedIds("", "", "", "")
        }
        val md5Hex = hashHex("MD5", macUpper).uppercase()
        val sncut = if (md5Hex.length >= 13) md5Hex.substring(0, 13) else md5Hex
        val devenc = hashHex("SHA-256", macUpper).uppercase()
        return StalkerDerivedIds(
            macUpper = macUpper,
            serialNumber = sncut,
            deviceId = devenc,
            deviceId2 = devenc
        )
    }

    fun sha256Upper(input: String): String = hashHex("SHA-256", input).uppercase()

    private fun hashHex(algo: String, input: String): String {
        val digest = MessageDigest.getInstance(algo).digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}

data class PlaylistConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val type: PlaylistType = PlaylistType.M3U,
    val enabled: Boolean = true,
    val url: String = "",
    val epgUrl: String = "",
    val logosPriority: String = "Prefer logos from playlist",
    val catchupMode: String = "Auto",
    val userAgent: String = "Not set",
    val includeTv: Boolean = true,
    val includeVod: Boolean = true,
    val isVodOnly: Boolean = false,
    val username: String = "",
    val password: String = "",
    val outputFormat: String = "MPEG-TS",
    val macAddress: String = "",
    val deviceId: String = "",
    val deviceId2: String = "",
    val serialNumber: String = "",
    val portalEndpoint: String = "",
    val token: String = "",
    val expirationDate: String = "Unlimited",
    val maxConnections: String = "1",
    val channelsCount: Int = 0,
    val moviesCount: Int = 0,
    val showsCount: Int = 0,
    val updateIntervalHours: Int = 24,
    val updateOnStart: Boolean = true,
    val orderIndex: Int = 0
)

data class GroupItem(
    val id: String,
    val playlistId: String,
    val name: String,
    val categoryType: String = "TV",
    val visible: Boolean = true,
    val orderIndex: Int = 0
)

data class ChannelItem(
    val id: String,
    val playlistId: String,
    val number: Int,
    val name: String,
    val groupId: String,
    val groupName: String,
    val logoUrl: String = "",
    val streamUrl: String = "",
    val cmd: String = "",
    val tvgId: String = "",
    val hasCatchup: Boolean = false,
    val customName: String? = null,
    val audioDecoder: String = "Default",
    val videoDecoder: String = "Default",
    val useExternalPlayer: String = "Default",
    val epgOffsetMinutes: Int = 0
)

data class EpgProgram(
    val channelId: String,
    val title: String,
    val description: String = "No information",
    val startTimeMs: Long,
    val endTimeMs: Long
)

data class VodItem(
    val id: String,
    val playlistId: String,
    val title: String,
    val isSeries: Boolean = false,
    val groupId: String = "",
    val groupName: String = "",
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val rating: String = "",
    val year: String = "",
    val durationOrSeasons: String = "",
    val genres: String = "",
    val cast: String = "",
    val description: String = "",
    val streamUrl: String = "",
    val cmd: String = "",
    val containerExt: String = "mp4",
    val addedTimestamp: Long = 0L
)

data class EpisodeItem(
    val id: String,
    val season: Int,
    val episodeNum: Int,
    val title: String,
    val streamUrl: String = "",
    val cmd: String = "",
    val duration: String = ""
)

data class RecordingItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val channelName: String,
    val filePath: String,
    val startedAtMs: Long = System.currentTimeMillis(),
    val bytesWritten: Long = 0L,
    val isRecording: Boolean = false
)

data class AppSettings(
    val autoStartOnBoot: Boolean = false,
    val autoStartOnWake: Boolean = false,
    val turnOnLastChannel: Boolean = true,
    val confirmExitOnBack: Boolean = true,
    val globalUserAgent: String = "Not set",
    val udpProxy: String = "Not set",
    val pastDaysToKeepEpg: Int = 1,
    val storeProgramDescriptions: Boolean = true,
    val epgUpdateIntervalHours: Int = 24,
    val epgUpdateOnStart: Boolean = false,
    val epgUpdateOnPlaylistChange: Boolean = false,
    val lastEpgUpdateStatus: String = "Never updated",
    val channelsSorting: String = "By order in playlist",
    val tvGuidePreview: Boolean = true,
    val showChannelNumbers: Boolean = true,
    val showChannelNames: Boolean = true,
    val twoLineChannelNames: Boolean = false,
    val showCatchupIcon: Boolean = true,
    val highlightCurrentChannel: Boolean = true,
    val twoLineProgramTitles: Boolean = false,
    val highlightCurrentProgramsInColor: Boolean = true,
    val dimPastPrograms: Boolean = false,
    val showProgramsInList: Boolean = true,
    val showProgramDescriptionInList: Boolean = false,
    val autoplayChannels: Boolean = false,
    val stayOnListWhenSwitching: Boolean = false,
    val animatedTransition: Boolean = true,
    val showInfoPanel: Boolean = true,
    val showTvGuideButton: Boolean = true,
    val showHistoryButton: Boolean = true,
    val historyDayCount: Int = 7,
    val delayBeforeHistorySec: Int = 10,
    val showCurrentProgramsInHistory: Boolean = true,
    val showPastProgramsWithoutCatchup: Boolean = false,
    val recentChannelCount: Int = 10,
    val delayBeforeRecentSec: Int = 5,
    val showChannelNamesInRecent: Boolean = true,
    val playerClockPosition: String = "Top right",
    val panelsTimeoutSec: Int = 5,
    val showBlackScreenWhenSwitching: Boolean = false,
    val menuShowSearch: Boolean = true,
    val menuShowChannelsList: Boolean = true,
    val menuShowRecordings: Boolean = true,
    val menuShowMultiview: Boolean = true,
    val menuShowPip: Boolean = true,
    val menuShowHdr: Boolean = true,
    val menuShowVideoTracks: Boolean = true,
    val menuShowAudioTracks: Boolean = true,
    val menuShowAudioOffset: Boolean = true,
    val menuShowClosedCaptions: Boolean = true,
    val menuShowDisplayMode: Boolean = true,
    val menuShowSleepTimer: Boolean = true,
    val menuShowFavorite: Boolean = true,
    val groupsSorting: String = "By order in playlist",
    val showFavoritesCategory: Boolean = true,
    val showAllChannelsCategory: Boolean = true,
    val showUncategorizedCategory: Boolean = true,
    val globalLogosPriority: String = "Prefer logos from playlist",
    val logosFolder: String = "",
    val inexactLogosMatching: Boolean = false,
    val language: String = "System",
    val fontSize: String = "Medium",
    val backgroundColorName: String = "Dark",
    val accentColorName: String = "Blue",
    val selectionColorName: String = "Blue",
    val uiTransparencyPercent: Int = 50,
    val bufferSize: String = "Normal",
    val audioDecoder: String = "Hardware",
    val videoDecoder: String = "Hardware",
    val afrEnableTv: Boolean = false,
    val afrEnableVod: Boolean = false,
    val afrSwitchRefreshRate: Boolean = false,
    val afrOnly5060: Boolean = false,
    val afrSwitchResolution: Boolean = false,
    val afrDelaySec: Int = 0,
    val selectSurroundByDefault: Boolean = false,
    val audioPassthrough: Boolean = false,
    val useExternalPlayer: String = "No",
    val skipStepSec: Int = 10,
    val hdrBoostDefaultOn: Boolean = true,
    val seekRwFfCatchup: Boolean = true,
    val seekRwLiveCatchup: Boolean = false,
    val seekLeftRightCatchup: Boolean = false,
    val seekLeftLiveCatchup: Boolean = false,
    val seekDownUpCatchup: Boolean = false,
    val seekDownLiveCatchup: Boolean = false,
    val parentalPin: String = "",
    val parentalEnabled: Boolean = false,
    val remindBeforeMin: Int = 5,
    val reminderPopupTimeoutSec: Int = 15,
    val reminderAutoSwitch: Boolean = false,
    val reminderWakeFromSleep: Boolean = false,
    val autoplayNextEpisode: Boolean = true,
    val globalDisplayMode: DisplayMode = DisplayMode.NORMAL,
    val vodSorting: String = "By order in playlist",
    val groupAllMoviesByCategories: Boolean = false
)
