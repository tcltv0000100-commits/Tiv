package com.tiviplayer.app.network

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.tiviplayer.app.data.ChannelItem
import com.tiviplayer.app.data.EpgProgram
import com.tiviplayer.app.data.EpisodeItem
import com.tiviplayer.app.data.GroupItem
import com.tiviplayer.app.data.PlaylistConfig
import com.tiviplayer.app.data.PlaylistType
import com.tiviplayer.app.data.StalkerDeviceUtils
import com.tiviplayer.app.data.VodItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class LoadedPlaylistData(
    val updatedConfig: PlaylistConfig,
    val groups: List<GroupItem>,
    val channels: List<ChannelItem>,
    val movies: List<VodItem>,
    val shows: List<VodItem>,
    val epgPrograms: List<EpgProgram> = emptyList()
)

object PlaylistClients {
    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val gson = Gson()

    suspend fun loadPlaylist(config: PlaylistConfig, rawLocalContent: String? = null): LoadedPlaylistData =
        withContext(Dispatchers.IO) {
            when (config.type) {
                PlaylistType.M3U -> loadM3u(config, rawLocalContent)
                PlaylistType.XTREAM -> loadXtream(config)
                PlaylistType.STALKER -> loadStalker(config)
            }
        }

    // -------------------------------------------------------------------------
    // 1. M3U / M3U8 + XMLTV EPG PARSER
    // -------------------------------------------------------------------------
    private fun loadM3u(config: PlaylistConfig, rawLocalContent: String?): LoadedPlaylistData {
        val text = rawLocalContent ?: fetchText(
            url = config.url,
            userAgent = config.userAgent.takeIf { it != "Not set" && it.isNotBlank() } ?: "Mozilla/5.0"
        )
        val channels = mutableListOf<ChannelItem>()
        val movies = mutableListOf<VodItem>()
        val groupNames = linkedSetOf<String>()

        var currentTitle = ""
        var currentLogo = ""
        var currentGroup = "Uncategorized"
        var currentTvgId = ""
        var currentCatchup = false
        var chNum = 1

        val lines = text.lineSequence()
        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF:", ignoreCase = true)) {
                currentTitle = line.substringAfterLast(",", "").trim().ifEmpty { "Channel $chNum" }
                currentLogo = extractAttr(line, "tvg-logo")
                currentGroup = extractAttr(line, "group-title").ifEmpty { "Uncategorized" }
                currentTvgId = extractAttr(line, "tvg-id")
                currentCatchup = line.contains("catchup=", ignoreCase = true)
            } else if (!line.startsWith("#")) {
                groupNames.add(currentGroup)
                if (config.isVodOnly) {
                    movies.add(
                        VodItem(
                            id = "${config.id}_vod_$chNum",
                            playlistId = config.id,
                            title = currentTitle.ifEmpty { "Video $chNum" },
                            isSeries = false,
                            groupId = currentGroup,
                            groupName = currentGroup,
                            posterUrl = currentLogo,
                            streamUrl = line
                        )
                    )
                } else {
                    channels.add(
                        ChannelItem(
                            id = "${config.id}_ch_$chNum",
                            playlistId = config.id,
                            number = chNum,
                            name = currentTitle.ifEmpty { "Channel $chNum" },
                            groupId = currentGroup,
                            groupName = currentGroup,
                            logoUrl = currentLogo,
                            streamUrl = line,
                            tvgId = currentTvgId,
                            hasCatchup = currentCatchup
                        )
                    )
                }
                chNum++
                currentTitle = ""
                currentLogo = ""
                currentGroup = "Uncategorized"
                currentTvgId = ""
                currentCatchup = false
            }
        }

        val groups = groupNames.mapIndexed { idx, name ->
            GroupItem(
                id = "${config.id}_grp_$idx",
                playlistId = config.id,
                name = name,
                categoryType = if (config.isVodOnly) "Movies" else "TV",
                visible = true,
                orderIndex = idx
            )
        }

        val epgPrograms = if (config.epgUrl.isNotBlank()) {
            runCatching { parseXmltv(fetchText(config.epgUrl, "Mozilla/5.0")) }.getOrDefault(emptyList())
        } else emptyList()

        val updated = config.copy(
            channelsCount = channels.size,
            moviesCount = movies.size,
            showsCount = 0
        )
        return LoadedPlaylistData(updated, groups, channels, movies, emptyList(), epgPrograms)
    }

    private fun extractAttr(line: String, attr: String): String {
        val regex = Regex("""$attr="([^"]*)"""", RegexOption.IGNORE_CASE)
        return regex.find(line)?.groupValues?.getOrNull(1)?.trim() ?: ""
    }

    fun parseXmltv(xml: String): List<EpgProgram> {
        val list = mutableListOf<EpgProgram>()
        val fmt = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
        val progRegex = Regex("""<programme\s+([^>]*)>(.*?)</programme>""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val titleRegex = Regex("""<title[^>]*>(.*?)</title>""", RegexOption.DOT_MATCHES_ALL)
        val descRegex = Regex("""<desc[^>]*>(.*?)</desc>""", RegexOption.DOT_MATCHES_ALL)

        for (match in progRegex.findAll(xml).take(5000)) {
            val attrs = match.groupValues[1]
            val body = match.groupValues[2]
            val channel = extractAttr(attrs, "channel")
            val startRaw = extractAttr(attrs, "start").take(14)
            val stopRaw = extractAttr(attrs, "stop").take(14)
            val startMs = runCatching { fmt.parse(startRaw)?.time ?: 0L }.getOrDefault(0L)
            val endMs = runCatching { fmt.parse(stopRaw)?.time ?: (startMs + 3600_000L) }.getOrDefault(startMs + 3600_000L)
            val title = titleRegex.find(body)?.groupValues?.getOrNull(1)?.trim() ?: "No information"
            val desc = descRegex.find(body)?.groupValues?.getOrNull(1)?.trim() ?: "No information"
            if (channel.isNotEmpty() && startMs > 0L) {
                list.add(EpgProgram(channel, title, desc, startMs, endMs))
            }
        }
        return list
    }

    // -------------------------------------------------------------------------
    // 2. XTREAM CODES API CLIENT (from Xtreme.py)
    // -------------------------------------------------------------------------
    private fun loadXtream(config: PlaylistConfig): LoadedPlaylistData {
        val base = normalizeHttpBase(config.url)
        val u = URLEncoder.encode(config.username.trim(), "UTF-8")
        val p = URLEncoder.encode(config.password.trim(), "UTF-8")
        val ua = config.userAgent.takeIf { it != "Not set" && it.isNotBlank() } ?: "Mozilla/5.0"

        val authJson = fetchText("$base/player_api.php?username=$u&password=$p", ua)
        val authObj = runCatching { JsonParser.parseString(authJson).asJsonObject }.getOrNull()
        val userInfo = authObj?.getAsJsonObject("user_info")
        val expDateRaw = userInfo?.get("exp_date")?.takeIf { !it.isJsonNull }?.asString ?: ""
        val expFormatted = expDateRaw.toLongOrNull()?.let {
            SimpleDateFormat("dd/MM/yy", Locale.US).format(Date(it * 1000L))
        } ?: "Unlimited"
        val maxConn = userInfo?.get("max_connections")?.takeIf { !it.isJsonNull }?.asString ?: "1"

        val groups = mutableListOf<GroupItem>()
        val channels = mutableListOf<ChannelItem>()
        val movies = mutableListOf<VodItem>()
        val shows = mutableListOf<VodItem>()

        val ext = if (config.outputFormat.equals("HLS", ignoreCase = true)) "m3u8" else "ts"

        if (config.includeTv) {
            val catMap = mutableMapOf<String, String>()
            val catJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_live_categories", ua) }.getOrDefault("[]")
            parseArray(catJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("category_id")
                val cname = obj.str("category_name").ifEmpty { "TV $idx" }
                catMap[cid] = cname
                groups.add(GroupItem("${config.id}_tv_$cid", config.id, cname, "TV", true, idx))
            }
            val streamsJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_live_streams", ua) }.getOrDefault("[]")
            parseArray(streamsJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val sid = obj.str("stream_id")
                val cid = obj.str("category_id")
                val cname = catMap[cid] ?: "Uncategorized"
                val num = obj.str("num").toIntOrNull() ?: (idx + 1)
                channels.add(
                    ChannelItem(
                        id = "${config.id}_xt_ch_$sid",
                        playlistId = config.id,
                        number = num,
                        name = obj.str("name").ifEmpty { "Channel $num" },
                        groupId = cid,
                        groupName = cname,
                        logoUrl = obj.str("stream_icon"),
                        streamUrl = "$base/live/$u/$p/$sid.$ext",
                        tvgId = obj.str("epg_channel_id"),
                        hasCatchup = obj.str("tv_archive") == "1"
                    )
                )
            }
        }

        if (config.includeVod) {
            // Movies
            val vodCatMap = mutableMapOf<String, String>()
            val vodCatJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_vod_categories", ua) }.getOrDefault("[]")
            parseArray(vodCatJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("category_id")
                val cname = obj.str("category_name").ifEmpty { "Movies $idx" }
                vodCatMap[cid] = cname
                groups.add(GroupItem("${config.id}_mov_$cid", config.id, cname, "Movies", true, idx))
            }
            val vodJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_vod_streams", ua) }.getOrDefault("[]")
            parseArray(vodJson).forEach { el ->
                val obj = el.asJsonObject
                val sid = obj.str("stream_id")
                val cid = obj.str("category_id")
                val container = obj.str("container_extension").ifEmpty { "mp4" }
                movies.add(
                    VodItem(
                        id = "${config.id}_xt_mov_$sid",
                        playlistId = config.id,
                        title = obj.str("name"),
                        isSeries = false,
                        groupId = cid,
                        groupName = vodCatMap[cid] ?: "Movies",
                        posterUrl = obj.str("stream_icon"),
                        backdropUrl = obj.str("stream_icon"),
                        rating = obj.str("rating"),
                        streamUrl = "$base/movie/$u/$p/$sid.$container",
                        containerExt = container,
                        addedTimestamp = obj.str("added").toLongOrNull() ?: 0L
                    )
                )
            }

            // Series / Shows
            val serCatMap = mutableMapOf<String, String>()
            val serCatJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_series_categories", ua) }.getOrDefault("[]")
            parseArray(serCatJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("category_id")
                val cname = obj.str("category_name").ifEmpty { "Shows $idx" }
                serCatMap[cid] = cname
                groups.add(GroupItem("${config.id}_ser_$cid", config.id, cname, "Shows", true, idx))
            }
            val serJson = runCatching { fetchText("$base/player_api.php?username=$u&password=$p&action=get_series", ua) }.getOrDefault("[]")
            parseArray(serJson).forEach { el ->
                val obj = el.asJsonObject
                val sid = obj.str("series_id")
                val cid = obj.str("category_id")
                shows.add(
                    VodItem(
                        id = "${config.id}_xt_ser_$sid",
                        playlistId = config.id,
                        title = obj.str("name"),
                        isSeries = true,
                        groupId = cid,
                        groupName = serCatMap[cid] ?: "Shows",
                        posterUrl = obj.str("cover"),
                        backdropUrl = obj.str("backdrop_path").ifEmpty { obj.str("cover") },
                        rating = obj.str("rating"),
                        year = obj.str("releaseDate").take(4),
                        genres = obj.str("genre"),
                        cast = obj.str("cast"),
                        description = obj.str("plot"),
                        cmd = sid
                    )
                )
            }
        }

        val updated = config.copy(
            expirationDate = expFormatted,
            maxConnections = maxConn,
            channelsCount = channels.size,
            moviesCount = movies.size,
            showsCount = shows.size
        )
        return LoadedPlaylistData(updated, groups, channels, movies, shows)
    }

    suspend fun fetchXtreamSeriesEpisodes(config: PlaylistConfig, seriesId: String): List<EpisodeItem> =
        withContext(Dispatchers.IO) {
            val base = normalizeHttpBase(config.url)
            val u = URLEncoder.encode(config.username.trim(), "UTF-8")
            val p = URLEncoder.encode(config.password.trim(), "UTF-8")
            val json = fetchText("$base/player_api.php?username=$u&password=$p&action=get_series_info&series_id=$seriesId", "Mozilla/5.0")
            val obj = runCatching { JsonParser.parseString(json).asJsonObject }.getOrNull() ?: return@withContext emptyList()
            val episodesObj = obj.getAsJsonObject("episodes") ?: return@withContext emptyList()
            val list = mutableListOf<EpisodeItem>()
            for ((seasonKey, arrEl) in episodesObj.entrySet()) {
                val seasonNum = seasonKey.toIntOrNull() ?: 1
                if (!arrEl.isJsonArray) continue
                arrEl.asJsonArray.forEach { epEl ->
                    val ep = epEl.asJsonObject
                    val eid = ep.str("id")
                    val ext = ep.str("container_extension").ifEmpty { "mp4" }
                    list.add(
                        EpisodeItem(
                            id = eid,
                            season = seasonNum,
                            episodeNum = ep.str("episode_num").toIntOrNull() ?: 1,
                            title = ep.str("title").ifEmpty { "Episode ${ep.str("episode_num")}" },
                            streamUrl = "$base/series/$u/$p/$eid.$ext"
                        )
                    )
                }
            }
            list.sortedWith(compareBy({ it.season }, { it.episodeNum }))
        }

    // -------------------------------------------------------------------------
    // 3. STALKER PORTAL API CLIENT (from tiv.py + MD5/SHA256 MAC auto-derivation)
    // -------------------------------------------------------------------------
    private fun loadStalker(config: PlaylistConfig): LoadedPlaylistData {
        val base = normalizeHttpBase(config.url)
        val derived = StalkerDeviceUtils.deriveFromMac(config.macAddress)
        val macUpper = derived.macUpper
        val snCut = config.serialNumber.ifBlank { derived.serialNumber }
        val devId = config.deviceId.ifBlank { derived.deviceId }
        val devId2 = config.deviceId2.ifBlank { devId } // d2 == d1 per user requirement
        val macEncoded = URLEncoder.encode(macUpper, "UTF-8")

        val candidateEndpoints = listOf(
            "portal.php",
            "stalker_portal/server/load.php",
            "server/load.php",
            "c/portal.php",
            "ministra/portal.php"
        )

        var activeEndpoint = config.portalEndpoint.ifBlank { "portal.php" }
        var token = ""
        var random = ""

        for (ep in candidateEndpoints) {
            val hsUrl = "$base/$ep?type=stb&action=handshake&token=&prehash=false&JsHttpRequest=1-xml"
            val resp = runCatching { fetchText(hsUrl, stalkerUserAgent(), stalkerHeaders(base, macEncoded, null)) }.getOrDefault("")
            if (resp.contains("\"token\"")) {
                activeEndpoint = ep
                val js = runCatching { JsonParser.parseString(resp).asJsonObject.getAsJsonObject("js") }.getOrNull()
                token = js?.str("token") ?: ""
                random = js?.str("random") ?: ""
                break
            }
        }

        val authHeaders = stalkerHeaders(base, macEncoded, token)
        val sgHash = StalkerDeviceUtils.sha256Upper(snCut + macUpper)
        val ts = System.currentTimeMillis() / 1000L
        val metrics = URLEncoder.encode(
            """{"mac":"$macUpper","sn":"$snCut","model":"MAG254","type":"STB","uid":"$devId","random":"$random"}""",
            "UTF-8"
        )
        val profileUrl = "$base/$activeEndpoint?type=stb&action=get_profile&hd=1&num_banks=2" +
            "&sn=$snCut&stb_type=MAG254&client_type=STB&image_version=218&video_out=hdmi" +
            "&device_id=$devId&device_id2=$devId2&signature=$sgHash&auth_second_step=1" +
            "&hw_version=1.7-BD-00&not_valid_token=0&metrics=$metrics&timestamp=$ts&JsHttpRequest=1-xml"
        runCatching { fetchText(profileUrl, stalkerUserAgent(), authHeaders) }

        val accJson = runCatching {
            fetchText("$base/$activeEndpoint?type=account_info&action=get_main_info&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
        }.getOrDefault("{}")
        val accJs = runCatching { JsonParser.parseString(accJson).asJsonObject.getAsJsonObject("js") }.getOrNull()
        val expDate = accJs?.str("phone")?.ifEmpty { accJs.str("end_date") }?.ifEmpty { "Unlimited" } ?: "Unlimited"

        val groups = mutableListOf<GroupItem>()
        val channels = mutableListOf<ChannelItem>()
        val movies = mutableListOf<VodItem>()
        val shows = mutableListOf<VodItem>()

        if (config.includeTv) {
            val genreMap = mutableMapOf<String, String>()
            val genresJson = runCatching {
                fetchText("$base/$activeEndpoint?type=itv&action=get_genres&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val genresArr = extractJsArray(genresJson)
            genresArr.forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val gid = obj.str("id")
                val title = obj.str("title").ifEmpty { "TV $idx" }
                genreMap[gid] = title
                groups.add(GroupItem("${config.id}_st_tv_$gid", config.id, title, "TV", true, idx))
            }

            val chJson = runCatching {
                fetchText("$base/$activeEndpoint?type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val chData = runCatching {
                JsonParser.parseString(chJson).asJsonObject.getAsJsonObject("js").getAsJsonArray("data")
            }.getOrNull() ?: JsonArray()

            chData.forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("id")
                val gid = obj.str("tv_genre_id")
                val num = obj.str("number").toIntOrNull() ?: (idx + 1)
                channels.add(
                    ChannelItem(
                        id = "${config.id}_st_ch_$cid",
                        playlistId = config.id,
                        number = num,
                        name = obj.str("name").ifEmpty { "Channel $num" },
                        groupId = gid,
                        groupName = genreMap[gid] ?: "All",
                        logoUrl = obj.str("logo"),
                        cmd = obj.str("cmd"),
                        hasCatchup = obj.str("enable_tv_archive") == "1"
                    )
                )
            }
        }

        if (config.includeVod) {
            val vodCatJson = runCatching {
                fetchText("$base/$activeEndpoint?type=vod&action=get_categories&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val vodCatMap = mutableMapOf<String, String>()
            extractJsArray(vodCatJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("id")
                val title = obj.str("title").ifEmpty { "Movies $idx" }
                vodCatMap[cid] = title
                groups.add(GroupItem("${config.id}_st_mov_$cid", config.id, title, "Movies", true, idx))
            }

            val vodListJson = runCatching {
                fetchText("$base/$activeEndpoint?type=vod&action=get_ordered_list&p=1&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val vodData = runCatching {
                JsonParser.parseString(vodListJson).asJsonObject.getAsJsonObject("js").getAsJsonArray("data")
            }.getOrNull() ?: JsonArray()

            vodData.forEach { el ->
                val obj = el.asJsonObject
                val vid = obj.str("id")
                val cid = obj.str("category_id")
                movies.add(
                    VodItem(
                        id = "${config.id}_st_vod_$vid",
                        playlistId = config.id,
                        title = obj.str("name"),
                        isSeries = false,
                        groupId = cid,
                        groupName = vodCatMap[cid] ?: "Movies",
                        posterUrl = obj.str("screenshot_uri"),
                        backdropUrl = obj.str("screenshot_uri"),
                        rating = obj.str("rating_imdb"),
                        year = obj.str("year"),
                        genres = obj.str("genres_str"),
                        cast = obj.str("actors"),
                        description = obj.str("description"),
                        cmd = obj.str("cmd")
                    )
                )
            }

            val serCatJson = runCatching {
                fetchText("$base/$activeEndpoint?type=series&action=get_categories&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val serCatMap = mutableMapOf<String, String>()
            extractJsArray(serCatJson).forEachIndexed { idx, el ->
                val obj = el.asJsonObject
                val cid = obj.str("id")
                val title = obj.str("title").ifEmpty { "Shows $idx" }
                serCatMap[cid] = title
                groups.add(GroupItem("${config.id}_st_ser_$cid", config.id, title, "Shows", true, idx))
            }

            val serListJson = runCatching {
                fetchText("$base/$activeEndpoint?type=series&action=get_ordered_list&p=1&JsHttpRequest=1-xml", stalkerUserAgent(), authHeaders)
            }.getOrDefault("{}")
            val serData = runCatching {
                JsonParser.parseString(serListJson).asJsonObject.getAsJsonObject("js").getAsJsonArray("data")
            }.getOrNull() ?: JsonArray()

            serData.forEach { el ->
                val obj = el.asJsonObject
                val sid = obj.str("id")
                val cid = obj.str("category_id")
                shows.add(
                    VodItem(
                        id = "${config.id}_st_ser_$sid",
                        playlistId = config.id,
                        title = obj.str("name"),
                        isSeries = true,
                        groupId = cid,
                        groupName = serCatMap[cid] ?: "Shows",
                        posterUrl = obj.str("screenshot_uri"),
                        backdropUrl = obj.str("screenshot_uri"),
                        rating = obj.str("rating_imdb"),
                        year = obj.str("year"),
                        genres = obj.str("genres_str"),
                        cast = obj.str("actors"),
                        description = obj.str("description"),
                        cmd = obj.str("cmd")
                    )
                )
            }
        }

        val updated = config.copy(
            macAddress = macUpper,
            serialNumber = snCut,
            deviceId = devId,
            deviceId2 = devId2,
            portalEndpoint = activeEndpoint,
            token = token,
            expirationDate = expDate,
            channelsCount = channels.size,
            moviesCount = movies.size,
            showsCount = shows.size
        )
        return LoadedPlaylistData(updated, groups, channels, movies, shows)
    }

    suspend fun resolveStalkerStreamUrl(
        config: PlaylistConfig,
        cmd: String,
        mediaType: String = "itv"
    ): String = withContext(Dispatchers.IO) {
        if (cmd.startsWith("http://") || cmd.startsWith("https://")) return@withContext cmd
        val base = normalizeHttpBase(config.url)
        val ep = config.portalEndpoint.ifBlank { "portal.php" }
        val macEncoded = URLEncoder.encode(config.macAddress.uppercase(), "UTF-8")
        val cmdEncoded = URLEncoder.encode(cmd, "UTF-8")
        val url = "$base/$ep?type=$mediaType&action=create_link&cmd=$cmdEncoded&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
        val resp = runCatching {
            fetchText(url, stalkerUserAgent(), stalkerHeaders(base, macEncoded, config.token))
        }.getOrDefault("")
        val jsCmd = runCatching {
            JsonParser.parseString(resp).asJsonObject.getAsJsonObject("js").str("cmd")
        }.getOrDefault("")
        jsCmd.replace("ffmpeg ", "").replace("ffrt ", "").trim()
    }

    private fun stalkerUserAgent(): String =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private fun stalkerHeaders(base: String, macEncoded: String, token: String?): Map<String, String> {
        val map = mutableMapOf(
            "Referer" to "$base/c/",
            "X-User-Agent" to "Model: MAG254; Link: Ethernet",
            "Cookie" to "mac=$macEncoded; stb_lang=en; timezone=UTC;",
            "Accept" to "application/json,application/javascript,text/javascript,*/*"
        )
        if (!token.isNullOrBlank()) {
            map["Authorization"] = "Bearer $token"
        }
        return map
    }

    private fun normalizeHttpBase(raw: String): String {
        var s = raw.trim().removeSuffix("/")
        s = s.removeSuffix("/c")
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "http://$s"
        }
        return s
    }

    private fun fetchText(url: String, userAgent: String, extraHeaders: Map<String, String> = emptyMap()): String {
        val reqBuilder = Request.Builder().url(url).header("User-Agent", userAgent)
        extraHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }
        httpClient.newCall(reqBuilder.build()).execute().use { resp ->
            return resp.body?.string() ?: ""
        }
    }

    private fun parseArray(raw: String): JsonArray =
        runCatching { JsonParser.parseString(raw).asJsonArray }.getOrDefault(JsonArray())

    private fun extractJsArray(raw: String): JsonArray =
        runCatching { JsonParser.parseString(raw).asJsonObject.getAsJsonArray("js") }.getOrDefault(JsonArray())

    private fun JsonObject.str(key: String): String {
        val el = get(key) ?: return ""
        return if (el.isJsonNull) "" else el.asString
    }
}
