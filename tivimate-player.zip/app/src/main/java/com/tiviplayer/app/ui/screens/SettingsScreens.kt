package com.tiviplayer.app.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.tiviplayer.app.data.PlaylistConfig
import com.tiviplayer.app.data.PlaylistType
import com.tiviplayer.app.network.PlaylistClients
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.components.*
import com.tiviplayer.app.ui.theme.TiviColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

private enum class SettingsPage {
    ROOT, GENERAL, GENERAL_BACKUP, GENERAL_RESTORE,
    PLAYLISTS, PLAYLIST_DETAIL, PLAYLIST_PARAMS, MANAGE_GROUPS_CAT, MANAGE_GROUPS_LIST,
    EPG, APPEARANCE, APP_TV_GUIDE, APP_PLAYER, APP_PLAYER_LIST, APP_PLAYER_INFO,
    APP_PLAYER_HISTORY, APP_PLAYER_MENU, APP_PLAYER_CLOCK,
    APP_GROUPS, APP_LOGOS, APP_LANGUAGE, APP_THEME, APP_BG_COLOR, APP_ACCENT_COLOR,
    PLAYBACK, PLAYBACK_AFR, REMOTE, REMOTE_TV, REMOTE_PLAYER, PARENTAL, OTHER, OTHER_REMINDERS, OTHER_VOD, ABOUT
}

@Composable
fun SettingsDrawerHost(
    viewModel: MainViewModel,
    onAddPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val groups by viewModel.groups.collectAsState()
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var page by remember { mutableStateOf(SettingsPage.ROOT) }
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var selectedGroupCat by remember { mutableStateOf("TV") }
    var inputDialogTarget by remember { mutableStateOf<String?>(null) }

    val selectedPlaylist: PlaylistConfig? = playlists.find { it.id == selectedPlaylistId }

    val saveBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            scope.launch {
                val json = viewModel.exportBackup()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(it)?.bufferedWriter()?.use { w -> w.write(json) }
                }
                Toast.makeText(context, "Backup saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val openBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            scope.launch {
                val json = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } ?: ""
                }
                val ok = viewModel.restoreBackup(json)
                Toast.makeText(context, if (ok) "Backup restored" else "Invalid backup file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun goBack(): Boolean {
        page = when (page) {
            SettingsPage.ROOT -> return false
            SettingsPage.GENERAL, SettingsPage.PLAYLISTS, SettingsPage.EPG,
            SettingsPage.APPEARANCE, SettingsPage.PLAYBACK, SettingsPage.REMOTE,
            SettingsPage.PARENTAL, SettingsPage.OTHER, SettingsPage.ABOUT -> SettingsPage.ROOT
            SettingsPage.GENERAL_BACKUP, SettingsPage.GENERAL_RESTORE -> SettingsPage.GENERAL
            SettingsPage.PLAYLIST_DETAIL -> SettingsPage.PLAYLISTS
            SettingsPage.PLAYLIST_PARAMS, SettingsPage.MANAGE_GROUPS_CAT -> SettingsPage.PLAYLIST_DETAIL
            SettingsPage.MANAGE_GROUPS_LIST -> SettingsPage.MANAGE_GROUPS_CAT
            SettingsPage.APP_TV_GUIDE, SettingsPage.APP_PLAYER, SettingsPage.APP_GROUPS,
            SettingsPage.APP_LOGOS, SettingsPage.APP_LANGUAGE, SettingsPage.APP_THEME -> SettingsPage.APPEARANCE
            SettingsPage.APP_PLAYER_LIST, SettingsPage.APP_PLAYER_INFO,
            SettingsPage.APP_PLAYER_HISTORY, SettingsPage.APP_PLAYER_MENU, SettingsPage.APP_PLAYER_CLOCK -> SettingsPage.APP_PLAYER
            SettingsPage.APP_BG_COLOR, SettingsPage.APP_ACCENT_COLOR -> SettingsPage.APP_THEME
            SettingsPage.PLAYBACK_AFR -> SettingsPage.PLAYBACK
            SettingsPage.REMOTE_TV, SettingsPage.REMOTE_PLAYER -> SettingsPage.REMOTE
            SettingsPage.OTHER_REMINDERS, SettingsPage.OTHER_VOD -> SettingsPage.OTHER
        }
        return true
    }

    val title = when (page) {
        SettingsPage.ROOT -> "Settings"
        SettingsPage.GENERAL -> "General"
        SettingsPage.GENERAL_BACKUP -> "Backup data"
        SettingsPage.GENERAL_RESTORE -> "Restore data"
        SettingsPage.PLAYLISTS -> "Playlists"
        SettingsPage.PLAYLIST_DETAIL -> selectedPlaylist?.name ?: "Playlist"
        SettingsPage.PLAYLIST_PARAMS -> if (selectedPlaylist?.type == PlaylistType.XTREAM) "Xtream Codes parameters" else "Stalker Portal parameters"
        SettingsPage.MANAGE_GROUPS_CAT -> "Manage groups"
        SettingsPage.MANAGE_GROUPS_LIST -> "Manage groups • $selectedGroupCat"
        SettingsPage.EPG -> "EPG"
        SettingsPage.APPEARANCE -> "Appearance"
        SettingsPage.APP_TV_GUIDE -> "TV guide"
        SettingsPage.APP_PLAYER -> "Player"
        SettingsPage.APP_PLAYER_LIST -> "Channels list"
        SettingsPage.APP_PLAYER_INFO -> "Info panel"
        SettingsPage.APP_PLAYER_HISTORY -> "History / Recent channels"
        SettingsPage.APP_PLAYER_MENU -> "Menu"
        SettingsPage.APP_PLAYER_CLOCK -> "Clock"
        SettingsPage.APP_GROUPS -> "Groups"
        SettingsPage.APP_LOGOS -> "Logos"
        SettingsPage.APP_LANGUAGE -> "Language"
        SettingsPage.APP_THEME -> "Color theme"
        SettingsPage.APP_BG_COLOR -> "Background color"
        SettingsPage.APP_ACCENT_COLOR -> "Accent color"
        SettingsPage.PLAYBACK -> "Playback"
        SettingsPage.PLAYBACK_AFR -> "Auto frame rate (AFR)"
        SettingsPage.REMOTE -> "Remote control"
        SettingsPage.REMOTE_TV -> "TV guide"
        SettingsPage.REMOTE_PLAYER -> "Player"
        SettingsPage.PARENTAL -> "Parental controls"
        SettingsPage.OTHER -> "Other"
        SettingsPage.OTHER_REMINDERS -> "Reminders"
        SettingsPage.OTHER_VOD -> "VOD"
        SettingsPage.ABOUT -> "About"
    }

    TiviRightDrawer(
        title = title,
        onDismiss = { if (!goBack()) onDismiss() }
    ) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
            when (page) {
                SettingsPage.ROOT -> {
                    DrawerMenuItem("General") { page = SettingsPage.GENERAL }
                    DrawerMenuItem("Playlists") { page = SettingsPage.PLAYLISTS }
                    DrawerMenuItem("EPG") { page = SettingsPage.EPG }
                    DrawerMenuItem("Appearance") { page = SettingsPage.APPEARANCE }
                    DrawerMenuItem("Playback") { page = SettingsPage.PLAYBACK }
                    DrawerMenuItem("Remote control") { page = SettingsPage.REMOTE }
                    DrawerMenuItem("Parental controls") { page = SettingsPage.PARENTAL }
                    DrawerMenuItem("Other") { page = SettingsPage.OTHER }
                    DrawerMenuItem("About") { page = SettingsPage.ABOUT }
                }

                SettingsPage.GENERAL -> {
                    DrawerToggleItem("Auto start app on boot", checked = settings.autoStartOnBoot) { v ->
                        viewModel.updateSettings { it.copy(autoStartOnBoot = v) }
                    }
                    DrawerToggleItem("Auto start app on waking from sleep mode", checked = settings.autoStartOnWake) { v ->
                        viewModel.updateSettings { it.copy(autoStartOnWake = v) }
                    }
                    DrawerToggleItem("Turn on last channel on app start", checked = settings.turnOnLastChannel) { v ->
                        viewModel.updateSettings { it.copy(turnOnLastChannel = v) }
                    }
                    DrawerToggleItem("Confirm exit by pressing Back", checked = settings.confirmExitOnBack) { v ->
                        viewModel.updateSettings { it.copy(confirmExitOnBack = v) }
                    }
                    DrawerMenuItem("User-Agent", settings.globalUserAgent) { inputDialogTarget = "global_ua" }
                    DrawerMenuItem("UDP proxy (comma-separated)", settings.udpProxy) { inputDialogTarget = "udp_proxy" }
                    DrawerMenuItem("Backup data") { page = SettingsPage.GENERAL_BACKUP }
                    DrawerMenuItem("Restore data") { page = SettingsPage.GENERAL_RESTORE }
                }

                SettingsPage.GENERAL_BACKUP -> {
                    DrawerMenuItem("Save local backup", "Save to Internal shared storage") {
                        saveBackupLauncher.launch("tivimate_backup.tmb")
                    }
                    DrawerMenuItem("Copy backup to clipboard") {
                        scope.launch {
                            clipboard.setText(AnnotatedString(viewModel.exportBackup()))
                            Toast.makeText(context, "Backup copied", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                SettingsPage.GENERAL_RESTORE -> {
                    DrawerMenuItem("Enter URL") { inputDialogTarget = "restore_url" }
                    DrawerMenuItem("Paste from clipboard") {
                        clipboard.getText()?.text?.let { json ->
                            scope.launch {
                                val ok = viewModel.restoreBackup(json)
                                Toast.makeText(context, if (ok) "Backup restored" else "Invalid backup data", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    DrawerMenuItem("Select local backup") {
                        openBackupLauncher.launch(arrayOf("*/*"))
                    }
                }

                SettingsPage.PLAYLISTS -> {
                    playlists.forEach { pl ->
                        val summary = buildString {
                            append("Channels: ${pl.channelsCount}")
                            if (pl.moviesCount > 0) append(", movies: ${pl.moviesCount}")
                            if (pl.showsCount > 0) append(", shows: ${pl.showsCount}")
                        }
                        DrawerMenuItem(pl.name, summary) {
                            selectedPlaylistId = pl.id
                            page = SettingsPage.PLAYLIST_DETAIL
                        }
                    }
                    HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                    DrawerMenuItem("Add playlist") { onDismiss(); onAddPlaylist() }
                    DrawerMenuItem("Update all playlists") { viewModel.refreshAllPlaylists() }
                    DrawerMenuItem("Playlists sorting", "By name") {}
                    DrawerMenuItem("Reorder playlists") {}
                }

                SettingsPage.PLAYLIST_DETAIL -> {
                    selectedPlaylist?.let { pl ->
                        DrawerToggleItem("Enable playlist", checked = pl.enabled) { v ->
                            viewModel.updatePlaylistConfig(pl.copy(enabled = v))
                        }
                        DrawerMenuItem("Playlist name", pl.name) { inputDialogTarget = "pl_name" }
                        if (pl.type == PlaylistType.M3U) {
                            DrawerMenuItem("Playlist URL", pl.url) { inputDialogTarget = "pl_url" }
                        }
                        DrawerMenuItem("EPG sources", if (pl.epgUrl.isBlank()) "Default source" else pl.epgUrl) { inputDialogTarget = "pl_epg" }
                        DrawerMenuItem("Logos priority", pl.logosPriority) {}
                        DrawerMenuItem("Catch-up", pl.catchupMode) {}
                        DrawerMenuItem("User-Agent", pl.userAgent) { inputDialogTarget = "pl_ua" }
                        if (pl.type != PlaylistType.M3U) {
                            DrawerMenuItem(
                                if (pl.type == PlaylistType.XTREAM) "Xtream Codes parameters" else "Stalker Portal parameters"
                            ) { page = SettingsPage.PLAYLIST_PARAMS }
                        }
                        DrawerMenuItem("Manage groups") { page = SettingsPage.MANAGE_GROUPS_CAT }
                        DrawerSectionHeader("Update options")
                        DrawerMenuItem("Update interval, hours", "${pl.updateIntervalHours}") {}
                        DrawerToggleItem("Update playlist on app start", checked = pl.updateOnStart) { v ->
                            viewModel.updatePlaylistConfig(pl.copy(updateOnStart = v))
                        }
                        DrawerMenuItem("Update playlist") { viewModel.refreshAllPlaylists() }
                        DrawerMenuItem("Delete playlist") {
                            viewModel.deletePlaylist(pl.id)
                            page = SettingsPage.PLAYLISTS
                        }
                    }
                }

                SettingsPage.PLAYLIST_PARAMS -> {
                    selectedPlaylist?.let { pl ->
                        if (pl.type == PlaylistType.XTREAM) {
                            DrawerMenuItem("Username", pl.username) {}
                            DrawerMenuItem("Password", "••••••") {}
                            DrawerMenuItem("Output format", pl.outputFormat) {
                                val next = if (pl.outputFormat == "MPEG-TS") "HLS" else "MPEG-TS"
                                viewModel.updatePlaylistConfig(pl.copy(outputFormat = next))
                            }
                            DrawerToggleItem("Include TV channels", checked = pl.includeTv) { v ->
                                viewModel.updatePlaylistConfig(pl.copy(includeTv = v))
                            }
                            DrawerToggleItem("Include VOD", checked = pl.includeVod) { v ->
                                viewModel.updatePlaylistConfig(pl.copy(includeVod = v))
                            }
                            DrawerMenuItem("Apply changes") { viewModel.refreshAllPlaylists(); page = SettingsPage.PLAYLIST_DETAIL }
                            DrawerMenuItem("Expiration date", pl.expirationDate) {}
                            DrawerMenuItem("Max connections", pl.maxConnections) {}
                        } else {
                            DrawerMenuItem("Server address", pl.url) {}
                            DrawerMenuItem("MAC address", pl.macAddress) {}
                            DrawerMenuItem("Username", pl.username.ifBlank { "Not set" }) {}
                            DrawerMenuItem("Password", if (pl.password.isBlank()) "Not set" else "••••••") {}
                            DrawerMenuItem("Device ID", pl.deviceId) {}
                            DrawerMenuItem("Device ID 2", pl.deviceId2) {}
                            DrawerMenuItem("Serial number", pl.serialNumber) {}
                            DrawerToggleItem("Include TV channels", checked = pl.includeTv) { v ->
                                viewModel.updatePlaylistConfig(pl.copy(includeTv = v))
                            }
                            DrawerToggleItem("Include VOD", checked = pl.includeVod) { v ->
                                viewModel.updatePlaylistConfig(pl.copy(includeVod = v))
                            }
                            DrawerMenuItem("Apply changes") { viewModel.refreshAllPlaylists(); page = SettingsPage.PLAYLIST_DETAIL }
                            DrawerMenuItem("Expiration date", pl.expirationDate) {}
                        }
                    }
                }

                SettingsPage.MANAGE_GROUPS_CAT -> {
                    DrawerMenuItem("TV") { selectedGroupCat = "TV"; page = SettingsPage.MANAGE_GROUPS_LIST }
                    DrawerMenuItem("Movies") { selectedGroupCat = "Movies"; page = SettingsPage.MANAGE_GROUPS_LIST }
                    DrawerMenuItem("Shows") { selectedGroupCat = "Shows"; page = SettingsPage.MANAGE_GROUPS_LIST }
                }

                SettingsPage.MANAGE_GROUPS_LIST -> {
                    selectedPlaylist?.let { pl ->
                        DrawerMenuItem("Groups sorting", "By order in playlist") {}
                        DrawerMenuItem("Show all groups") { viewModel.setAllGroupsVisibility(pl.id, selectedGroupCat, true) }
                        DrawerMenuItem("Hide all groups") { viewModel.setAllGroupsVisibility(pl.id, selectedGroupCat, false) }
                        DrawerSectionHeader("Groups")
                        groups.filter { it.playlistId == pl.id && it.categoryType == selectedGroupCat }.forEach { grp ->
                            DrawerToggleItem(grp.name, checked = grp.visible) {
                                viewModel.toggleGroupVisibility(grp.id)
                            }
                        }
                    }
                }

                SettingsPage.EPG -> {
                    DrawerMenuItem("EPG sources") {}
                    DrawerMenuItem("Past days to keep EPG", "${settings.pastDaysToKeepEpg}") {
                        val next = if (settings.pastDaysToKeepEpg >= 14) 1 else settings.pastDaysToKeepEpg + 1
                        viewModel.updateSettings { it.copy(pastDaysToKeepEpg = next) }
                    }
                    DrawerToggleItem("Store program descriptions", checked = settings.storeProgramDescriptions) { v ->
                        viewModel.updateSettings { it.copy(storeProgramDescriptions = v) }
                    }
                    DrawerSectionHeader("Update options")
                    DrawerMenuItem("Update interval, hours", "${settings.epgUpdateIntervalHours}") {
                        val next = when (settings.epgUpdateIntervalHours) {
                            2 -> 4; 4 -> 8; 8 -> 12; 12 -> 24; 24 -> 48; else -> 2
                        }
                        viewModel.updateSettings { it.copy(epgUpdateIntervalHours = next) }
                    }
                    DrawerToggleItem("Update on app start", checked = settings.epgUpdateOnStart) { v ->
                        viewModel.updateSettings { it.copy(epgUpdateOnStart = v) }
                    }
                    DrawerToggleItem("Update on playlists change", checked = settings.epgUpdateOnPlaylistChange) { v ->
                        viewModel.updateSettings { it.copy(epgUpdateOnPlaylistChange = v) }
                    }
                    DrawerMenuItem("Update EPG") { viewModel.refreshAllPlaylists() }
                    DrawerMenuItem("Clear EPG") { viewModel.updateSettings { it.copy(lastEpgUpdateStatus = "Cleared") } }
                    DrawerMenuItem("Latest update status", settings.lastEpgUpdateStatus) {}
                }

                SettingsPage.APPEARANCE -> {
                    DrawerMenuItem("TV guide") { page = SettingsPage.APP_TV_GUIDE }
                    DrawerMenuItem("Player") { page = SettingsPage.APP_PLAYER }
                    DrawerMenuItem("Groups") { page = SettingsPage.APP_GROUPS }
                    DrawerMenuItem("Logos") { page = SettingsPage.APP_LOGOS }
                    DrawerMenuItem("Language", settings.language) { page = SettingsPage.APP_LANGUAGE }
                    DrawerMenuItem("Font size", settings.fontSize) {
                        val next = when (settings.fontSize) {
                            "Small" -> "Medium"; "Medium" -> "Large"; "Large" -> "Very large"; else -> "Small"
                        }
                        viewModel.updateSettings { it.copy(fontSize = next) }
                    }
                    DrawerMenuItem("Color theme", "${settings.backgroundColorName} • ${settings.accentColorName}") { page = SettingsPage.APP_THEME }
                    DrawerMenuItem("User interface transparency, %", "${settings.uiTransparencyPercent}") {
                        val next = (settings.uiTransparencyPercent + 10) % 100
                        viewModel.updateSettings { it.copy(uiTransparencyPercent = next) }
                    }
                }

                SettingsPage.APP_LANGUAGE -> {
                    listOf("System", "English", "Deutsch", "Español", "Français", "Italiano", "Nederlands", "Polski", "Português", "Русский", "Українська").forEach { lang ->
                        DrawerRadioItem(lang, selected = settings.language == lang) {
                            viewModel.updateSettings { it.copy(language = lang) }
                        }
                    }
                }

                SettingsPage.APP_TV_GUIDE -> {
                    DrawerMenuItem("Channels sorting", settings.channelsSorting) {
                        val next = if (settings.channelsSorting == "By order in playlist") "By name" else "By order in playlist"
                        viewModel.updateSettings { it.copy(channelsSorting = next) }
                    }
                    DrawerToggleItem("Preview", checked = settings.tvGuidePreview) { v -> viewModel.updateSettings { it.copy(tvGuidePreview = v) } }
                    DrawerToggleItem("Show channel numbers", checked = settings.showChannelNumbers) { v -> viewModel.updateSettings { it.copy(showChannelNumbers = v) } }
                    DrawerToggleItem("Show channel names", checked = settings.showChannelNames) { v -> viewModel.updateSettings { it.copy(showChannelNames = v) } }
                    DrawerToggleItem("Two-line channel names", checked = settings.twoLineChannelNames) { v -> viewModel.updateSettings { it.copy(twoLineChannelNames = v) } }
                    DrawerToggleItem("Show catch-up icon in channels list", checked = settings.showCatchupIcon) { v -> viewModel.updateSettings { it.copy(showCatchupIcon = v) } }
                    DrawerToggleItem("Highlight current channel in color", checked = settings.highlightCurrentChannel) { v -> viewModel.updateSettings { it.copy(highlightCurrentChannel = v) } }
                    DrawerToggleItem("Two-line program titles", checked = settings.twoLineProgramTitles) { v -> viewModel.updateSettings { it.copy(twoLineProgramTitles = v) } }
                }

                SettingsPage.APP_PLAYER -> {
                    DrawerMenuItem("Channels list") { page = SettingsPage.APP_PLAYER_LIST }
                    DrawerMenuItem("Info panel") { page = SettingsPage.APP_PLAYER_INFO }
                    DrawerMenuItem("History / Recent channels") { page = SettingsPage.APP_PLAYER_HISTORY }
                    DrawerMenuItem("Menu") { page = SettingsPage.APP_PLAYER_MENU }
                    DrawerMenuItem("Clock", settings.playerClockPosition) { page = SettingsPage.APP_PLAYER_CLOCK }
                    DrawerMenuItem("Panels timeout, sec", "${settings.panelsTimeoutSec}") {
                        val next = if (settings.panelsTimeoutSec >= 10) 1 else settings.panelsTimeoutSec + 1
                        viewModel.updateSettings { it.copy(panelsTimeoutSec = next) }
                    }
                    DrawerToggleItem("Show black screen when switching channels", checked = settings.showBlackScreenWhenSwitching) { v ->
                        viewModel.updateSettings { it.copy(showBlackScreenWhenSwitching = v) }
                    }
                }

                SettingsPage.APP_PLAYER_CLOCK -> {
                    listOf("Off", "Top right", "Top left", "Bottom right", "Bottom left").forEach { pos ->
                        DrawerRadioItem(pos, selected = settings.playerClockPosition == pos) {
                            viewModel.updateSettings { it.copy(playerClockPosition = pos) }
                        }
                    }
                }

                SettingsPage.APP_PLAYER_LIST -> {
                    DrawerToggleItem("Highlight current programs in color", checked = settings.highlightCurrentProgramsInColor) { v -> viewModel.updateSettings { it.copy(highlightCurrentProgramsInColor = v) } }
                    DrawerToggleItem("Dim past programs", checked = settings.dimPastPrograms) { v -> viewModel.updateSettings { it.copy(dimPastPrograms = v) } }
                    DrawerToggleItem("Show programs", checked = settings.showProgramsInList) { v -> viewModel.updateSettings { it.copy(showProgramsInList = v) } }
                    DrawerToggleItem("Show program description", checked = settings.showProgramDescriptionInList) { v -> viewModel.updateSettings { it.copy(showProgramDescriptionInList = v) } }
                    DrawerToggleItem("Autoplay channels", checked = settings.autoplayChannels) { v -> viewModel.updateSettings { it.copy(autoplayChannels = v) } }
                    DrawerToggleItem("Stay on list when switching channels", checked = settings.stayOnListWhenSwitching) { v -> viewModel.updateSettings { it.copy(stayOnListWhenSwitching = v) } }
                    DrawerToggleItem("Animated transition", checked = settings.animatedTransition) { v -> viewModel.updateSettings { it.copy(animatedTransition = v) } }
                }

                SettingsPage.APP_PLAYER_INFO -> {
                    DrawerToggleItem("Info bar", checked = settings.showInfoPanel) { v -> viewModel.updateSettings { it.copy(showInfoPanel = v) } }
                    DrawerToggleItem("Show clock", checked = settings.showClockInInfoPanel) { v -> viewModel.updateSettings { it.copy(showClockInInfoPanel = v) } }
                    DrawerToggleItem("Show channel number", checked = settings.showChannelNumberInInfoPanel) { v -> viewModel.updateSettings { it.copy(showChannelNumberInInfoPanel = v) } }
                    DrawerToggleItem("Show playlist/group name", checked = settings.showPlaylistGroupInInfoPanel) { v -> viewModel.updateSettings { it.copy(showPlaylistGroupInInfoPanel = v) } }
                    DrawerToggleItem("Show program description", checked = settings.showProgramDescInInfoPanel) { v -> viewModel.updateSettings { it.copy(showProgramDescInInfoPanel = v) } }
                    DrawerToggleItem("Show video resolution and badges", checked = settings.showVideoResBadges) { v -> viewModel.updateSettings { it.copy(showVideoResBadges = v) } }
                    DrawerToggleItem("Show audio/subtitles info", checked = settings.showAudioSubInfo) { v -> viewModel.updateSettings { it.copy(showAudioSubInfo = v) } }
                }

                SettingsPage.APP_PLAYER_HISTORY -> {
                    DrawerToggleItem("Show \"TV guide\" button", checked = settings.showTvGuideButton) { v -> viewModel.updateSettings { it.copy(showTvGuideButton = v) } }
                    DrawerToggleItem("Show \"History\" button", checked = settings.showHistoryButton) { v -> viewModel.updateSettings { it.copy(showHistoryButton = v) } }
                    DrawerSectionHeader("History")
                    DrawerMenuItem("History day count", "${settings.historyDayCount}") {}
                    DrawerMenuItem("Delay before adding to history, sec", "${settings.delayBeforeHistorySec}") {}
                    DrawerToggleItem("Show current programs", checked = settings.showCurrentProgramsInHistory) { v -> viewModel.updateSettings { it.copy(showCurrentProgramsInHistory = v) } }
                    DrawerToggleItem("Show past programs without catch-up", checked = settings.showPastProgramsWithoutCatchup) { v -> viewModel.updateSettings { it.copy(showPastProgramsWithoutCatchup = v) } }
                    DrawerSectionHeader("Recent channels")
                    DrawerMenuItem("Recent channel count", "${settings.recentChannelCount}") {}
                    DrawerMenuItem("Delay before adding to recent channels, sec", "${settings.delayBeforeRecentSec}") {}
                    DrawerToggleItem("Show channel names", checked = settings.showChannelNamesInRecent) { v -> viewModel.updateSettings { it.copy(showChannelNamesInRecent = v) } }
                }

                SettingsPage.APP_PLAYER_MENU -> {
                    DrawerToggleItem("Search", checked = settings.menuShowSearch) { v -> viewModel.updateSettings { it.copy(menuShowSearch = v) } }
                    DrawerToggleItem("Channels list", checked = settings.menuShowChannelsList) { v -> viewModel.updateSettings { it.copy(menuShowChannelsList = v) } }
                    DrawerToggleItem("Recordings", checked = settings.menuShowRecordings) { v -> viewModel.updateSettings { it.copy(menuShowRecordings = v) } }
                    DrawerToggleItem("Multiview", checked = settings.menuShowMultiview) { v -> viewModel.updateSettings { it.copy(menuShowMultiview = v) } }
                    DrawerToggleItem("Picture-in-picture", checked = settings.menuShowPip) { v -> viewModel.updateSettings { it.copy(menuShowPip = v) } }
                    DrawerToggleItem("HDR Boost", checked = settings.menuShowHdr) { v -> viewModel.updateSettings { it.copy(menuShowHdr = v) } }
                    DrawerToggleItem("Video tracks", checked = settings.menuShowVideoTracks) { v -> viewModel.updateSettings { it.copy(menuShowVideoTracks = v) } }
                    DrawerToggleItem("Audio tracks", checked = settings.menuShowAudioTracks) { v -> viewModel.updateSettings { it.copy(menuShowAudioTracks = v) } }
                    DrawerToggleItem("Audio offset", checked = settings.menuShowAudioOffset) { v -> viewModel.updateSettings { it.copy(menuShowAudioOffset = v) } }
                    DrawerToggleItem("Closed captions", checked = settings.menuShowClosedCaptions) { v -> viewModel.updateSettings { it.copy(menuShowClosedCaptions = v) } }
                    DrawerToggleItem("Display mode", checked = settings.menuShowDisplayMode) { v -> viewModel.updateSettings { it.copy(menuShowDisplayMode = v) } }
                    DrawerToggleItem("Sleep timer", checked = settings.menuShowSleepTimer) { v -> viewModel.updateSettings { it.copy(menuShowSleepTimer = v) } }
                    DrawerToggleItem("Change Favorite status", checked = settings.menuShowFavorite) { v -> viewModel.updateSettings { it.copy(menuShowFavorite = v) } }
                }

                SettingsPage.APP_GROUPS -> {
                    DrawerMenuItem("Groups sorting", settings.groupsSorting) {}
                    DrawerToggleItem("Show \"Favorites\" category", checked = settings.showFavoritesCategory) { v -> viewModel.updateSettings { it.copy(showFavoritesCategory = v) } }
                    DrawerToggleItem("Show \"All channels\" category", checked = settings.showAllChannelsCategory) { v -> viewModel.updateSettings { it.copy(showAllChannelsCategory = v) } }
                    DrawerToggleItem("Show \"Uncategorized\" category", checked = settings.showUncategorizedCategory) { v -> viewModel.updateSettings { it.copy(showUncategorizedCategory = v) } }
                }

                SettingsPage.APP_LOGOS -> {
                    DrawerMenuItem("Logos priority", settings.globalLogosPriority) {}
                    DrawerMenuItem("Logos folder", settings.logosFolder.ifBlank { "Not set" }) {}
                    DrawerToggleItem("Inexact matching for logos files", checked = settings.inexactLogosMatching) { v -> viewModel.updateSettings { it.copy(inexactLogosMatching = v) } }
                    DrawerMenuItem("Clear logos cache") {}
                }

                SettingsPage.APP_THEME -> {
                    DrawerMenuItem("Background color", settings.backgroundColorName) { page = SettingsPage.APP_BG_COLOR }
                    DrawerMenuItem("Accent color", settings.accentColorName) { page = SettingsPage.APP_ACCENT_COLOR }
                }

                SettingsPage.APP_BG_COLOR -> {
                    listOf("Dark", "Black", "Red", "Pink", "Purple", "Indigo", "Blue", "Cyan", "Teal", "Green", "Lime", "Yellow").forEach { c ->
                        DrawerRadioItem(c, selected = settings.backgroundColorName == c, colorDot = TiviColors.resolveColor(c, TiviColors.BgRoot)) {
                            viewModel.updateSettings { it.copy(backgroundColorName = c) }
                        }
                    }
                }

                SettingsPage.APP_ACCENT_COLOR -> {
                    listOf("Blue", "Red", "Pink", "Purple", "Indigo", "Cyan", "Teal", "Green", "Lime", "Yellow").forEach { c ->
                        DrawerRadioItem(c, selected = settings.accentColorName == c, colorDot = TiviColors.resolveColor(c, TiviColors.AccentBlue)) {
                            viewModel.updateSettings { it.copy(accentColorName = c) }
                        }
                    }
                }

                SettingsPage.PLAYBACK -> {
                    DrawerToggleItem("HDR color boost (Default ON)", checked = settings.hdrBoostDefaultOn) { v ->
                        viewModel.updateSettings { it.copy(hdrBoostDefaultOn = v) }
                    }
                    DrawerMenuItem("Buffer size", settings.bufferSize) {
                        val next = when (settings.bufferSize) {
                            "None" -> "Small"; "Small" -> "Normal"; "Normal" -> "Large"; "Large" -> "Very large"; else -> "None"
                        }
                        viewModel.updateSettings { it.copy(bufferSize = next) }
                    }
                    DrawerMenuItem("Audio decoder", settings.audioDecoder) {
                        val next = if (settings.audioDecoder == "Hardware") "Software" else "Hardware"
                        viewModel.updateSettings { it.copy(audioDecoder = next) }
                    }
                    DrawerMenuItem("Video decoder", settings.videoDecoder) {
                        val next = if (settings.videoDecoder == "Hardware") "Software" else "Hardware"
                        viewModel.updateSettings { it.copy(videoDecoder = next) }
                    }
                    DrawerMenuItem("Auto frame rate (AFR)") { page = SettingsPage.PLAYBACK_AFR }
                    DrawerToggleItem("Select surround audio tracks by default", checked = settings.selectSurroundByDefault) { v ->
                        viewModel.updateSettings { it.copy(selectSurroundByDefault = v) }
                    }
                    DrawerToggleItem("Audio passthrough", checked = settings.audioPassthrough) { v ->
                        viewModel.updateSettings { it.copy(audioPassthrough = v) }
                    }
                    DrawerMenuItem("Use external player", settings.useExternalPlayer) {
                        val next = when (settings.useExternalPlayer) {
                            "No" -> "Yes"; "Yes" -> "For VOD only"; else -> "No"
                        }
                        viewModel.updateSettings { it.copy(useExternalPlayer = next) }
                    }
                    DrawerMenuItem("Skip steps", "${settings.skipStepSec} sec") {
                        val next = if (settings.skipStepSec >= 60) 10 else settings.skipStepSec + 10
                        viewModel.updateSettings { it.copy(skipStepSec = next) }
                    }
                }

                SettingsPage.PLAYBACK_AFR -> {
                    DrawerToggleItem("Enable for TV", checked = settings.afrEnableTv) { v -> viewModel.updateSettings { it.copy(afrEnableTv = v) } }
                    DrawerToggleItem("Enable for VOD", checked = settings.afrEnableVod) { v -> viewModel.updateSettings { it.copy(afrEnableVod = v) } }
                    DrawerToggleItem("Switch screen refresh rate", checked = settings.afrSwitchRefreshRate) { v -> viewModel.updateSettings { it.copy(afrSwitchRefreshRate = v) } }
                    DrawerToggleItem("Switch rate for 50/60 FPS only", checked = settings.afrOnly5060) { v -> viewModel.updateSettings { it.copy(afrOnly5060 = v) } }
                    DrawerToggleItem("Switch screen resolution", checked = settings.afrSwitchResolution) { v -> viewModel.updateSettings { it.copy(afrSwitchResolution = v) } }
                    DrawerMenuItem("Delay before switching, sec", "${settings.afrDelaySec}") {}
                }

                SettingsPage.REMOTE -> {
                    DrawerMenuItem("TV guide") { page = SettingsPage.REMOTE_TV }
                    DrawerMenuItem("Player") { page = SettingsPage.REMOTE_PLAYER }
                    DrawerSectionHeader("Seeking options")
                    DrawerToggleItem("Use RW/FF/Pause for seeking/pause while watching catch-up", checked = settings.seekRwFfCatchup) { v -> viewModel.updateSettings { it.copy(seekRwFfCatchup = v) } }
                    DrawerToggleItem("Use RW to rewind live stream with catch-up", checked = settings.seekRwLiveCatchup) { v -> viewModel.updateSettings { it.copy(seekRwLiveCatchup = v) } }
                    DrawerToggleItem("Use Left/Right for seeking while watching catch-up", checked = settings.seekLeftRightCatchup) { v -> viewModel.updateSettings { it.copy(seekLeftRightCatchup = v) } }
                    DrawerToggleItem("Use Left to rewind live stream with catch-up", checked = settings.seekLeftLiveCatchup) { v -> viewModel.updateSettings { it.copy(seekLeftLiveCatchup = v) } }
                    DrawerToggleItem("Use Down/Up for seeking while watching catch-up", checked = settings.seekDownUpCatchup) { v -> viewModel.updateSettings { it.copy(seekDownUpCatchup = v) } }
                    DrawerToggleItem("Use Down to rewind live stream with catch-up", checked = settings.seekDownLiveCatchup) { v -> viewModel.updateSettings { it.copy(seekDownLiveCatchup = v) } }
                }

                SettingsPage.REMOTE_TV -> {
                    listOf("OK" to "Select channel", "Long OK" to "Show menu", "Back" to "Go back", "Long Back" to "Show TV guide",
                        "Left" to "Show groups", "Long Left" to "Navigate to past programs", "Right" to "Scroll right", "Up/Down" to "Navigate channels",
                        "Restore to defaults" to "").forEach { (k, v) ->
                        DrawerMenuItem(k, v.ifBlank { null }) {}
                    }
                }

                SettingsPage.REMOTE_PLAYER -> {
                    listOf("OK" to "Show channels list", "Long OK" to "Show menu", "Back" to "Go back", "Long Back" to "Stop playback",
                        "Left" to "Show channels list in overlay mode", "Long Left" to "Show channels list in preview mode",
                        "Right" to "Turn on most recent channel", "Long Right" to "Show program description",
                        "Up/Down" to "Next/Previous channel", "Volume up/down" to "Volume", "Mute" to "Volume mute",
                        "Menu" to "Show menu", "Long Menu" to "Show TV guide in overlay mode",
                        "Play/Pause" to "Play/pause", "Long Play/Pause" to "Go to live stream", "Stop" to "Stop playback",
                        "Restore to defaults" to "").forEach { (k, v) ->
                        DrawerMenuItem(k, v.ifBlank { null }) {}
                    }
                }

                SettingsPage.PARENTAL -> {
                    DrawerToggleItem("Enable parental controls", checked = settings.parentalEnabled) { v ->
                        viewModel.updateSettings { it.copy(parentalEnabled = v) }
                    }
                    DrawerMenuItem("PIN code", if (settings.parentalPin.isBlank()) "Not set" else "••••") {
                        inputDialogTarget = "parental_pin"
                    }
                }

                SettingsPage.OTHER -> {
                    DrawerMenuItem("Search") {}
                    DrawerMenuItem("Reminders") { page = SettingsPage.OTHER_REMINDERS }
                    DrawerMenuItem("Recording") {}
                    DrawerMenuItem("VOD") { page = SettingsPage.OTHER_VOD }
                }

                SettingsPage.OTHER_REMINDERS -> {
                    DrawerMenuItem("Remind before program start, min", "${settings.remindBeforeMin}") {}
                    DrawerMenuItem("Popup timeout, sec", "${settings.reminderPopupTimeoutSec}") {}
                    DrawerToggleItem("Auto switch", checked = settings.reminderAutoSwitch) { v -> viewModel.updateSettings { it.copy(reminderAutoSwitch = v) } }
                    DrawerToggleItem("Wake up from sleep mode", checked = settings.reminderWakeFromSleep) { v -> viewModel.updateSettings { it.copy(reminderWakeFromSleep = v) } }
                }

                SettingsPage.OTHER_VOD -> {
                    DrawerToggleItem("Autoplay next episode", checked = settings.autoplayNextEpisode) { v ->
                        viewModel.updateSettings { it.copy(autoplayNextEpisode = v) }
                    }
                }

                SettingsPage.ABOUT -> {
                    DrawerMenuItem("TiviMate", "Version 1.0.0") {}
                    DrawerMenuItem("Media Engine", "AndroidX Media3 (DASH, HLS, SmoothStreaming, RTSP, MKV, MP4, TS)") {}
                    DrawerMenuItem("HDR Boost", if (settings.hdrBoostDefaultOn) "Enabled by default" else "Disabled") {}
                }
            }
        }
    }

    inputDialogTarget?.let { target ->
        val (dlgTitle, initVal) = when (target) {
            "global_ua" -> "User-Agent" to settings.globalUserAgent
            "udp_proxy" -> "UDP proxy" to settings.udpProxy
            "restore_url" -> "Backup URL" to ""
            "pl_name" -> "Playlist name" to (selectedPlaylist?.name ?: "")
            "pl_url" -> "Playlist URL" to (selectedPlaylist?.url ?: "")
            "pl_epg" -> "EPG URL" to (selectedPlaylist?.epgUrl ?: "")
            "pl_ua" -> "User-Agent" to (selectedPlaylist?.userAgent ?: "")
            else -> "Parental PIN" to settings.parentalPin
        }
        TiviTextInputDialog(
            title = dlgTitle,
            initialValue = initVal,
            onDismiss = { inputDialogTarget = null },
            onConfirm = { v ->
                when (target) {
                    "global_ua" -> viewModel.updateSettings { it.copy(globalUserAgent = v.ifBlank { "Not set" }) }
                    "udp_proxy" -> viewModel.updateSettings { it.copy(udpProxy = v.ifBlank { "Not set" }) }
                    "restore_url" -> {
                        if (v.isNotBlank()) {
                            scope.launch {
                                val json = withContext(Dispatchers.IO) {
                                    runCatching {
                                        PlaylistClients.httpClient.newCall(Request.Builder().url(v).build()).execute().use { it.body?.string() ?: "" }
                                    }.getOrDefault("")
                                }
                                val ok = viewModel.restoreBackup(json)
                                Toast.makeText(context, if (ok) "Backup restored" else "Failed to restore", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    "pl_name" -> selectedPlaylist?.let { viewModel.updatePlaylistConfig(it.copy(name = v)) }
                    "pl_url" -> selectedPlaylist?.let { viewModel.updatePlaylistConfig(it.copy(url = v)) }
                    "pl_epg" -> selectedPlaylist?.let { viewModel.updatePlaylistConfig(it.copy(epgUrl = v)) }
                    "pl_ua" -> selectedPlaylist?.let { viewModel.updatePlaylistConfig(it.copy(userAgent = v.ifBlank { "Not set" })) }
                    "parental_pin" -> viewModel.updateSettings { it.copy(parentalPin = v) }
                }
                inputDialogTarget = null
            }
        )
    }
}
