package com.tiviplayer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.tiviplayer.app.data.AppSettings

object TiviColors {
    val BgRoot = Color(0xFF101114)
    val BgSurface = Color(0xFF1A1C21)
    val BgDrawer = Color(0xFF1E2026)
    val BgCard = Color(0xFF24272F)
    val BgHighlight = Color(0xFFFFFFFF)
    val TextPrimary = Color(0xFFF2F4F8)
    val TextSecondary = Color(0xFF9AA0AE)
    val AccentBlue = Color(0xFF2196F3)
    val Divider = Color(0xFF2C2F38)

    fun resolveColor(name: String, default: Color): Color = when (name) {
        "Red" -> Color(0xFFE53935)
        "Pink" -> Color(0xFFD81B60)
        "Purple" -> Color(0xFF8E24AA)
        "Indigo" -> Color(0xFF3949AB)
        "Blue" -> Color(0xFF2196F3)
        "Cyan" -> Color(0xFF00ACC1)
        "Teal" -> Color(0xFF00897B)
        "Green" -> Color(0xFF43A047)
        "Lime" -> Color(0xFFC0CA33)
        "Yellow" -> Color(0xFFFDD835)
        "Black" -> Color(0xFF000000)
        "Dark" -> BgRoot
        else -> default
    }
}

@Composable
fun TiviPlayerTheme(
    settings: AppSettings = AppSettings(),
    content: @Composable () -> Unit
) {
    val bg = TiviColors.resolveColor(settings.backgroundColorName, TiviColors.BgRoot)
    val accent = TiviColors.resolveColor(settings.accentColorName, TiviColors.AccentBlue)
    val scheme = darkColorScheme(
        primary = accent,
        secondary = accent,
        background = bg,
        surface = TiviColors.BgSurface,
        onBackground = TiviColors.TextPrimary,
        onSurface = TiviColors.TextPrimary
    )
    MaterialTheme(
        colorScheme = scheme,
        content = content
    )
}
