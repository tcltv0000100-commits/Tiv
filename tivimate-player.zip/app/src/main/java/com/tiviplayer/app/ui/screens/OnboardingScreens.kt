package com.tiviplayer.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviplayer.app.ui.theme.TiviColors

@Composable
fun TermsOfUseScreen(
    onAccept: () -> Unit,
    onDeclineAndExit: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .background(TiviColors.BgDrawer, RoundedCornerShape(8.dp))
                .padding(24.dp)
        ) {
            Text(
                "Terms of Use",
                color = TiviColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(14.dp))
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .heightIn(max = 260.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "This media player is a neutral playback application and does not provide, host, or include any media, playlists, channels, or streams. By using this app you agree to these Terms.\n\n" +
                        "Your responsibility for content\n" +
                        "You are solely responsible for any playlists or media sources you add and play. By using the app, you confirm that you have the legal right to access and view the content from your chosen providers.\n\n" +
                        "No endorsement of third-party content\n" +
                        "The app is not affiliated with any third-party playlist or stream provider.",
                    color = TiviColors.TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = onDeclineAndExit,
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgCard, contentColor = TiviColors.TextPrimary),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("Decline and exit", fontSize = 13.sp)
                }
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgHighlight, contentColor = Color.Black),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("Accept", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun EmptyHomeScreen(
    onAddPlaylist: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.BgRoot),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "TiviPlayer does not provide any content",
                color = TiviColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(6.dp))
            Text("Add your playlist", color = TiviColors.TextSecondary, fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))
            Row {
                Button(
                    onClick = onAddPlaylist,
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgHighlight, contentColor = Color.Black),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("Add playlist", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.BgCard, contentColor = TiviColors.TextPrimary),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("Settings", fontSize = 14.sp)
                }
            }
        }
    }
}
