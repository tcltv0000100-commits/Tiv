package com.tiviplayer.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "tiviplayer_prefs")

class AppRepository(private val context: Context) {
    private val gson = Gson()

    companion object {
        private val KEY_TERMS_ACCEPTED = booleanPreferencesKey("terms_accepted")
        private val KEY_SETTINGS = stringPreferencesKey("app_settings")
        private val KEY_PLAYLISTS = stringPreferencesKey("playlists")
        private val KEY_FAVORITES = stringPreferencesKey("favorite_channels")
        private val KEY_BLOCKED = stringPreferencesKey("blocked_channels")
        private val KEY_HIDDEN = stringPreferencesKey("hidden_channels")
        private val KEY_MY_LIST_VOD = stringPreferencesKey("my_list_vod")
        private val KEY_VOD_HISTORY = stringPreferencesKey("vod_history")
        private val KEY_SEARCH_HISTORY = stringPreferencesKey("search_history")
        private val KEY_RECORDINGS = stringPreferencesKey("recordings_list")
        private val KEY_CUSTOM_GROUPS = stringPreferencesKey("custom_groups")
    }

    val termsAccepted: Flow<Boolean> = context.dataStore.data.map { it[KEY_TERMS_ACCEPTED] ?: false }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        prefs[KEY_SETTINGS]?.let {
            runCatching { gson.fromJson(it, AppSettings::class.java) }.getOrNull()
        } ?: AppSettings()
    }

    val playlistsFlow: Flow<List<PlaylistConfig>> = context.dataStore.data.map { prefs ->
        prefs[KEY_PLAYLISTS]?.let {
            val type = object : TypeToken<List<PlaylistConfig>>() {}.type
            runCatching { gson.fromJson<List<PlaylistConfig>>(it, type) }.getOrNull()
        } ?: emptyList()
    }

    val recordingsFlow: Flow<List<RecordingItem>> = context.dataStore.data.map { prefs ->
        prefs[KEY_RECORDINGS]?.let {
            val type = object : TypeToken<List<RecordingItem>>() {}.type
            runCatching { gson.fromJson<List<RecordingItem>>(it, type) }.getOrNull()
        } ?: emptyList()
    }

    val customGroupsFlow: Flow<List<GroupItem>> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_GROUPS]?.let {
            val type = object : TypeToken<List<GroupItem>>() {}.type
            runCatching { gson.fromJson<List<GroupItem>>(it, type) }.getOrNull()
        } ?: emptyList()
    }

    val favoritesFlow: Flow<Set<String>> = context.dataStore.data.map { decodeStringSet(it[KEY_FAVORITES]) }
    val blockedFlow: Flow<Set<String>> = context.dataStore.data.map { decodeStringSet(it[KEY_BLOCKED]) }
    val hiddenFlow: Flow<Set<String>> = context.dataStore.data.map { decodeStringSet(it[KEY_HIDDEN]) }
    val myListVodFlow: Flow<Set<String>> = context.dataStore.data.map { decodeStringSet(it[KEY_MY_LIST_VOD]) }
    val vodHistoryFlow: Flow<List<String>> = context.dataStore.data.map { decodeStringList(it[KEY_VOD_HISTORY]) }
    val searchHistoryFlow: Flow<List<String>> = context.dataStore.data.map { decodeStringList(it[KEY_SEARCH_HISTORY]) }

    suspend fun acceptTerms() {
        context.dataStore.edit { it[KEY_TERMS_ACCEPTED] = true }
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.dataStore.edit { it[KEY_SETTINGS] = gson.toJson(settings) }
    }

    suspend fun savePlaylists(playlists: List<PlaylistConfig>) {
        context.dataStore.edit { it[KEY_PLAYLISTS] = gson.toJson(playlists) }
    }

    suspend fun saveRecordings(recordings: List<RecordingItem>) {
        context.dataStore.edit { it[KEY_RECORDINGS] = gson.toJson(recordings) }
    }

    suspend fun saveCustomGroups(groups: List<GroupItem>) {
        context.dataStore.edit { it[KEY_CUSTOM_GROUPS] = gson.toJson(groups) }
    }

    suspend fun toggleFavoriteChannel(channelId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringSet(prefs[KEY_FAVORITES]).toMutableSet()
            if (!current.add(channelId)) current.remove(channelId)
            prefs[KEY_FAVORITES] = gson.toJson(current)
        }
    }

    suspend fun toggleBlockedChannel(channelId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringSet(prefs[KEY_BLOCKED]).toMutableSet()
            if (!current.add(channelId)) current.remove(channelId)
            prefs[KEY_BLOCKED] = gson.toJson(current)
        }
    }

    suspend fun toggleHiddenChannel(channelId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringSet(prefs[KEY_HIDDEN]).toMutableSet()
            if (!current.add(channelId)) current.remove(channelId)
            prefs[KEY_HIDDEN] = gson.toJson(current)
        }
    }

    suspend fun toggleMyListVod(vodId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringSet(prefs[KEY_MY_LIST_VOD]).toMutableSet()
            if (!current.add(vodId)) current.remove(vodId)
            prefs[KEY_MY_LIST_VOD] = gson.toJson(current)
        }
    }

    suspend fun addVodHistory(vodId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringList(prefs[KEY_VOD_HISTORY]).toMutableList()
            current.remove(vodId)
            current.add(0, vodId)
            prefs[KEY_VOD_HISTORY] = gson.toJson(current.take(50))
        }
    }

    suspend fun removeVodHistory(vodId: String) {
        context.dataStore.edit { prefs ->
            val current = decodeStringList(prefs[KEY_VOD_HISTORY]).toMutableList()
            current.remove(vodId)
            prefs[KEY_VOD_HISTORY] = gson.toJson(current)
        }
    }

    suspend fun addSearchQuery(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        context.dataStore.edit { prefs ->
            val current = decodeStringList(prefs[KEY_SEARCH_HISTORY]).toMutableList()
            current.remove(q)
            current.add(0, q)
            prefs[KEY_SEARCH_HISTORY] = gson.toJson(current.take(25))
        }
    }

    suspend fun clearSearchHistory() {
        context.dataStore.edit { it[KEY_SEARCH_HISTORY] = "[]" }
    }

    suspend fun exportBackupJson(): String {
        val prefs = context.dataStore.data.first()
        val map = mapOf(
            "settings" to (prefs[KEY_SETTINGS] ?: "{}"),
            "playlists" to (prefs[KEY_PLAYLISTS] ?: "[]"),
            "favorites" to (prefs[KEY_FAVORITES] ?: "[]"),
            "myList" to (prefs[KEY_MY_LIST_VOD] ?: "[]"),
            "customGroups" to (prefs[KEY_CUSTOM_GROUPS] ?: "[]")
        )
        return gson.toJson(map)
    }

    suspend fun restoreBackupJson(json: String): Boolean {
        return runCatching {
            val type = object : TypeToken<Map<String, String>>() {}.type
            val map: Map<String, String> = gson.fromJson(json, type)
            context.dataStore.edit { prefs ->
                map["settings"]?.let { prefs[KEY_SETTINGS] = it }
                map["playlists"]?.let { prefs[KEY_PLAYLISTS] = it }
                map["favorites"]?.let { prefs[KEY_FAVORITES] = it }
                map["myList"]?.let { prefs[KEY_MY_LIST_VOD] = it }
                map["customGroups"]?.let { prefs[KEY_CUSTOM_GROUPS] = it }
            }
            true
        }.getOrDefault(false)
    }

    private fun decodeStringSet(raw: String?): Set<String> {
        if (raw.isNullOrBlank()) return emptySet()
        val type = object : TypeToken<Set<String>>() {}.type
        return runCatching { gson.fromJson<Set<String>>(raw, type) }.getOrDefault(emptySet())
    }

    private fun decodeStringList(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return runCatching { gson.fromJson<List<String>>(raw, type) }.getOrDefault(emptyList())
    }
}
