package com.tiviplayer.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviplayer.app.data.*
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.components.DrawerMenuItem
import com.tiviplayer.app.ui.components.DrawerSectionHeader
import com.tiviplayer.app.ui.components.TiviRightDrawer
import com.tiviplayer.app.ui.components.TiviTextInputDialog
import com.tiviplayer.app.ui.theme.TiviColors
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class GuideSubDrawer { NONE, CHANNEL_OPTIONS, COPY_CHANNEL, REORDER_CHANNEL }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TvGuideScreen(
    viewModel: MainViewModel,
    onPlayChannel: (ChannelItem) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val groups by viewModel.groups.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val blocked by viewModel.blocked.collectAsState()
    val hidden by viewModel.hidden.collectAsState()
    val epgPrograms by viewModel.epgPrograms.collectAsState()

    var selectedGroupKey by remember { mutableStateOf("ALL") }
    var focusedChannel by remember { mutableStateOf<ChannelItem?>(null) }
    var contextChannel by remember { mutableStateOf<ChannelItem?>(null) }
    var subDrawer by remember { mutableStateOf(GuideSubDrawer.NONE) }
    var activeInputDialog by remember { mutableStateOf<String?>(null) }

    val tvGroups = remember(groups) { groups.filter { it.categoryType == "TV" && it.visible } }
    val filteredChannels = remember(channels, selectedGroupKey, favorites, hidden, blocked, settings.channelsSorting) {
        val base = channels.filterNot { hidden.contains(it.id) || blocked.contains(it.id) }
        val scoped = when {
            selectedGroupKey == "ALL" -> base
            selectedGroupKey == "FAV" -> base.filter { favorites.contains(it.id) }
            else -> base.filter { it.groupId == selectedGroupKey || it.groupName == selectedGroupKey }
        }
        when (settings.channelsSorting) {
            "By name" -> scoped.sortedBy { it.customName ?: it.name }
            else -> scoped.sortedBy { it.number }
        }
    }

    LaunchedEffect(filteredChannels) {
        if (focusedChannel == null && filteredChannels.isNotEmpty()) {
            focusedChannel = filteredChannels.first()
        }
    }

    val nowStr = remember { SimpleDateFormat("EEE, dd MMM, h:mm a", Locale.US).format(Date()) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.BgRoot)
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown || filteredChannels.isEmpty()) return@onPreviewKeyEvent false
                val curIdx = filteredChannels.indexOfFirst { it.id == focusedChannel?.id }.coerceAtLeast(0)
                when (ev.key) {
                    Key.DirectionDown -> {
                        focusedChannel = filteredChannels[(curIdx + 1).coerceAtMost(filteredChannels.lastIndex)]
                        true
                    }
                    Key.DirectionUp -> {
                        focusedChannel = filteredChannels[(curIdx - 1).coerceAtLeast(0)]
                        true
                    }
                    Key.DirectionCenter, Key.Enter -> {
                        focusedChannel?.let(onPlayChannel)
                        true
                    }
                    Key.Menu -> {
                        contextChannel = focusedChannel
                        true
                    }
                    else -> false
                }
            }
    ) {
        // Groups Sidebar
        LazyColumn(
            modifier = Modifier
                .width(190.dp)
                .fillMaxHeight()
                .background(TiviColors.BgSurface)
                .padding(vertical = 12.dp)
        ) {
            if (settings.showFavoritesCategory) {
                item {
                    GroupSidebarItem("Favorites", selectedGroupKey == "FAV") { selectedGroupKey = "FAV" }
                }
            }
            if (settings.showAllChannelsCategory) {
                item {
                    GroupSidebarItem("All channels", selectedGroupKey == "ALL") { selectedGroupKey = "ALL" }
                }
            }
            playlists.filter { it.enabled }.forEach { pl ->
                item {
                    Text(
                        pl.name,
                        color = TiviColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                val plGroups = tvGroups.filter { it.playlistId == pl.id }
                items(plGroups) { grp ->
                    GroupSidebarItem(grp.name, selectedGroupKey == grp.id) { selectedGroupKey = grp.id }
                }
            }
        }

        // Right EPG Area
        Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(14.dp)) {
            if (settings.tvGuidePreview) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(145.dp)
                        .padding(bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(240.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black)
                            .clickable { focusedChannel?.let(onPlayChannel) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (focusedChannel?.logoUrl?.isNotBlank() == true) {
                            AsyncImage(
                                model = focusedChannel!!.logoUrl,
                                contentDescription = focusedChannel!!.name,
                                modifier = Modifier.size(64.dp),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Icon(Icons.Default.Tv, contentDescription = null, tint = TiviColors.TextSecondary, modifier = Modifier.size(40.dp))
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        val currentProg = focusedChannel?.let { ch ->
                            epgPrograms.firstOrNull { it.channelId == ch.tvgId }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                currentProg?.title ?: "No information",
                                color = TiviColors.TextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Medium
                            )
                            focusedChannel?.let { ch ->
                                IconButton(onClick = { viewModel.toggleFavoriteChannel(ch.id) }) {
                                    Icon(
                                        if (favorites.contains(ch.id)) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "Favorite",
                                        tint = if (favorites.contains(ch.id)) Color(0xFFFFD54F) else TiviColors.TextSecondary
                                    )
                                }
                            }
                        }
                        Text(
                            focusedChannel?.let { "${it.customName ?: it.name} • ${it.groupName}" } ?: "",
                            color = TiviColors.TextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            currentProg?.description ?: "Tap channel to play • Long press for options",
                            color = TiviColors.TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Timeline Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TiviColors.BgSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(nowStr, color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(210.dp))
                listOf("Now", "+30 min", "+1 hr", "+1.5 hr").forEach { slot ->
                    Text(slot, color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredChannels, key = { it.id }) { ch ->
                    val isFocused = focusedChannel?.id == ch.id
                    val prog = epgPrograms.firstOrNull { it.channelId == ch.tvgId }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .background(if (isFocused) Color(0xFF282D38) else TiviColors.BgRoot)
                            .combinedClickable(
                                onClick = {
                                    focusedChannel = ch
                                    onPlayChannel(ch)
                                },
                                onLongClick = {
                                    focusedChannel = ch
                                    contextChannel = ch
                                    subDrawer = GuideSubDrawer.NONE
                                }
                            )
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (settings.showChannelNumbers) {
                            Text(
                                "${ch.number}",
                                color = if (isFocused && settings.highlightCurrentChannel) TiviColors.AccentBlue else TiviColors.TextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.width(34.dp)
                            )
                        }
                        if (ch.logoUrl.isNotBlank()) {
                            AsyncImage(
                                model = ch.logoUrl,
                                contentDescription = null,
                                modifier = Modifier.size(28.dp).clip(RoundedCornerShape(4.dp)),
                                contentScale = ContentScale.Fit
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        if (settings.showChannelNames) {
                            Text(
                                ch.customName ?: ch.name,
                                color = if (isFocused) Color.White else TiviColors.TextPrimary,
                                fontSize = 13.sp,
                                maxLines = if (settings.twoLineChannelNames) 2 else 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.width(155.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(vertical = 3.dp, horizontal = 4.dp)
                                .background(
                                    if (isFocused) Color(0xFFEAECEF) else TiviColors.BgSurface,
                                    RoundedCornerShape(3.dp)
                                )
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                prog?.title ?: "No information",
                                color = if (isFocused) Color.Black else TiviColors.TextSecondary,
                                fontSize = 12.sp,
                                maxLines = if (settings.twoLineProgramTitles) 2 else 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    HorizontalDivider(color = TiviColors.Divider.copy(alpha = 0.4f))
                }
            }
        }
    }

    // Channel & Group Context Menu (100% Wired)
    contextChannel?.let { ch ->
        when (subDrawer) {
            GuideSubDrawer.NONE -> {
                TiviRightDrawer(title = ch.customName ?: ch.name, onDismiss = { contextChannel = null }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        DrawerMenuItem("Search") { contextChannel = null; onOpenSearch() }
                        DrawerMenuItem("Settings") { contextChannel = null; onOpenSettings() }
                        DrawerSectionHeader("Program")
                        DrawerMenuItem("Open in external player") {
                            contextChannel = null
                            scope.launch {
                                val url = viewModel.resolveChannelPlayableUrl(ch)
                                if (url.isNotBlank()) {
                                    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(url), "video/*") }
                                    runCatching { context.startActivity(intent) }
                                }
                            }
                        }
                        DrawerMenuItem("Record") {
                            contextChannel = null
                            scope.launch {
                                val url = viewModel.resolveChannelPlayableUrl(ch)
                                if (url.isNotBlank()) {
                                    viewModel.startRecording(ch.customName ?: ch.name, url)
                                    Toast.makeText(context, "Recording started: ${ch.name}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        DrawerSectionHeader(ch.customName ?: ch.name)
                        DrawerMenuItem(
                            if (favorites.contains(ch.id)) "Remove from Favorites" else "Add to Favorites"
                        ) { viewModel.toggleFavoriteChannel(ch.id); contextChannel = null }
                        DrawerMenuItem("Block channel") { viewModel.toggleBlockedChannel(ch.id); contextChannel = null }
                        DrawerMenuItem("Hide channel") { viewModel.toggleHiddenChannel(ch.id); contextChannel = null }
                        DrawerMenuItem("Assign EPG", ch.tvgId.ifBlank { "Not set" }) { activeInputDialog = "assign_epg" }
                        DrawerMenuItem("Channel options") { subDrawer = GuideSubDrawer.CHANNEL_OPTIONS }
                        DrawerSectionHeader(ch.groupName)
                        DrawerMenuItem("Reorder channels") { subDrawer = GuideSubDrawer.REORDER_CHANNEL }
                        DrawerMenuItem("Copy channels") { subDrawer = GuideSubDrawer.COPY_CHANNEL }
                        DrawerMenuItem("Create group") { activeInputDialog = "create_group" }
                    }
                }
            }
            GuideSubDrawer.CHANNEL_OPTIONS -> {
                TiviRightDrawer(title = ch.customName ?: ch.name, subtitle = "Channel options", onDismiss = { subDrawer = GuideSubDrawer.NONE }) {
                    DrawerMenuItem("Channel name", ch.customName ?: ch.name) { activeInputDialog = "rename_ch" }
                    DrawerMenuItem("Restore channel name") { viewModel.restoreChannelName(ch.id); subDrawer = GuideSubDrawer.NONE }
                    DrawerMenuItem("Channel names editor") { activeInputDialog = "rename_ch" }
                    DrawerMenuItem("Audio decoder", ch.audioDecoder) {}
                    DrawerMenuItem("Video decoder", ch.videoDecoder) {}
                    DrawerMenuItem("Use external player", ch.useExternalPlayer) {}
                    DrawerMenuItem("EPG time offset, h:min", "${ch.epgOffsetMinutes}:00") {}
                    DrawerMenuItem("Block channel") { viewModel.toggleBlockedChannel(ch.id); subDrawer = GuideSubDrawer.NONE; contextChannel = null }
                }
            }
            GuideSubDrawer.COPY_CHANNEL -> {
                TiviRightDrawer(title = "Copy to group", onDismiss = { subDrawer = GuideSubDrawer.NONE }) {
                    LazyColumn {
                        items(tvGroups) { grp ->
                            DrawerMenuItem(grp.name) {
                                viewModel.copyChannelToGroup(ch, grp.id, grp.name)
                                Toast.makeText(context, "Copied to ${grp.name}", Toast.LENGTH_SHORT).show()
                                subDrawer = GuideSubDrawer.NONE
                                contextChannel = null
                            }
                        }
                    }
                }
            }
            GuideSubDrawer.REORDER_CHANNEL -> {
                TiviRightDrawer(title = "Reorder: ${ch.customName ?: ch.name}", onDismiss = { subDrawer = GuideSubDrawer.NONE }) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(onClick = { viewModel.moveChannelOrder(ch.id, -1) }) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up")
                            Spacer(Modifier.width(6.dp))
                            Text("Move Up")
                        }
                        Button(onClick = { viewModel.moveChannelOrder(ch.id, 1) }) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down")
                            Spacer(Modifier.width(6.dp))
                            Text("Move Down")
                        }
                    }
                }
            }
        }
    }

    activeInputDialog?.let { dlg ->
        val (title, init) = when (dlg) {
            "rename_ch" -> "Channel name" to (contextChannel?.customName ?: contextChannel?.name ?: "")
            "assign_epg" -> "Assign EPG ID (tvg-id)" to (contextChannel?.tvgId ?: "")
            else -> "Create group" to ""
        }
        TiviTextInputDialog(
            title = title,
            initialValue = init,
            onDismiss = { activeInputDialog = null },
            onConfirm = { v ->
                when (dlg) {
                    "rename_ch" -> contextChannel?.let { viewModel.renameChannel(it.id, v) }
                    "assign_epg" -> contextChannel?.let { viewModel.assignChannelEpg(it.id, v) }
                    "create_group" -> {
                        val plId = contextChannel?.playlistId ?: playlists.firstOrNull()?.id ?: ""
                        if (plId.isNotBlank()) viewModel.createGroup(plId, v, "TV")
                    }
                }
                activeInputDialog = null
                contextChannel = null
            }
        )
    }
}

@Composable
private fun GroupSidebarItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) TiviColors.BgHighlight else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Text(
            label,
            color = if (selected) Color.Black else TiviColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
