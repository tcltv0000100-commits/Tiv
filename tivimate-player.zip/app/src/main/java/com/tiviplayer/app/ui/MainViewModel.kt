package com.tiviplayer.app.ui

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tiviplayer.app.data.AppRepository
import com.tiviplayer.app.data.AppSettings
import com.tiviplayer.app.data.ChannelItem
import com.tiviplayer.app.data.EpgProgram
import com.tiviplayer.app.data.EpisodeItem
import com.tiviplayer.app.data.GroupItem
import com.tiviplayer.app.data.PlaylistConfig
import com.tiviplayer.app.data.PlaylistType
import com.tiviplayer.app.data.RecordingItem
import com.tiviplayer.app.data.VodItem
import com.tiviplayer.app.network.PlaylistClients
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = AppRepository(application)

    val termsAccepted: StateFlow<Boolean> = repo.termsAccepted
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val settings: StateFlow<AppSettings> = repo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val playlists: StateFlow<List<PlaylistConfig>> = repo.playlistsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recordings: StateFlow<List<RecordingItem>> = repo.recordingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val customGroups: StateFlow<List<GroupItem>> = repo.customGroupsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<Set<String>> = repo.favoritesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val blocked: StateFlow<Set<String>> = repo.blockedFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val hidden: StateFlow<Set<String>> = repo.hiddenFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val myListVod: StateFlow<Set<String>> = repo.myListVodFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val vodHistory: StateFlow<List<String>> = repo.vodHistoryFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val searchHistory: StateFlow<List<String>> = repo.searchHistoryFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _groups = MutableStateFlow<List<GroupItem>>(emptyList())
    val groups: StateFlow<List<GroupItem>> = _groups.asStateFlow()

    private val _channels = MutableStateFlow<List<ChannelItem>>(emptyList())
    val channels: StateFlow<List<ChannelItem>> = _channels.asStateFlow()

    private val _movies = MutableStateFlow<List<VodItem>>(emptyList())
    val movies: StateFlow<List<VodItem>> = _movies.asStateFlow()

    private val _shows = MutableStateFlow<List<VodItem>>(emptyList())
    val shows: StateFlow<List<VodItem>> = _shows.asStateFlow()

    private val _epgPrograms = MutableStateFlow<List<EpgProgram>>(emptyList())
    val epgPrograms: StateFlow<List<EpgProgram>> = _epgPrograms.asStateFlow()

    private val _isProcessingPlaylist = MutableStateFlow(false)
    val isProcessingPlaylist: StateFlow<Boolean> = _isProcessingPlaylist.asStateFlow()

    private val _playlistError = MutableStateFlow<String?>(null)
    val playlistError: StateFlow<String?> = _playlistError.asStateFlow()

    private val _lastProcessedPlaylist = MutableStateFlow<PlaylistConfig?>(null)
    val lastProcessedPlaylist: StateFlow<PlaylistConfig?> = _lastProcessedPlaylist.asStateFlow()

    private val recordingJobs = mutableMapOf<String, Job>()

    fun acceptTerms() {
        viewModelScope.launch { repo.acceptTerms() }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch {
            repo.saveSettings(transform(settings.value))
        }
    }

    fun processAndAddPlaylist(
        config: PlaylistConfig,
        rawLocalContent: String? = null,
        onComplete: (PlaylistConfig?) -> Unit
    ) {
        viewModelScope.launch {
            _isProcessingPlaylist.value = true
            _playlistError.value = null
            try {
                val loaded = PlaylistClients.loadPlaylist(config, rawLocalContent)
                val existing = playlists.value.filterNot { it.id == loaded.updatedConfig.id }
                repo.savePlaylists(existing + loaded.updatedConfig)

                _groups.value = _groups.value.filterNot { it.playlistId == config.id } + loaded.groups + customGroups.value
                _channels.value = _channels.value.filterNot { it.playlistId == config.id } + loaded.channels
                _movies.value = _movies.value.filterNot { it.playlistId == config.id } + loaded.movies
                _shows.value = _shows.value.filterNot { it.playlistId == config.id } + loaded.shows
                if (loaded.epgPrograms.isNotEmpty()) {
                    _epgPrograms.value = _epgPrograms.value + loaded.epgPrograms
                }
                _lastProcessedPlaylist.value = loaded.updatedConfig
                onComplete(loaded.updatedConfig)
            } catch (e: Exception) {
                _playlistError.value = e.message ?: "Failed to load playlist"
                onComplete(null)
            } finally {
                _isProcessingPlaylist.value = false
            }
        }
    }

    fun updatePlaylistConfig(updated: PlaylistConfig) {
        viewModelScope.launch {
            val list = playlists.value.map { if (it.id == updated.id) updated else it }
            repo.savePlaylists(list)
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            repo.savePlaylists(playlists.value.filterNot { it.id == playlistId })
            _groups.value = _groups.value.filterNot { it.playlistId == playlistId }
            _channels.value = _channels.value.filterNot { it.playlistId == playlistId }
            _movies.value = _movies.value.filterNot { it.playlistId == playlistId }
            _shows.value = _shows.value.filterNot { it.playlistId == playlistId }
        }
    }

    fun refreshAllPlaylists() {
        viewModelScope.launch {
            playlists.value.filter { it.enabled }.forEach { pl ->
                runCatching {
                    val loaded = PlaylistClients.loadPlaylist(pl)
                    _groups.value = _groups.value.filterNot { it.playlistId == pl.id } + loaded.groups + customGroups.value
                    _channels.value = _channels.value.filterNot { it.playlistId == pl.id } + loaded.channels
                    _movies.value = _movies.value.filterNot { it.playlistId == pl.id } + loaded.movies
                    _shows.value = _shows.value.filterNot { it.playlistId == pl.id } + loaded.shows
                    if (loaded.epgPrograms.isNotEmpty()) {
                        _epgPrograms.value = _epgPrograms.value + loaded.epgPrograms
                    }
                    updatePlaylistConfig(loaded.updatedConfig)
                }
            }
            val nowStr = SimpleDateFormat("dd/MM/yy hh:mm a", Locale.US).format(Date())
            updateSettings { it.copy(lastEpgUpdateStatus = "EPG updated on $nowStr") }
        }
    }

    // Channel & Group Management (Complete Implementation)
    fun toggleGroupVisibility(groupId: String) {
        _groups.value = _groups.value.map {
            if (it.id == groupId) it.copy(visible = !it.visible) else it
        }
    }

    fun setAllGroupsVisibility(playlistId: String, categoryType: String, visible: Boolean) {
        _groups.value = _groups.value.map {
            if (it.playlistId == playlistId && it.categoryType == categoryType) it.copy(visible = visible) else it
        }
    }

    fun createGroup(playlistId: String, name: String, categoryType: String = "TV") {
        if (name.isBlank()) return
        val newGrp = GroupItem(
            id = "custom_${UUID.randomUUID()}",
            playlistId = playlistId,
            name = name.trim(),
            categoryType = categoryType,
            visible = true,
            orderIndex = _groups.value.size
        )
        _groups.value = _groups.value + newGrp
        viewModelScope.launch {
            repo.saveCustomGroups(customGroups.value + newGrp)
        }
    }

    fun renameChannel(channelId: String, newName: String) {
        _channels.value = _channels.value.map {
            if (it.id == channelId) it.copy(customName = newName.trim().ifBlank { null }) else it
        }
    }

    fun restoreChannelName(channelId: String) {
        _channels.value = _channels.value.map {
            if (it.id == channelId) it.copy(customName = null) else it
        }
    }

    fun assignChannelEpg(channelId: String, tvgId: String) {
        _channels.value = _channels.value.map {
            if (it.id == channelId) it.copy(tvgId = tvgId.trim()) else it
        }
    }

    fun copyChannelToGroup(channel: ChannelItem, targetGroupId: String, targetGroupName: String) {
        val copy = channel.copy(
            id = "${channel.id}_copy_${System.currentTimeMillis()}",
            groupId = targetGroupId,
            groupName = targetGroupName
        )
        _channels.value = _channels.value + copy
    }

    fun moveChannelOrder(channelId: String, delta: Int) {
        val list = _channels.value.toMutableList()
        val idx = list.indexOfFirst { it.id == channelId }
        val target = (idx + delta).coerceIn(0, list.lastIndex)
        if (idx >= 0 && target != idx) {
            val item = list.removeAt(idx)
            list.add(target, item)
            _channels.value = list.mapIndexed { i, ch -> ch.copy(number = i + 1) }
        }
    }

    // Live DVR Recording
    fun startRecording(channelName: String, streamUrl: String, title: String = channelName) {
        val recDir = File(getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Recordings")
        recDir.mkdirs()
        val safeName = channelName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val file = File(recDir, "${safeName}_${System.currentTimeMillis()}.ts")
        val recId = UUID.randomUUID().toString()
        val recItem = RecordingItem(
            id = recId,
            title = title,
            channelName = channelName,
            filePath = file.absolutePath,
            isRecording = true
        )
        viewModelScope.launch {
            repo.saveRecordings(listOf(recItem) + recordings.value)
        }

        val job = viewModelScope.launch(Dispatchers.IO) {
            var totalBytes = 0L
            try {
                val req = Request.Builder().url(streamUrl).header("User-Agent", "TiviPlayer/1.0").build()
                PlaylistClients.httpClient.newCall(req).execute().use { resp ->
                    val input = resp.body?.byteStream() ?: return@use
                    FileOutputStream(file).use { out ->
                        val buf = ByteArray(16 * 1024)
                        while (isActive) {
                            val read = input.read(buf)
                            if (read == -1) break
                            out.write(buf, 0, read)
                            totalBytes += read
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                val updated = recordings.value.map {
                    if (it.id == recId) it.copy(isRecording = false, bytesWritten = file.length()) else it
                }
                repo.saveRecordings(updated)
            }
        }
        recordingJobs[recId] = job
    }

    fun stopRecording(recId: String) {
        recordingJobs.remove(recId)?.cancel()
        viewModelScope.launch {
            val updated = recordings.value.map {
                if (it.id == recId) {
                    val f = File(it.filePath)
                    it.copy(isRecording = false, bytesWritten = if (f.exists()) f.length() else it.bytesWritten)
                } else it
            }
            repo.saveRecordings(updated)
        }
    }

    fun deleteRecording(recId: String) {
        recordingJobs.remove(recId)?.cancel()
        viewModelScope.launch {
            val item = recordings.value.find { it.id == recId }
            item?.let { runCatching { File(it.filePath).delete() } }
            repo.saveRecordings(recordings.value.filterNot { it.id == recId })
        }
    }

    fun toggleFavoriteChannel(id: String) { viewModelScope.launch { repo.toggleFavoriteChannel(id) } }
    fun toggleBlockedChannel(id: String) { viewModelScope.launch { repo.toggleBlockedChannel(id) } }
    fun toggleHiddenChannel(id: String) { viewModelScope.launch { repo.toggleHiddenChannel(id) } }
    fun toggleMyListVod(id: String) { viewModelScope.launch { repo.toggleMyListVod(id) } }
    fun addVodHistory(id: String) { viewModelScope.launch { repo.addVodHistory(id) } }
    fun removeVodHistory(id: String) { viewModelScope.launch { repo.removeVodHistory(id) } }
    fun addSearchQuery(q: String) { viewModelScope.launch { repo.addSearchQuery(q) } }
    fun clearSearchHistory() { viewModelScope.launch { repo.clearSearchHistory() } }

    suspend fun resolveChannelPlayableUrl(channel: ChannelItem): String {
        if (channel.streamUrl.isNotBlank()) return channel.streamUrl
        val pl = playlists.value.find { it.id == channel.playlistId } ?: return ""
        return if (pl.type == PlaylistType.STALKER && channel.cmd.isNotBlank()) {
            PlaylistClients.resolveStalkerStreamUrl(pl, channel.cmd, "itv")
        } else ""
    }

    suspend fun resolveVodPlayableUrl(vod: VodItem): String {
        if (vod.streamUrl.isNotBlank()) return vod.streamUrl
        val pl = playlists.value.find { it.id == vod.playlistId } ?: return ""
        return if (pl.type == PlaylistType.STALKER && vod.cmd.isNotBlank()) {
            PlaylistClients.resolveStalkerStreamUrl(pl, vod.cmd, "vod")
        } else ""
    }

    suspend fun loadSeriesEpisodes(show: VodItem): List<EpisodeItem> {
        val pl = playlists.value.find { it.id == show.playlistId } ?: return emptyList()
        return if (pl.type == PlaylistType.XTREAM && show.cmd.isNotBlank()) {
            PlaylistClients.fetchXtreamSeriesEpisodes(pl, show.cmd)
        } else emptyList()
    }

    suspend fun exportBackup(): String = repo.exportBackupJson()
    suspend fun restoreBackup(json: String): Boolean = repo.restoreBackupJson(json)
}
