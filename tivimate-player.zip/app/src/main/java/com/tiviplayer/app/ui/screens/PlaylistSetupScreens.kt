package com.tiviplayer.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviplayer.app.data.PlaylistConfig
import com.tiviplayer.app.data.PlaylistType
import com.tiviplayer.app.data.StalkerDeviceUtils
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.components.TiviTextInputDialog
import com.tiviplayer.app.ui.theme.TiviColors
import java.net.URI

private enum class SetupStep {
    TYPE_SELECT,
    M3U_INPUT,
    XTREAM_INPUT,
    STALKER_INPUT,
    PROCESSING,
    PROCESSED,
    EPG_URL
}

@Composable
fun AddPlaylistFlowScreen(
    viewModel: MainViewModel,
    onDone: () -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var step by remember { mutableStateOf(SetupStep.TYPE_SELECT) }
    var selectedType by remember { mutableStateOf(PlaylistType.M3U) }

    // M3U state
    var m3uUrl by remember { mutableStateOf("") }
    var localPlaylistText by remember { mutableStateOf<String?>(null) }
    var isVodOnly by remember { mutableStateOf(false) }
    var epgUrl by remember { mutableStateOf("") }

    // Xtream state
    var xtreamServer by remember { mutableStateOf("") }
    var xtreamUser by remember { mutableStateOf("") }
    var xtreamPass by remember { mutableStateOf("") }

    // Stalker state (with auto-gen D1, D2=D1, SN)
    var stalkerServer by remember { mutableStateOf("") }
    var stalkerMac by remember { mutableStateOf("") }
    var stalkerUser by remember { mutableStateOf("") }
    var stalkerPass by remember { mutableStateOf("") }
    var stalkerDev1 by remember { mutableStateOf("") }
    var stalkerDev2 by remember { mutableStateOf("") }
    var stalkerSn by remember { mutableStateOf("") }

    var includeTv by remember { mutableStateOf(true) }
    var includeVod by remember { mutableStateOf(true) }
    var playlistName by remember { mutableStateOf("") }

    val isProcessing by viewModel.isProcessingPlaylist.collectAsState()
    val errorMsg by viewModel.playlistError.collectAsState()
    val processedConfig by viewModel.lastProcessedPlaylist.collectAsState()

    var activeDialog by remember { mutableStateOf<String?>(null) }

    val localFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val content = runCatching {
                context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }
            }.getOrNull()
            if (!content.isNullOrBlank()) {
                localPlaylistText = content
                m3uUrl = it.lastPathSegment ?: "local_playlist.m3u"
            }
        }
    }

    fun autoDeriveStalker(mac: String) {
        stalkerMac = mac
        val derived = StalkerDeviceUtils.deriveFromMac(mac)
        stalkerSn = derived.serialNumber
        stalkerDev1 = derived.deviceId
        stalkerDev2 = derived.deviceId2 // d2 == d1
    }

    fun startProcessing() {
        val defaultName = when (selectedType) {
            PlaylistType.M3U -> runCatching { URI(m3uUrl).host ?: m3uUrl }.getOrDefault("M3U Playlist")
            PlaylistType.XTREAM -> runCatching { URI(if (xtreamServer.startsWith("http")) xtreamServer else "http://$xtreamServer").host ?: xtreamServer }.getOrDefault("Xtream")
            PlaylistType.STALKER -> runCatching { URI(if (stalkerServer.startsWith("http")) stalkerServer else "http://$stalkerServer").host ?: stalkerServer }.getOrDefault("Stalker")
        }
        if (playlistName.isBlank()) playlistName = defaultName

        val cfg = when (selectedType) {
            PlaylistType.M3U -> PlaylistConfig(
                name = playlistName,
                type = PlaylistType.M3U,
                url = m3uUrl,
                isVodOnly = isVodOnly
            )
            PlaylistType.XTREAM -> PlaylistConfig(
                name = playlistName,
                type = PlaylistType.XTREAM,
                url = xtreamServer,
                username = xtreamUser,
                password = xtreamPass,
                includeTv = includeTv,
                includeVod = includeVod
            )
            PlaylistType.STALKER -> {
                val derived = StalkerDeviceUtils.deriveFromMac(stalkerMac)
                PlaylistConfig(
                    name = playlistName,
                    type = PlaylistType.STALKER,
                    url = stalkerServer,
                    macAddress = derived.macUpper,
                    username = stalkerUser,
                    password = stalkerPass,
                    deviceId = stalkerDev1.ifBlank { derived.deviceId },
                    deviceId2 = stalkerDev2.ifBlank { derived.deviceId2 },
                    serialNumber = stalkerSn.ifBlank { derived.serialNumber },
                    includeTv = includeTv,
                    includeVod = includeVod
                )
            }
        }
        step = SetupStep.PROCESSING
        viewModel.processAndAddPlaylist(cfg, localPlaylistText) { result ->
            if (result != null) {
                playlistName = result.name
                step = SetupStep.PROCESSED
            } else {
                step = when (selectedType) {
                    PlaylistType.M3U -> SetupStep.M3U_INPUT
                    PlaylistType.XTREAM -> SetupStep.XTREAM_INPUT
                    PlaylistType.STALKER -> SetupStep.STALKER_INPUT
                }
            }
        }
    }

    val leftIcon: ImageVector = when (step) {
        SetupStep.TYPE_SELECT -> Icons.Default.PlaylistAdd
        SetupStep.M3U_INPUT, SetupStep.EPG_URL -> Icons.Default.Link
        SetupStep.XTREAM_INPUT, SetupStep.STALKER_INPUT -> Icons.AutoMirrored.Filled.ExitToApp
        SetupStep.PROCESSING, SetupStep.PROCESSED -> Icons.Default.Download
    }
    val leftTitle = when (step) {
        SetupStep.TYPE_SELECT -> "Playlist type"
        SetupStep.M3U_INPUT -> "M3U playlist"
        SetupStep.XTREAM_INPUT -> "Xtream Codes"
        SetupStep.STALKER_INPUT -> "Stalker Portal"
        SetupStep.PROCESSING -> "Processing..."
        SetupStep.PROCESSED -> "Playlist is processed"
        SetupStep.EPG_URL -> "EPG URL"
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.BgRoot)
    ) {
        // Left Panel (35%)
        Column(
            modifier = Modifier
                .weight(0.36f)
                .fillMaxHeight()
                .background(Color(0xFF21242B))
                .padding(32.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(leftIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(leftTitle, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Normal)
                    if (step == SetupStep.PROCESSED && processedConfig != null) {
                        Spacer(Modifier.height(6.dp))
                        Text("Channels: ${processedConfig!!.channelsCount}", color = TiviColors.TextSecondary, fontSize = 13.sp)
                        if (processedConfig!!.moviesCount > 0) {
                            Text("Movies: ${processedConfig!!.moviesCount}", color = TiviColors.TextSecondary, fontSize = 13.sp)
                        }
                        if (processedConfig!!.showsCount > 0) {
                            Text("Shows: ${processedConfig!!.showsCount}", color = TiviColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                    if (!errorMsg.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(errorMsg!!, color = Color(0xFFFF6B6B), fontSize = 12.sp)
                    }
                }
            }
        }

        // Middle Panel (44%)
        Column(
            modifier = Modifier
                .weight(0.44f)
                .fillMaxHeight()
                .background(TiviColors.BgSurface)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp, vertical = 36.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                SetupStep.TYPE_SELECT -> {
                    SetupMenuOption("M3U playlist") {
                        selectedType = PlaylistType.M3U
                        step = SetupStep.M3U_INPUT
                    }
                    SetupMenuOption("Xtream Codes") {
                        selectedType = PlaylistType.XTREAM
                        step = SetupStep.XTREAM_INPUT
                    }
                    SetupMenuOption("Stalker Portal") {
                        selectedType = PlaylistType.STALKER
                        step = SetupStep.STALKER_INPUT
                    }
                }
                SetupStep.M3U_INPUT -> {
                    SetupMenuOption("Enter URL", m3uUrl.ifBlank { null }) { activeDialog = "m3u_url" }
                    SetupMenuOption("Paste from clipboard") {
                        clipboard.getText()?.text?.let { m3uUrl = it.trim(); localPlaylistText = null }
                    }
                    SetupMenuOption("Select local playlist") {
                        localFileLauncher.launch("*/*")
                    }
                }
                SetupStep.XTREAM_INPUT -> {
                    SetupMenuOption("Server address", xtreamServer.ifBlank { null }) { activeDialog = "xt_server" }
                    SetupMenuOption("Username", xtreamUser.ifBlank { null }) { activeDialog = "xt_user" }
                    SetupMenuOption("Password", if (xtreamPass.isBlank()) null else "••••••") { activeDialog = "xt_pass" }
                    SetupCheckbox("Include TV channels", includeTv) { includeTv = it }
                    SetupCheckbox("Include VOD", includeVod) { includeVod = it }
                }
                SetupStep.STALKER_INPUT -> {
                    SetupMenuOption("Server address", stalkerServer.ifBlank { null }) { activeDialog = "st_server" }
                    SetupMenuOption("MAC address", stalkerMac.ifBlank { "00:1a:79:a8:aa:64" }) { activeDialog = "st_mac" }
                    SetupMenuOption("Username (optional)", stalkerUser.ifBlank { null }) { activeDialog = "st_user" }
                    SetupMenuOption("Password (optional)", if (stalkerPass.isBlank()) null else "••••••") { activeDialog = "st_pass" }
                    SetupMenuOption("Device ID (optional)", stalkerDev1.ifBlank { "Auto from MAC" }) { activeDialog = "st_d1" }
                    SetupMenuOption("Device ID 2 (optional)", stalkerDev2.ifBlank { "Auto (= Device ID)" }) { activeDialog = "st_d2" }
                    SetupMenuOption("Serial number (optional)", stalkerSn.ifBlank { "Auto from MAC" }) { activeDialog = "st_sn" }
                    SetupCheckbox("Include TV channels", includeTv) { includeTv = it }
                    SetupCheckbox("Include VOD", includeVod) { includeVod = it }
                }
                SetupStep.PROCESSING -> {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = TiviColors.AccentBlue)
                    }
                }
                SetupStep.PROCESSED -> {
                    SetupMenuOption("Playlist name", playlistName) { activeDialog = "pl_name" }
                    if (selectedType == PlaylistType.M3U) {
                        SetupRadioOption("TV playlist", !isVodOnly) { isVodOnly = false }
                        SetupRadioOption("VOD playlist (no TV channels)", isVodOnly) { isVodOnly = true }
                    }
                }
                SetupStep.EPG_URL -> {
                    SetupMenuOption("Enter URL", epgUrl.ifBlank { null }) { activeDialog = "epg_url" }
                    SetupMenuOption("Paste from clipboard") {
                        clipboard.getText()?.text?.let { epgUrl = it.trim() }
                    }
                    SetupMenuOption("Select local EPG") {
                        localFileLauncher.launch("*/*")
                    }
                }
            }
        }

        // Right Actions Panel (20%)
        Column(
            modifier = Modifier
                .weight(0.20f)
                .fillMaxHeight()
                .background(TiviColors.BgSurface)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                SetupStep.TYPE_SELECT -> {
                    SetupActionButton("Cancel", primary = false, onClick = onCancel)
                }
                SetupStep.M3U_INPUT, SetupStep.XTREAM_INPUT, SetupStep.STALKER_INPUT -> {
                    SetupActionButton("Next  ▶", primary = true, onClick = { startProcessing() })
                    Spacer(Modifier.height(10.dp))
                    SetupActionButton("Back", primary = false, onClick = { step = SetupStep.TYPE_SELECT })
                }
                SetupStep.PROCESSING -> {
                    SetupActionButton("Back", primary = false, onClick = onCancel)
                }
                SetupStep.PROCESSED -> {
                    SetupActionButton(
                        text = if (selectedType == PlaylistType.M3U) "Next  ▶" else "Done",
                        primary = true,
                        onClick = {
                            processedConfig?.let {
                                if (it.name != playlistName || it.isVodOnly != isVodOnly) {
                                    viewModel.updatePlaylistConfig(it.copy(name = playlistName, isVodOnly = isVodOnly))
                                }
                            }
                            if (selectedType == PlaylistType.M3U) step = SetupStep.EPG_URL else onDone()
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    SetupActionButton("Back", primary = false, onClick = { step = SetupStep.TYPE_SELECT })
                }
                SetupStep.EPG_URL -> {
                    SetupActionButton("Done", primary = true, onClick = {
                        if (epgUrl.isNotBlank()) {
                            processedConfig?.let { viewModel.updatePlaylistConfig(it.copy(epgUrl = epgUrl)) }
                        }
                        onDone()
                    })
                    Spacer(Modifier.height(10.dp))
                    SetupActionButton("Skip", primary = false, onClick = onDone)
                }
            }
        }
    }

    // Input Dialogs
    activeDialog?.let { dlg ->
        val (title, initVal, ph) = when (dlg) {
            "m3u_url" -> Triple("Playlist URL", m3uUrl, "https://example.com/playlist.m3u")
            "xt_server" -> Triple("Server address", xtreamServer, "http://domain.com:8080")
            "xt_user" -> Triple("Username", xtreamUser, "Username")
            "xt_pass" -> Triple("Password", xtreamPass, "Password")
            "st_server" -> Triple("Server address", stalkerServer, "http://portal.com/c/")
            "st_mac" -> Triple("MAC address", stalkerMac, "00:1A:79:XX:XX:XX")
            "st_user" -> Triple("Username (optional)", stalkerUser, "Username")
            "st_pass" -> Triple("Password (optional)", stalkerPass, "Password")
            "st_d1" -> Triple("Device ID", stalkerDev1, "Auto-generated SHA-256")
            "st_d2" -> Triple("Device ID 2", stalkerDev2, "Auto-generated (= Device ID)")
            "st_sn" -> Triple("Serial number", stalkerSn, "Auto-generated MD5(MAC)[0..13]")
            "pl_name" -> Triple("Playlist name", playlistName, "Playlist name")
            else -> Triple("EPG URL", epgUrl, "https://example.com/epg.xml")
        }
        TiviTextInputDialog(
            title = title,
            initialValue = initVal,
            placeholder = ph,
            onDismiss = { activeDialog = null },
            onConfirm = { v ->
                when (dlg) {
                    "m3u_url" -> { m3uUrl = v; localPlaylistText = null }
                    "xt_server" -> xtreamServer = v
                    "xt_user" -> xtreamUser = v
                    "xt_pass" -> xtreamPass = v
                    "st_server" -> stalkerServer = v
                    "st_mac" -> autoDeriveStalker(v)
                    "st_user" -> stalkerUser = v
                    "st_pass" -> stalkerPass = v
                    "st_d1" -> stalkerDev1 = v
                    "st_d2" -> stalkerDev2 = v
                    "st_sn" -> stalkerSn = v
                    "pl_name" -> playlistName = v
                    "epg_url" -> epgUrl = v
                }
                activeDialog = null
            }
        )
    }
}

@Composable
private fun SetupMenuOption(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
    ) {
        Text(title, color = TiviColors.TextPrimary, fontSize = 15.sp)
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SetupCheckbox(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(checkedColor = TiviColors.AccentBlue)
        )
        Spacer(Modifier.width(8.dp))
        Text(label, color = TiviColors.TextPrimary, fontSize = 14.sp)
    }
}

@Composable
private fun SetupRadioOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = TiviColors.AccentBlue)
        )
        Spacer(Modifier.width(8.dp))
        Text(label, color = TiviColors.TextPrimary, fontSize = 14.sp)
    }
}

@Composable
private fun SetupActionButton(text: String, primary: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (primary) Color(0xFFEAECEF) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            color = if (primary) Color.Black else TiviColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = if (primary) FontWeight.Medium else FontWeight.Normal
        )
    }
}
