package com.tiviplayer.app.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.os.Build
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tiviplayer.app.data.AppSettings
import com.tiviplayer.app.data.DisplayMode
import com.tiviplayer.app.network.PlaylistClients
import com.tiviplayer.app.ui.components.DrawerRadioItem
import com.tiviplayer.app.ui.components.TiviRightDrawer
import com.tiviplayer.app.ui.theme.TiviColors
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PlayerRequest(
    val title: String,
    val url: String,
    val isVod: Boolean = false,
    val isSeries: Boolean = false,
    val channelId: String? = null,
    val groupLabel: String = "",
    val isFavorite: Boolean = false,
    val userAgent: String = "",
    val referer: String = "",
    val drmLicenseType: String = "",
    val drmLicenseUrl: String = ""
)

private enum class PlayerDrawer { NONE, VIDEO_TRACKS, AUDIO_TRACKS, SUBTITLES, DISPLAY_MODE, SLEEP_TIMER }

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    request: PlayerRequest,
    settings: AppSettings,
    onBack: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenChannelsList: () -> Unit,
    onOpenRecordings: () -> Unit,
    onOpenMultiview: () -> Unit,
    onStartRecording: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onNextChannel: (() -> Unit)? = null,
    onPrevChannel: (() -> Unit)? = null,
    onNextEpisode: (() -> Unit)? = null,
    onPrevEpisode: (() -> Unit)? = null,
    onDisplayModeApplyAll: (DisplayMode) -> Unit
) {
    val context = LocalContext.current
    var showOsd by remember { mutableStateOf(true) }
    var showSecondaryBar by remember { mutableStateOf(!request.isVod) }
    var activeDrawer by remember { mutableStateOf(PlayerDrawer.NONE) }
    var hdrEnabled by remember { mutableStateOf(settings.hdrBoostDefaultOn) }
    var displayMode by remember { mutableStateOf(settings.globalDisplayMode) }
    var audioOffsetMs by remember { mutableIntStateOf(0) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isBuffering by remember { mutableStateOf(true) }
    var videoResolutionBadge by remember { mutableStateOf("1920×1080") }
    var fpsBadge by remember { mutableStateOf("24 FPS") }
    var audioBadge by remember { mutableStateOf("STEREO") }

    val exoPlayer = remember(request.url, settings.bufferSize) {
        val minBuf = when (settings.bufferSize) {
            "None" -> 500
            "Small" -> 5000
            "Large" -> 30000
            "Very large" -> 60000
            else -> 15000
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBuf, minBuf * 2, 1500, 3000)
            .build()
        val ua = request.userAgent.ifBlank {
            settings.globalUserAgent.takeIf { it != "Not set" && it.isNotBlank() } ?: "okhttp/4.7.1"
        }
        val headers = mutableMapOf<String, String>()
        if (request.referer.isNotBlank()) headers["Referer"] = request.referer
        val dataSourceFactory = OkHttpDataSource.Factory(PlaylistClients.httpClient)
            .setUserAgent(ua)
            .setDefaultRequestProperties(headers)
        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context)
            .setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)

        val mediaItemBuilder = MediaItem.Builder().setUri(request.url)
        if (request.drmLicenseUrl.isNotBlank()) {
            val drmUuid = when {
                request.drmLicenseType.contains("clearkey", ignoreCase = true) -> C.CLEARKEY_UUID
                request.drmLicenseType.contains("playready", ignoreCase = true) -> C.PLAYREADY_UUID
                else -> C.WIDEVINE_UUID
            }
            if (request.drmLicenseUrl.startsWith("http", ignoreCase = true)) {
                mediaItemBuilder.setDrmConfiguration(
                    MediaItem.DrmConfiguration.Builder(drmUuid)
                        .setLicenseUri(request.drmLicenseUrl)
                        .build()
                )
            }
        }

        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setLoadControl(loadControl)
            .build()
            .apply {
                setMediaItem(mediaItemBuilder.build())
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_ENDED && request.isSeries && settings.autoplayNextEpisode) {
                    onNextEpisode?.invoke()
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isBuffering = false
                android.widget.Toast.makeText(context, "Playback error: ${error.errorCodeName}", android.widget.Toast.LENGTH_SHORT).show()
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoResolutionBadge = "${videoSize.width}×${videoSize.height}"
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            delay(sleepTimerMinutes * 60_000L)
            exoPlayer.pause()
            onBack()
        }
    }

    // HDR Boost: RenderEffect on Android 12+, plus subtle vibrance/contrast boost on older Android
    val hdrModifier = if (hdrEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val cm = ColorMatrix().apply { setSaturation(1.28f) }
        val contrast = 1.12f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)
        Modifier.graphicsLayer {
            renderEffect = RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm)).asComposeRenderEffect()
        }
    } else {
        Modifier
    }

    val resizeMode = when (displayMode) {
        DisplayMode.FULL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        DisplayMode.ZOOM, DisplayMode.ZOOM_235 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        DisplayMode.REDUCED -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.key) {
                    Key.DirectionCenter, Key.Enter -> {
                        showOsd = !showOsd
                        true
                    }
                    Key.MediaPlayPause, Key.Spacebar -> {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        true
                    }
                    Key.DirectionUp, Key.ChannelUp -> {
                        if (!request.isVod) { onNextChannel?.invoke(); true } else false
                    }
                    Key.DirectionDown, Key.ChannelDown -> {
                        if (!request.isVod) { onPrevChannel?.invoke(); true } else false
                    }
                    Key.DirectionLeft -> {
                        if (request.isVod) {
                            exoPlayer.seekTo((exoPlayer.currentPosition - settings.skipStepSec * 1000L).coerceAtLeast(0L))
                        } else {
                            onOpenChannelsList()
                        }
                        true
                    }
                    Key.DirectionRight -> {
                        if (request.isVod) {
                            exoPlayer.seekTo(exoPlayer.currentPosition + settings.skipStepSec * 1000L)
                        } else {
                            showOsd = true
                        }
                        true
                    }
                    else -> false
                }
            }
            .clickable { showOsd = !showOsd }
    ) {
        AndroidView(
            factory = { ctx ->
                android.view.TextureView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    exoPlayer.setVideoTextureView(this)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    when (displayMode) {
                        DisplayMode.ZOOM -> { scaleX = 1.25f; scaleY = 1.25f }
                        DisplayMode.ZOOM_235 -> { scaleX = 1.35f; scaleY = 1.35f }
                        DisplayMode.REDUCED -> { scaleX = 0.85f; scaleY = 0.85f }
                        DisplayMode.RATIO_4_3 -> { scaleX = 0.75f; scaleY = 1f }
                        else -> { scaleX = 1f; scaleY = 1f }
                    }
                }
                .then(hdrModifier)
        )

        // Subtle HDR color/contrast lift fallback for Android 7-11
        if (hdrEnabled && Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x14FFFFFF))
            )
        }

        if (isBuffering) {
            CircularProgressIndicator(
                color = TiviColors.AccentBlue,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (showOsd) {
            val nowText = remember { SimpleDateFormat("EEE, dd MMM, h:mm a", Locale.US).format(Date()) }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.25f))
            ) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        if (request.groupLabel.isNotBlank()) {
                            Text(request.groupLabel, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (hdrEnabled) TiviColors.AccentBlue else Color.DarkGray)
                                .clickable { hdrEnabled = !hdrEnabled }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (hdrEnabled) "HDR ON" else "HDR OFF",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(nowText, color = Color.White, fontSize = 13.sp)
                    }
                }

                // Bottom Controls
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.72f))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    if (request.isVod) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(request.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TechBadge(videoResolutionBadge)
                                TechBadge(fpsBadge)
                                TechBadge(audioBadge)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Slider(
                            value = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f,
                            onValueChange = { frac ->
                                if (durationMs > 0) exoPlayer.seekTo((frac * durationMs).toLong())
                            },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = TiviColors.AccentBlue)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${formatTime(positionMs)} / ${formatTime(durationMs)}",
                                color = TiviColors.TextSecondary,
                                fontSize = 12.sp
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (request.isSeries) {
                                    IconButton(onClick = { onPrevEpisode?.invoke() }) {
                                        Icon(Icons.Default.SkipPrevious, contentDescription = "Previous Episode", tint = Color.White)
                                    }
                                }
                                IconButton(onClick = {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - settings.skipStepSec * 1000L).coerceAtLeast(0L))
                                }) {
                                    Icon(Icons.Default.FastRewind, contentDescription = "Rewind", tint = Color.White)
                                }
                                IconButton(
                                    onClick = { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.Black
                                    )
                                }
                                IconButton(onClick = {
                                    exoPlayer.seekTo(exoPlayer.currentPosition + settings.skipStepSec * 1000L)
                                }) {
                                    Icon(Icons.Default.FastForward, contentDescription = "Fast forward", tint = Color.White)
                                }
                                if (request.isSeries) {
                                    IconButton(onClick = { onNextEpisode?.invoke() }) {
                                        Icon(Icons.Default.SkipNext, contentDescription = "Next Episode", tint = Color.White)
                                    }
                                }
                            }
                            Row {
                                IconButton(onClick = { exoPlayer.seekTo(0L) }) {
                                    Icon(Icons.Default.Replay, contentDescription = "Restart", tint = Color.White)
                                }
                                IconButton(onClick = { showSecondaryBar = !showSecondaryBar }) {
                                    Icon(
                                        if (showSecondaryBar) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Toggle menu",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }

                    if (showSecondaryBar) {
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (settings.menuShowSearch) {
                                OsdActionButton(Icons.Default.Search, "Search", onClick = onOpenSearch)
                            }
                            if (settings.menuShowChannelsList) {
                                OsdActionButton(Icons.AutoMirrored.Filled.List, "Channels list", onClick = onOpenChannelsList)
                            }
                            if (settings.menuShowRecordings) {
                                OsdActionButton(Icons.Default.FiberManualRecord, "Record", onClick = onStartRecording)
                                OsdActionButton(Icons.Default.Dvr, "Recordings", onClick = onOpenRecordings)
                            }
                            if (settings.menuShowMultiview && !request.isVod) {
                                OsdActionButton(Icons.Default.GridView, "Multiview", onClick = onOpenMultiview)
                            }
                            if (settings.menuShowHdr) {
                                OsdActionButton(
                                    icon = Icons.Default.HdrOn,
                                    label = if (hdrEnabled) "HDR: On" else "HDR: Off",
                                    highlighted = hdrEnabled,
                                    onClick = { hdrEnabled = !hdrEnabled }
                                )
                            }
                            if (settings.menuShowPip) {
                                OsdActionButton(Icons.Default.PictureInPictureAlt, "Picture-in-picture") {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        (context as? Activity)?.enterPictureInPictureMode(
                                            PictureInPictureParams.Builder()
                                                .setAspectRatio(Rational(16, 9))
                                                .build()
                                        )
                                    }
                                }
                            }
                            if (settings.menuShowVideoTracks) {
                                OsdActionButton(Icons.Default.Videocam, videoResolutionBadge) {
                                    activeDrawer = PlayerDrawer.VIDEO_TRACKS
                                }
                            }
                            if (settings.menuShowAudioTracks) {
                                OsdActionButton(Icons.Default.VolumeUp, audioBadge) {
                                    activeDrawer = PlayerDrawer.AUDIO_TRACKS
                                }
                            }
                            if (settings.menuShowAudioOffset) {
                                OsdActionButton(Icons.Default.GraphicEq, "$audioOffsetMs ms") {
                                    audioOffsetMs = if (audioOffsetMs >= 500) -500 else audioOffsetMs + 50
                                }
                            }
                            if (settings.menuShowClosedCaptions) {
                                OsdActionButton(Icons.Default.ClosedCaption, "CC") {
                                    activeDrawer = PlayerDrawer.SUBTITLES
                                }
                            }
                            if (settings.menuShowDisplayMode) {
                                OsdActionButton(Icons.Default.AspectRatio, displayMode.label) {
                                    activeDrawer = PlayerDrawer.DISPLAY_MODE
                                }
                            }
                            if (settings.menuShowSleepTimer) {
                                OsdActionButton(
                                    Icons.Default.Bedtime,
                                    if (sleepTimerMinutes == 0) "Off" else "${sleepTimerMinutes}m"
                                ) {
                                    activeDrawer = PlayerDrawer.SLEEP_TIMER
                                }
                            }
                            if (settings.menuShowFavorite && request.channelId != null) {
                                OsdActionButton(
                                    if (request.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    "Favorite"
                                ) {
                                    onToggleFavorite(request.channelId)
                                }
                            }
                            OsdActionButton(Icons.Default.Settings, "Settings", onClick = onOpenSettings)
                        }
                    }
                }
            }
        }

        when (activeDrawer) {
            PlayerDrawer.DISPLAY_MODE -> {
                TiviRightDrawer("Display mode", onDismiss = { activeDrawer = PlayerDrawer.NONE }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    DisplayMode.entries.forEach { mode ->
                        DrawerRadioItem(mode.label, selected = displayMode == mode) {
                            displayMode = mode
                        }
                    }
                    HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 8.dp))
                    Text(
                        "Apply to all channels",
                        color = TiviColors.AccentBlue,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onDisplayModeApplyAll(displayMode)
                                activeDrawer = PlayerDrawer.NONE
                            }
                            .padding(horizontal = 20.dp, vertical = 12.dp)
                    )
                    }
                }
            }
            PlayerDrawer.VIDEO_TRACKS -> {
                val tracks = exoPlayer.currentTracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
                TiviRightDrawer("Video tracks", onDismiss = { activeDrawer = PlayerDrawer.NONE }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (tracks.isEmpty()) {
                        DrawerRadioItem("Auto ($videoResolutionBadge)", selected = true) { activeDrawer = PlayerDrawer.NONE }
                    } else {
                        tracks.forEach { group ->
                            for (i in 0 until group.length) {
                                val fmt = group.getTrackFormat(i)
                                val label = "${fmt.width} × ${fmt.height}" +
                                    if (fmt.bitrate > 0) ", ${"%.2f".format(fmt.bitrate / 1_000_000f)} Mbps" else ""
                                DrawerRadioItem(label, selected = group.isTrackSelected(i)) {
                                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                        .buildUpon()
                                        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, i))
                                        .build()
                                    activeDrawer = PlayerDrawer.NONE
                                }
                            }
                        }
                    }
                                    }
                }
            }
            PlayerDrawer.AUDIO_TRACKS -> {
                val tracks = exoPlayer.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                TiviRightDrawer("Audio tracks", onDismiss = { activeDrawer = PlayerDrawer.NONE }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    DrawerRadioItem("Off", selected = tracks.none { it.isSelected }) {
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                            .build()
                        activeDrawer = PlayerDrawer.NONE
                    }
                    tracks.forEach { group ->
                        for (i in 0 until group.length) {
                            val fmt = group.getTrackFormat(i)
                            val chLabel = if (fmt.channelCount > 2) "Surround" else "Stereo"
                            val lang = fmt.language?.uppercase() ?: "Audio"
                            DrawerRadioItem("$lang, $chLabel", selected = group.isTrackSelected(i)) {
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, i))
                                    .build()
                                activeDrawer = PlayerDrawer.NONE
                            }
                        }
                    }
                                    }
                }
            }
            PlayerDrawer.SUBTITLES -> {
                val tracks = exoPlayer.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                TiviRightDrawer("Closed captions", onDismiss = { activeDrawer = PlayerDrawer.NONE }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    DrawerRadioItem("Off", selected = tracks.none { it.isSelected }) {
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                            .build()
                        activeDrawer = PlayerDrawer.NONE
                    }
                    tracks.forEach { group ->
                        for (i in 0 until group.length) {
                            val fmt = group.getTrackFormat(i)
                            DrawerRadioItem(fmt.language?.uppercase() ?: "Subtitle ${i + 1}", selected = group.isTrackSelected(i)) {
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, i))
                                    .build()
                                activeDrawer = PlayerDrawer.NONE
                            }
                        }
                    }
                                    }
                }
            }
            PlayerDrawer.SLEEP_TIMER -> {
                TiviRightDrawer("Sleep timer", onDismiss = { activeDrawer = PlayerDrawer.NONE }) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    listOf(0, 15, 30, 45, 60, 90, 120).forEach { mins ->
                        DrawerRadioItem(if (mins == 0) "Off" else "$mins min", selected = sleepTimerMinutes == mins) {
                            sleepTimerMinutes = mins
                            activeDrawer = PlayerDrawer.NONE
                        }
                    }
                                    }
                }
            }
            PlayerDrawer.NONE -> {}
        }
    }
}

@Composable
private fun TechBadge(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun OsdActionButton(
    icon: ImageVector,
    label: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (highlighted) TiviColors.AccentBlue else Color.White,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            color = if (highlighted) TiviColors.AccentBlue else TiviColors.TextSecondary,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
