package com.tiviplayer.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tiviplayer.app.data.EpisodeItem
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.screens.*
import com.tiviplayer.app.ui.theme.TiviColors
import com.tiviplayer.app.ui.theme.TiviPlayerTheme
import kotlinx.coroutines.launch

private enum class MainTab { SEARCH, TV, MOVIES, SHOWS, RECORDINGS, MY_LIST }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            val termsAccepted by vm.termsAccepted.collectAsState()
            val playlists by vm.playlists.collectAsState()
            val channels by vm.channels.collectAsState()
            val favorites by vm.favorites.collectAsState()

            val context = LocalContext.current
            val scope = rememberCoroutineScope()

            var showAddPlaylist by remember { mutableStateOf(false) }
            var showSettings by remember { mutableStateOf(false) }
            var currentTab by remember { mutableStateOf(MainTab.TV) }
            var activePlayer by remember { mutableStateOf<PlayerRequest?>(null) }
            var activeMultiview by remember { mutableStateOf<Pair<String, String>?>(null) }
            var lastBackPressMs by remember { mutableLongStateOf(0L) }

            val permLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { }

            LaunchedEffect(termsAccepted) {
                if (termsAccepted) {
                    val perms = mutableListOf<String>()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
                        }
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            perms.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    } else {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    }
                    if (perms.isNotEmpty()) permLauncher.launch(perms.toTypedArray())
                }
            }

            BackHandler {
                when {
                    showSettings -> showSettings = false
                    activeMultiview != null -> activeMultiview = null
                    activePlayer != null -> activePlayer = null
                    showAddPlaylist -> showAddPlaylist = false
                    settings.confirmExitOnBack -> {
                        val now = System.currentTimeMillis()
                        if (now - lastBackPressMs < 2000L) {
                            finish()
                        } else {
                            lastBackPressMs = now
                            Toast.makeText(context, "Press Back again to exit", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else -> finish()
                }
            }

            TiviPlayerTheme(settings = settings) {
                Box(modifier = Modifier.fillMaxSize().background(TiviColors.BgRoot)) {
                    when {
                        !termsAccepted -> {
                            TermsOfUseScreen(
                                onAccept = { vm.acceptTerms() },
                                onDeclineAndExit = { finish() }
                            )
                        }
                        showAddPlaylist -> {
                            AddPlaylistFlowScreen(
                                viewModel = vm,
                                onDone = { showAddPlaylist = false },
                                onCancel = { showAddPlaylist = false }
                            )
                        }
                        activeMultiview != null -> {
                            MultiviewScreen(
                                viewModel = vm,
                                initialChannelTitle = activeMultiview!!.first,
                                initialUrl = activeMultiview!!.second,
                                onBack = { activeMultiview = null }
                            )
                        }
                        activePlayer != null -> {
                            PlayerScreen(
                                request = activePlayer!!,
                                settings = settings,
                                onBack = { activePlayer = null },
                                onOpenSearch = { activePlayer = null; currentTab = MainTab.SEARCH },
                                onOpenChannelsList = { activePlayer = null; currentTab = MainTab.TV },
                                onOpenRecordings = { activePlayer = null; currentTab = MainTab.RECORDINGS },
                                onOpenMultiview = {
                                    activeMultiview = activePlayer!!.title to activePlayer!!.url
                                },
                                onStartRecording = {
                                    val req = activePlayer!!
                                    vm.startRecording(req.title, req.url)
                                    Toast.makeText(context, "Recording started: ${req.title}", Toast.LENGTH_SHORT).show()
                                },
                                onOpenSettings = { showSettings = true },
                                onToggleFavorite = { chId ->
                                    vm.toggleFavoriteChannel(chId)
                                    activePlayer = activePlayer?.copy(isFavorite = !activePlayer!!.isFavorite)
                                },
                                onNextChannel = {
                                    val curId = activePlayer?.channelId
                                    val idx = channels.indexOfFirst { it.id == curId }
                                    if (idx >= 0 && channels.isNotEmpty()) {
                                        val next = channels[(idx + 1) % channels.size]
                                        scope.launch {
                                            val url = vm.resolveChannelPlayableUrl(next)
                                            if (url.isNotBlank()) {
                                                activePlayer = PlayerRequest(next.name, url, false, false, next.id, next.groupName, favorites.contains(next.id))
                                            }
                                        }
                                    }
                                },
                                onPrevChannel = {
                                    val curId = activePlayer?.channelId
                                    val idx = channels.indexOfFirst { it.id == curId }
                                    if (idx >= 0 && channels.isNotEmpty()) {
                                        val prev = channels[(idx - 1 + channels.size) % channels.size]
                                        scope.launch {
                                            val url = vm.resolveChannelPlayableUrl(prev)
                                            if (url.isNotBlank()) {
                                                activePlayer = PlayerRequest(prev.name, url, false, false, prev.id, prev.groupName, favorites.contains(prev.id))
                                            }
                                        }
                                    }
                                },
                                onDisplayModeApplyAll = { mode ->
                                    vm.updateSettings { it.copy(globalDisplayMode = mode) }
                                }
                            )
                        }
                        playlists.isEmpty() -> {
                            EmptyHomeScreen(
                                onAddPlaylist = { showAddPlaylist = true },
                                onOpenSettings = { showSettings = true }
                            )
                        }
                        else -> {
                            Row(modifier = Modifier.fillMaxSize()) {
                                Column(
                                    modifier = Modifier
                                        .width(148.dp)
                                        .fillMaxHeight()
                                        .background(Color(0xFF14161B))
                                        .padding(vertical = 18.dp, horizontal = 10.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("tivi", color = TiviColors.AccentBlue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                            Text("mate", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Light)
                                        }
                                        Spacer(Modifier.height(14.dp))
                                        NavRailItem(Icons.Default.Search, "Search", currentTab == MainTab.SEARCH) { currentTab = MainTab.SEARCH }
                                        NavRailItem(Icons.Default.Tv, "TV", currentTab == MainTab.TV) { currentTab = MainTab.TV }
                                        NavRailItem(Icons.Default.Movie, "Movies", currentTab == MainTab.MOVIES) { currentTab = MainTab.MOVIES }
                                        NavRailItem(Icons.Default.LiveTv, "Shows", currentTab == MainTab.SHOWS) { currentTab = MainTab.SHOWS }
                                        NavRailItem(Icons.Default.Dvr, "Recordings", currentTab == MainTab.RECORDINGS) { currentTab = MainTab.RECORDINGS }
                                        NavRailItem(Icons.Default.Bookmark, "My list", currentTab == MainTab.MY_LIST) { currentTab = MainTab.MY_LIST }
                                    }
                                    NavRailItem(Icons.Default.Settings, "Settings", false) { showSettings = true }
                                }

                                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                    when (currentTab) {
                                        MainTab.TV -> TvGuideScreen(
                                            viewModel = vm,
                                            onPlayChannel = { ch ->
                                                scope.launch {
                                                    val url = vm.resolveChannelPlayableUrl(ch)
                                                    if (url.isNotBlank()) {
                                                        activePlayer = PlayerRequest(
                                                            title = ch.customName ?: ch.name,
                                                            url = url,
                                                            isVod = false,
                                                            channelId = ch.id,
                                                            groupLabel = ch.groupName,
                                                            isFavorite = favorites.contains(ch.id)
                                                        )
                                                    } else {
                                                        Toast.makeText(context, "Stream URL unavailable", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            onOpenSearch = { currentTab = MainTab.SEARCH },
                                            onOpenSettings = { showSettings = true }
                                        )
                                        MainTab.MOVIES -> VodBrowseScreen(
                                            viewModel = vm,
                                            isSeries = false,
                                            onPlayVod = { vod, _ ->
                                                scope.launch {
                                                    val url = vm.resolveVodPlayableUrl(vod)
                                                    if (url.isNotBlank()) {
                                                        vm.addVodHistory(vod.id)
                                                        activePlayer = PlayerRequest(
                                                            title = vod.title,
                                                            url = url,
                                                            isVod = true,
                                                            isSeries = false
                                                        )
                                                    }
                                                }
                                            },
                                            onOpenSearch = { currentTab = MainTab.SEARCH }
                                        )
                                        MainTab.SHOWS -> VodBrowseScreen(
                                            viewModel = vm,
                                            isSeries = true,
                                            onPlayVod = { show, ep: EpisodeItem? ->
                                                scope.launch {
                                                    val url = ep?.streamUrl?.takeIf { it.isNotBlank() } ?: vm.resolveVodPlayableUrl(show)
                                                    if (url.isNotBlank()) {
                                                        vm.addVodHistory(show.id)
                                                        val epTitle = if (ep != null) {
                                                            "${show.title} - S%02dE%02d - ${ep.title}".format(ep.season, ep.episodeNum)
                                                        } else show.title
                                                        activePlayer = PlayerRequest(
                                                            title = epTitle,
                                                            url = url,
                                                            isVod = true,
                                                            isSeries = true
                                                        )
                                                    }
                                                }
                                            },
                                            onOpenSearch = { currentTab = MainTab.SEARCH }
                                        )
                                        MainTab.SEARCH -> SearchScreen(
                                            viewModel = vm,
                                            onPlayVod = { vod ->
                                                scope.launch {
                                                    val url = vm.resolveVodPlayableUrl(vod)
                                                    if (url.isNotBlank()) {
                                                        activePlayer = PlayerRequest(vod.title, url, isVod = true, isSeries = vod.isSeries)
                                                    }
                                                }
                                            },
                                            onPlayChannel = { ch ->
                                                scope.launch {
                                                    val url = vm.resolveChannelPlayableUrl(ch)
                                                    if (url.isNotBlank()) {
                                                        activePlayer = PlayerRequest(ch.customName ?: ch.name, url, isVod = false, channelId = ch.id)
                                                    }
                                                }
                                            }
                                        )
                                        MainTab.RECORDINGS -> RecordingsScreen(
                                            viewModel = vm,
                                            onPlayRecording = { rec ->
                                                activePlayer = PlayerRequest(
                                                    title = rec.title,
                                                    url = "file://${rec.filePath}",
                                                    isVod = true
                                                )
                                            }
                                        )
                                        MainTab.MY_LIST -> {
                                            VodBrowseScreen(
                                                viewModel = vm,
                                                isSeries = false,
                                                onPlayVod = { vod, _ ->
                                                    scope.launch {
                                                        val url = vm.resolveVodPlayableUrl(vod)
                                                        if (url.isNotBlank()) activePlayer = PlayerRequest(vod.title, url, isVod = true)
                                                    }
                                                },
                                                onOpenSearch = { currentTab = MainTab.SEARCH }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (showSettings) {
                        SettingsDrawerHost(
                            viewModel = vm,
                            onAddPlaylist = { showAddPlaylist = true },
                            onDismiss = { showSettings = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NavRailItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) Color(0xFF282B33) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Color.White else TiviColors.TextSecondary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, color = if (selected) Color.White else TiviColors.TextSecondary, fontSize = 13.sp)
    }
}
