package com.tiviplayer.app.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.tiviplayer.app.data.ChannelItem
import com.tiviplayer.app.network.PlaylistClients
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.components.TiviRightDrawer
import com.tiviplayer.app.ui.theme.TiviColors
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun MultiviewScreen(
    viewModel: MainViewModel,
    initialChannelTitle: String,
    initialUrl: String,
    onBack: () -> Unit
) {
    val channels by viewModel.channels.collectAsState()
    val scope = rememberCoroutineScope()

    var slots by remember {
        mutableStateOf(
            listOf(
                initialChannelTitle to initialUrl,
                null as Pair<String, String>?
            )
        )
    }
    var activeSlotIndex by remember { mutableIntStateOf(0) }
    var pickingForSlot by remember { mutableStateOf<Int?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF14161B))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text("Multiview", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (slots.size < 4) {
                        TextButton(onClick = { slots = slots + null }) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = TiviColors.AccentBlue)
                            Spacer(Modifier.width(4.dp))
                            Text("Add screen", color = TiviColors.AccentBlue)
                        }
                    }
                }
            }

            // Grid of Video Tiles (2 or 4 screens)
            val rows = slots.chunked(2)
            Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                rows.forEachIndexed { rIdx, rowItems ->
                    Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        rowItems.forEachIndexed { cIdx, slot ->
                            val idx = rIdx * 2 + cIdx
                            val isActive = activeSlotIndex == idx
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .padding(3.dp)
                                    .border(
                                        width = if (isActive) 2.dp else 1.dp,
                                        color = if (isActive) TiviColors.AccentBlue else Color.DarkGray,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .clickable {
                                        if (slot == null) pickingForSlot = idx else activeSlotIndex = idx
                                    }
                            ) {
                                if (slot != null) {
                                    MultiviewTilePlayer(
                                        url = slot.second,
                                        muted = !isActive
                                    )
                                    Row(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .fillMaxWidth()
                                            .background(Color.Black.copy(alpha = 0.6f))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(slot.first, color = Color.White, fontSize = 12.sp)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (isActive) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = "Audio active", tint = TiviColors.AccentBlue, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(8.dp))
                                            }
                                            Text(
                                                "Change",
                                                color = TiviColors.AccentBlue,
                                                fontSize = 11.sp,
                                                modifier = Modifier.clickable { pickingForSlot = idx }
                                            )
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier.align(Alignment.Center),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Add channel", tint = Color.White, modifier = Modifier.size(32.dp))
                                        Spacer(Modifier.height(4.dp))
                                        Text("Add channel", color = TiviColors.TextSecondary, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        pickingForSlot?.let { slotIdx ->
            TiviRightDrawer("Select channel", onDismiss = { pickingForSlot = null }) {
                LazyColumn {
                    items(channels.take(150)) { ch: ChannelItem ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    pickingForSlot = null
                                    scope.launch {
                                        val url = viewModel.resolveChannelPlayableUrl(ch)
                                        if (url.isNotBlank()) {
                                            val updated = slots.toMutableList()
                                            updated[slotIdx] = ch.name to url
                                            slots = updated
                                            activeSlotIndex = slotIdx
                                        }
                                    }
                                }
                                .padding(horizontal = 20.dp, vertical = 11.dp)
                        ) {
                            Text("${ch.number}. ${ch.name}", color = Color.White, fontSize = 14.sp)
                            Text(ch.groupName, color = TiviColors.TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun MultiviewTilePlayer(url: String, muted: Boolean) {
    val context = LocalContext.current
    val player = remember(url) {
        val factory = OkHttpDataSource.Factory(PlaylistClients.httpClient).setUserAgent("TiviPlayer/1.0")
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(factory))
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(url))
                prepare()
                playWhenReady = true
            }
    }
    LaunchedEffect(muted) {
        player.volume = if (muted) 0f else 1f
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
