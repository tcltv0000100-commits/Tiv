package com.tiviplayer.app.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.tiviplayer.app.data.ChannelItem
import com.tiviplayer.app.data.EpgProgram
import com.tiviplayer.app.data.VodItem
import com.tiviplayer.app.ui.MainViewModel
import com.tiviplayer.app.ui.theme.TiviColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SearchScreen(
    viewModel: MainViewModel,
    onPlayVod: (VodItem) -> Unit,
    onPlayChannel: (ChannelItem) -> Unit
) {
    val context = LocalContext.current
    val playlists by viewModel.playlists.collectAsState()
    val movies by viewModel.movies.collectAsState()
    val shows by viewModel.shows.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val epgPrograms by viewModel.epgPrograms.collectAsState()
    val history by viewModel.searchHistory.collectAsState()

    var query by remember { mutableStateOf("") }
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var selectedProgram by remember { mutableStateOf<EpgProgram?>(null) }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                query = text
                viewModel.addSearchQuery(text)
            }
        }
    }

    val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search")
            }
            runCatching { voiceLauncher.launch(intent) }
        }
    }

    val matchedMovies = remember(query, movies, selectedPlaylistId) {
        if (query.isBlank()) emptyList()
        else movies.filter {
            it.title.contains(query, ignoreCase = true) &&
                (selectedPlaylistId == null || it.playlistId == selectedPlaylistId)
        }.take(30)
    }

    val matchedShows = remember(query, shows, selectedPlaylistId) {
        if (query.isBlank()) emptyList()
        else shows.filter {
            it.title.contains(query, ignoreCase = true) &&
                (selectedPlaylistId == null || it.playlistId == selectedPlaylistId)
        }.take(30)
    }

    val matchedPrograms = remember(query, epgPrograms) {
        if (query.isBlank()) emptyList()
        else epgPrograms.filter { it.title.contains(query, ignoreCase = true) }.take(30)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.BgRoot)
            .padding(24.dp)
    ) {
        // Top Mic + Search Input
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(
                onClick = {
                    val hasPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasPerm) {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search")
                        }
                        runCatching { voiceLauncher.launch(intent) }
                    } else {
                        micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(TiviColors.BgCard)
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Voice search", tint = Color.White)
            }
            Spacer(Modifier.width(14.dp))
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    if (it.length >= 3) viewModel.addSearchQuery(it)
                },
                placeholder = { Text("Search", color = TiviColors.TextSecondary) },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .background(TiviColors.BgCard, RoundedCornerShape(6.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
        }

        Spacer(Modifier.height(18.dp))

        if (query.isBlank()) {
            // Search History
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Search history", color = TiviColors.TextSecondary, fontSize = 14.sp)
                IconButton(onClick = { viewModel.clearSearchHistory() }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear history", tint = TiviColors.TextSecondary)
                }
            }
            if (history.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No history", color = TiviColors.TextSecondary, fontSize = 14.sp)
                }
            } else {
                LazyColumn {
                    items(history) { item ->
                        Text(
                            item,
                            color = TiviColors.TextPrimary,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { query = item }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        } else {
            // Playlist Filter Pills
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedPlaylistId == null,
                        onClick = { selectedPlaylistId = null },
                        label = { Text("All playlists") }
                    )
                }
                items(playlists) { pl ->
                    FilterChip(
                        selected = selectedPlaylistId == pl.id,
                        onClick = { selectedPlaylistId = pl.id },
                        label = { Text(pl.name) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                if (matchedMovies.isNotEmpty()) {
                    item {
                        Text("Movies", color = TiviColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(matchedMovies) { m ->
                                VodPosterCard(m, selected = false) { onPlayVod(m) }
                            }
                        }
                    }
                }
                if (matchedShows.isNotEmpty()) {
                    item {
                        Text("Shows", color = TiviColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(matchedShows) { s ->
                                VodPosterCard(s, selected = false) { onPlayVod(s) }
                            }
                        }
                    }
                }
                if (matchedPrograms.isNotEmpty()) {
                    item {
                        Text("Programs", color = TiviColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                            LazyColumn(modifier = Modifier.weight(1f)) {
                                items(matchedPrograms) { prog ->
                                    val fmt = SimpleDateFormat("EEE, dd MMM, h:mm a", Locale.US)
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedProgram = prog }
                                            .padding(vertical = 8.dp)
                                    ) {
                                        Text(prog.title, color = Color.White, fontSize = 14.sp)
                                        Text(fmt.format(Date(prog.startTimeMs)), color = TiviColors.TextSecondary, fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(TiviColors.BgSurface, RoundedCornerShape(6.dp))
                                    .padding(14.dp)
                            ) {
                                val p = selectedProgram ?: matchedPrograms.first()
                                Text(p.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                Spacer(Modifier.height(6.dp))
                                Text(p.description, color = TiviColors.TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
