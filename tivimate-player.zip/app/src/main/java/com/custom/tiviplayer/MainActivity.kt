package com.custom.tiviplayer

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.custom.tiviplayer.data.AppStorage
import com.custom.tiviplayer.data.EpgParser
import com.custom.tiviplayer.data.PlaylistParser
import com.custom.tiviplayer.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

data class DrawerItem(
    val title: String,
    val subtitle: String? = null,
    val section: String? = null,
    val iconRes: Int? = null,
    val isChecked: Boolean? = null,
    val onToggle: ((Boolean) -> Unit)? = null,
    val onClick: (() -> Unit)? = null
)

class MainActivity : AppCompatActivity() {

    private lateinit var storage: AppStorage
    private lateinit var welcomeOverlay: LinearLayout
    private lateinit var drawerBackdrop: FrameLayout
    private lateinit var drawerTitle: TextView
    private lateinit var drawerRecycler: RecyclerView
    private lateinit var groupsSidebar: LinearLayout
    private lateinit var groupsRecycler: RecyclerView

    private lateinit var epgSection: LinearLayout
    private lateinit var vodSection: LinearLayout
    private lateinit var searchSection: LinearLayout
    private lateinit var simpleListSection: LinearLayout

    private var previewPlayer: ExoPlayer? = null
    private lateinit var previewPlayerView: PlayerView

    private var allChannels = mutableListOf<ChannelItem>()
    private var visibleChannels = mutableListOf<ChannelItem>()
    private var allMovies = mutableListOf<VodMovie>()
    private var allShows = mutableListOf<VodShow>()
    private var epgMap = mutableMapOf<String, MutableList<EpgProgram>>()

    private var currentFilterPlaylistId: String? = null
    private var currentFilterGroup: String? = null
    private var currentTab = "tv"
    private var lastBackMs = 0L

    private val addPlaylistLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            reloadAllData()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        storage = AppStorage(this)

        welcomeOverlay = findViewById(R.id.welcomeOverlay)
        drawerBackdrop = findViewById(R.id.drawerBackdrop)
        drawerTitle = findViewById(R.id.drawerHeaderTitle)
        drawerRecycler = findViewById(R.id.drawerRecycler)
        groupsSidebar = findViewById(R.id.groupsSidebar)
        groupsRecycler = findViewById(R.id.groupsRecycler)

        epgSection = findViewById(R.id.epgSection)
        vodSection = findViewById(R.id.vodSection)
        searchSection = findViewById(R.id.searchSection)
        simpleListSection = findViewById(R.id.simpleListSection)
        previewPlayerView = findViewById(R.id.previewPlayerView)

        drawerRecycler.layoutManager = LinearLayoutManager(this)
        groupsRecycler.layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.epgRecycler).layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.vodRowsRecycler).layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.simpleListRecycler).layoutManager = LinearLayoutManager(this)

        drawerBackdrop.setOnClickListener { closeDrawer() }

        findViewById<Button>(R.id.welcomeAddPlaylistBtn).setOnClickListener {
            addPlaylistLauncher.launch(Intent(this, AddPlaylistActivity::class.java))
        }
        findViewById<Button>(R.id.welcomeSettingsBtn).setOnClickListener { openSettingsDrawer() }

        setupLeftRail()
        setupSearchUi()
        reloadAllData()

        when (intent.getStringExtra("open_tab")) {
            "search" -> switchTab("search")
            "recordings" -> switchTab("recordings")
            "settings" -> openSettingsDrawer()
        }
    }

    private fun reloadAllData() {
        val playlists = storage.getPlaylists()
        if (playlists.isEmpty()) {
            welcomeOverlay.visibility = View.VISIBLE
            findViewById<Button>(R.id.welcomeAddPlaylistBtn).requestFocus()
            return
        }
        welcomeOverlay.visibility = View.GONE

        allChannels.clear()
        allMovies.clear()
        allShows.clear()
        val favs = storage.getFavorites()

        playlists.filter { it.enabled }.forEach { p ->
            val chs = storage.loadChannels(p.id).filter { !p.hiddenChannels.contains(it.id) && !p.blockedChannels.contains(it.id) }
            allChannels.addAll(chs)
            allMovies.addAll(storage.loadMovies(p.id))
            allShows.addAll(storage.loadShows(p.id))
        }
        epgMap = storage.loadEpgMap()

        updateTimeRuler()
        applyChannelFilter(currentFilterPlaylistId, currentFilterGroup, favs)
        buildGroupsSidebar()
    }

    private fun updateTimeRuler() {
        val now = Calendar.getInstance()
        findViewById<TextView>(R.id.epgDateClock).text =
            SimpleDateFormat("EEE, d MMM, h:mm a", Locale.US).format(now.time)
        val min = now.get(Calendar.MINUTE)
        now.set(Calendar.MINUTE, if (min < 30) 0 else 30)
        now.set(Calendar.SECOND, 0)
        val fmt = SimpleDateFormat("h:mm a", Locale.US)
        findViewById<TextView>(R.id.epgSlot1).text = fmt.format(now.time)
        now.add(Calendar.MINUTE, 30)
        findViewById<TextView>(R.id.epgSlot2).text = fmt.format(now.time)
        now.add(Calendar.MINUTE, 30)
        findViewById<TextView>(R.id.epgSlot3).text = fmt.format(now.time)
    }

    private fun setupLeftRail() {
        findViewById<ImageButton>(R.id.railSearch).setOnClickListener { switchTab("search") }
        findViewById<ImageButton>(R.id.railTv).setOnClickListener {
            if (currentTab == "tv") {
                groupsSidebar.visibility = if (groupsSidebar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            } else {
                switchTab("tv")
            }
        }
        findViewById<ImageButton>(R.id.railMovies).setOnClickListener { switchTab("movies") }
        findViewById<ImageButton>(R.id.railShows).setOnClickListener { switchTab("shows") }
        findViewById<ImageButton>(R.id.railRecordings).setOnClickListener { switchTab("recordings") }
        findViewById<ImageButton>(R.id.railMyList).setOnClickListener { switchTab("mylist") }
        findViewById<ImageButton>(R.id.railSettings).setOnClickListener { openSettingsDrawer() }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        epgSection.visibility = if (tab == "tv") View.VISIBLE else View.GONE
        vodSection.visibility = if (tab == "movies" || tab == "shows") View.VISIBLE else View.GONE
        searchSection.visibility = if (tab == "search") View.VISIBLE else View.GONE
        simpleListSection.visibility = if (tab == "recordings" || tab == "mylist") View.VISIBLE else View.GONE
        groupsSidebar.visibility = View.GONE

        when (tab) {
            "tv" -> renderEpgList()
            "movies" -> renderVodSection(isShows = false)
            "shows" -> renderVodSection(isShows = true)
            "search" -> renderSearchHistory()
            "recordings" -> renderSimpleList("Recordings")
            "mylist" -> renderSimpleList("My list")
        }
    }

    private fun buildGroupsSidebar() {
        val playlists = storage.getPlaylists().filter { it.enabled }
        val rows = mutableListOf<DrawerItem>()
        val settings = storage.getSettings()

        if (settings.showAllPlaylistsCategory) {
            rows.add(DrawerItem("All playlists", section = "Categories") {
                applyChannelFilter(null, null, storage.getFavorites())
                groupsSidebar.visibility = View.GONE
            })
        }
        if (settings.showFavoritesCategory) {
            rows.add(DrawerItem("Favorites") {
                applyChannelFilter(null, "__FAV__", storage.getFavorites())
                groupsSidebar.visibility = View.GONE
            })
        }
        if (settings.showAllChannelsCategory) {
            rows.add(DrawerItem("All channels") {
                applyChannelFilter(null, null, storage.getFavorites())
                groupsSidebar.visibility = View.GONE
            })
        }

        playlists.forEach { p ->
            rows.add(DrawerItem(p.name, section = p.name) {
                applyChannelFilter(p.id, null, storage.getFavorites())
                groupsSidebar.visibility = View.GONE
            })
            val groups = allChannels.filter { it.playlistId == p.id }.map { it.groupTitle }.distinct()
            groups.filter { !p.hiddenTvGroups.contains(it) }.forEach { g ->
                rows.add(DrawerItem(g) {
                    applyChannelFilter(p.id, g, storage.getFavorites())
                    groupsSidebar.visibility = View.GONE
                })
            }
        }
        groupsRecycler.adapter = DrawerAdapter(rows)
    }

    private fun applyChannelFilter(playlistId: String?, group: String?, favs: Set<String>) {
        currentFilterPlaylistId = playlistId
        currentFilterGroup = group
        visibleChannels = allChannels.filter { ch ->
            val pOk = playlistId == null || ch.playlistId == playlistId
            val gOk = when (group) {
                null -> true
                "__FAV__" -> favs.contains(ch.id)
                else -> ch.groupTitle == group
            }
            pOk && gOk
        }.toMutableList()
        renderEpgList()
    }

    private fun renderEpgList() {
        val rv = findViewById<RecyclerView>(R.id.epgRecycler)
        val now = System.currentTimeMillis()
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.item_epg_row, parent, false)
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun getItemCount() = visibleChannels.size

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val ch = visibleChannels[position]
                val v = holder.itemView
                val numTv = v.findViewById<TextView>(R.id.epgRowNumber)
                val logoIv = v.findViewById<ImageView>(R.id.epgRowLogo)
                val nameTv = v.findViewById<TextView>(R.id.epgRowName)
                val c1 = v.findViewById<TextView>(R.id.epgCell1)
                val c2 = v.findViewById<TextView>(R.id.epgCell2)
                val c3 = v.findViewById<TextView>(R.id.epgCell3)

                numTv.text = ch.number.toString()
                nameTv.text = ch.name
                logoIv.load(ch.logoUrl)

                val progs = epgMap[ch.tvgId]?.filter { it.endMs >= now }?.sortedBy { it.startMs } ?: emptyList()
                c1.text = progs.getOrNull(0)?.title ?: "No information"
                c2.text = progs.getOrNull(1)?.title ?: "No information"
                c3.text = progs.getOrNull(2)?.title ?: "No information"

                v.setOnFocusChangeListener { _, hasFocus ->
                    if (hasFocus) {
                        updateTopPreviewInfo(ch, progs.firstOrNull())
                        c1.setBackgroundColor(getColor(R.color.tivi_epg_cell_focused))
                        c1.setTextColor(getColor(R.color.tivi_text_dark))
                    } else {
                        c1.setBackgroundColor(getColor(R.color.tivi_epg_cell_active))
                        c1.setTextColor(getColor(R.color.tivi_text_primary))
                    }
                }
                v.setOnClickListener {
                    if (ch.useExternalPlayer) {
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(ch.streamUrl), "video/*")
                        runCatching { startActivity(i) }
                    } else {
                        startActivity(Intent(this@MainActivity, PlayerActivity::class.java).putExtra("channel_id", ch.id))
                    }
                }
                v.setOnLongClickListener {
                    openChannelContextMenu(ch, progs.firstOrNull())
                    true
                }
            }
        }
        visibleChannels.firstOrNull()?.let { ch ->
            updateTopPreviewInfo(ch, epgMap[ch.tvgId]?.firstOrNull())
        }
    }

    private fun updateTopPreviewInfo(ch: ChannelItem, prog: EpgProgram?) {
        val playlistName = storage.getPlaylists().find { it.id == ch.playlistId }?.name ?: "Playlist"
        findViewById<TextView>(R.id.epgProgramTitle).text = prog?.title ?: "No information"
        findViewById<TextView>(R.id.epgProgramDesc).text = prog?.description?.ifEmpty { "No details available" } ?: "No details available"
        findViewById<TextView>(R.id.epgTopPlaylistGroup).text = "$playlistName • ${ch.groupTitle}"
        findViewById<ImageButton>(R.id.epgTopFavBtn).setOnClickListener {
            val added = storage.toggleFavorite(ch.id)
            Toast.makeText(this, if (added) "Added to Favorites" else "Removed from Favorites", Toast.LENGTH_SHORT).show()
        }

        if (previewPlayer == null) {
            previewPlayer = ExoPlayer.Builder(this).build().also { previewPlayerView.player = it }
        }
        previewPlayer?.apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(ch.streamUrl)))
            prepare()
            playWhenReady = true
        }
    }

    private fun renderVodSection(isShows: Boolean) {
        val rv = findViewById<RecyclerView>(R.id.vodRowsRecycler)
        val heroTitle = findViewById<TextView>(R.id.vodHeroTitle)
        val heroMeta = findViewById<TextView>(R.id.vodHeroMeta)
        val heroDesc = findViewById<TextView>(R.id.vodHeroDesc)
        val heroBackdrop = findViewById<ImageView>(R.id.vodHeroBackdrop)
        val playBtn = findViewById<Button>(R.id.vodPlayBtn)
        val myListBtn = findViewById<Button>(R.id.vodMyListBtn)

        if (!isShows) {
            val grouped = allMovies.groupBy { it.groupTitle }.entries.toList()
            allMovies.firstOrNull()?.let { m ->
                heroTitle.text = m.title
                heroMeta.text = listOf(m.rating, m.year, m.duration, m.genres).filter { it.isNotEmpty() }.joinToString(" • ")
                heroDesc.text = m.description.ifEmpty { m.groupTitle }
                heroBackdrop.load(m.backdropUrl.ifEmpty { m.posterUrl })
                playBtn.setOnClickListener { playVodUrl(m.streamUrl, m.title) }
                myListBtn.setOnClickListener { storage.toggleMyListVod(m.id) }
            }
            rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
                    object : RecyclerView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_vod_row, parent, false)) {}

                override fun getItemCount() = grouped.size

                override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
                    val (gTitle, items) = grouped[pos]
                    holder.itemView.findViewById<TextView>(R.id.vodGroupTitle).text = gTitle
                    val hRv = holder.itemView.findViewById<RecyclerView>(R.id.vodGroupRecycler)
                    hRv.layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
                    hRv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                        override fun onCreateViewHolder(p: ViewGroup, vt: Int) =
                            object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_vod_poster, p, false)) {}

                        override fun getItemCount() = items.size.coerceAtMost(40)

                        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                            val m = items[i]
                            h.itemView.findViewById<TextView>(R.id.vodPosterTitle).text = m.title
                            val badge = h.itemView.findViewById<TextView>(R.id.vodRatingBadge)
                            badge.text = m.rating.ifEmpty { "HD" }
                            h.itemView.findViewById<ImageView>(R.id.vodPosterImg).load(m.posterUrl)
                            h.itemView.setOnFocusChangeListener { _, hasFocus ->
                                if (hasFocus) {
                                    heroTitle.text = m.title
                                    heroDesc.text = m.description.ifEmpty { m.groupTitle }
                                    heroBackdrop.load(m.backdropUrl.ifEmpty { m.posterUrl })
                                    playBtn.setOnClickListener { playVodUrl(m.streamUrl, m.title) }
                                }
                            }
                            h.itemView.setOnClickListener { playVodUrl(m.streamUrl, m.title) }
                        }
                    }
                }
            }
        } else {
            val grouped = allShows.groupBy { it.groupTitle }.entries.toList()
            allShows.firstOrNull()?.let { s ->
                heroTitle.text = s.title
                heroMeta.text = listOf(s.rating, s.year, s.genres).filter { it.isNotEmpty() }.joinToString(" • ")
                heroDesc.text = s.description.ifEmpty { s.groupTitle }
                heroBackdrop.load(s.backdropUrl.ifEmpty { s.posterUrl })
            }
            rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
                    object : RecyclerView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_vod_row, parent, false)) {}

                override fun getItemCount() = grouped.size

                override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
                    val (gTitle, items) = grouped[pos]
                    holder.itemView.findViewById<TextView>(R.id.vodGroupTitle).text = gTitle
                    val hRv = holder.itemView.findViewById<RecyclerView>(R.id.vodGroupRecycler)
                    hRv.layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
                    hRv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                        override fun onCreateViewHolder(p: ViewGroup, vt: Int) =
                            object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_vod_poster, p, false)) {}

                        override fun getItemCount() = items.size.coerceAtMost(40)

                        override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                            val s = items[i]
                            h.itemView.findViewById<TextView>(R.id.vodPosterTitle).text = s.title
                            h.itemView.findViewById<TextView>(R.id.vodRatingBadge).text = s.rating.ifEmpty { "TV" }
                            h.itemView.findViewById<ImageView>(R.id.vodPosterImg).load(s.posterUrl)
                            h.itemView.setOnFocusChangeListener { _, hasFocus ->
                                if (hasFocus) {
                                    heroTitle.text = s.title
                                    heroDesc.text = s.description.ifEmpty { s.groupTitle }
                                    heroBackdrop.load(s.backdropUrl.ifEmpty { s.posterUrl })
                                }
                            }
                            h.itemView.setOnClickListener { storage.toggleMyListVod(s.id) }
                        }
                    }
                }
            }
        }
    }

    private fun playVodUrl(url: String, title: String) {
        if (url.isEmpty()) return
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("vod_url", url).putExtra("vod_title", title))
    }

    private fun setupSearchUi() {
        val input = findViewById<EditText>(R.id.searchInput)
        findViewById<ImageButton>(R.id.searchSettingsBtn).setOnClickListener { openSettingsDrawer() }
        findViewById<ImageButton>(R.id.clearSearchHistoryBtn).setOnClickListener {
            storage.clearSearchHistory()
            renderSearchHistory()
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                performGlobalSearch(input.text.toString())
                true
            } else false
        }
    }

    private fun renderSearchHistory() {
        val hist = storage.getSearchHistory()
        findViewById<View>(R.id.searchHistoryContainer).visibility = View.VISIBLE
        findViewById<View>(R.id.searchResultsScroll).visibility = View.GONE
        findViewById<View>(R.id.searchProgress).visibility = View.GONE
        findViewById<TextView>(R.id.noHistoryText).visibility = if (hist.isEmpty()) View.VISIBLE else View.GONE
        val rv = findViewById<RecyclerView>(R.id.searchHistoryRecycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = DrawerAdapter(hist.map { q ->
            DrawerItem(q) {
                findViewById<EditText>(R.id.searchInput).setText(q)
                performGlobalSearch(q)
            }
        })
    }

    private fun performGlobalSearch(rawQuery: String) {
        val q = rawQuery.trim().lowercase()
        if (q.isEmpty()) {
            renderSearchHistory()
            return
        }
        storage.addSearchHistory(rawQuery.trim())
        findViewById<View>(R.id.searchHistoryContainer).visibility = View.GONE
        findViewById<View>(R.id.searchResultsScroll).visibility = View.GONE
        findViewById<View>(R.id.searchProgress).visibility = View.VISIBLE

        thread {
            val matchedMovies = allMovies.filter { it.title.lowercase().contains(q) }.take(60)
            val matchedShows = allShows.filter { it.title.lowercase().contains(q) }.take(60)
            val matchedChannels = allChannels.filter { it.name.lowercase().contains(q) }.take(60)

            runOnUiThread {
                findViewById<View>(R.id.searchProgress).visibility = View.GONE
                val scroll = findViewById<ScrollView>(R.id.searchResultsScroll)
                scroll.visibility = View.VISIBLE
                val container = findViewById<LinearLayout>(R.id.searchResultsContainer)
                container.removeAllViews()

                if (matchedMovies.isNotEmpty()) {
                    addSearchVodBlock(container, "Movies", matchedMovies.map { Triple(it.title, it.posterUrl, it.rating) to { playVodUrl(it.streamUrl, it.title) } })
                }
                if (matchedShows.isNotEmpty()) {
                    addSearchVodBlock(container, "Shows", matchedShows.map { Triple(it.title, it.posterUrl, it.rating) to { storage.toggleMyListVod(it.id) } })
                }
                if (matchedChannels.isNotEmpty()) {
                    val hdr = TextView(this).apply {
                        text = "Channels & Programs"
                        setTextColor(getColor(R.color.tivi_text_secondary))
                        textSize = 14f
                        setPadding(0, 12, 0, 8)
                    }
                    container.addView(hdr)
                    matchedChannels.forEach { ch ->
                        val row = LayoutInflater.from(this).inflate(R.layout.item_search_program, container, false)
                        row.findViewById<ImageView>(R.id.spLogo).load(ch.logoUrl)
                        row.findViewById<TextView>(R.id.spTitle).text = ch.name
                        row.findViewById<TextView>(R.id.spTime).text = ch.groupTitle
                        row.setOnClickListener {
                            startActivity(Intent(this, PlayerActivity::class.java).putExtra("channel_id", ch.id))
                        }
                        container.addView(row)
                    }
                }
            }
        }
    }

    private fun addSearchVodBlock(
        container: LinearLayout,
        header: String,
        items: List<Pair<Triple<String, String, String>, () -> Unit>>
    ) {
        val hdr = TextView(this).apply {
            text = header
            setTextColor(getColor(R.color.tivi_text_secondary))
            textSize = 14f
            setPadding(0, 8, 0, 8)
        }
        container.addView(hdr)
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun onCreateViewHolder(p: ViewGroup, vt: Int) =
                    object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_vod_poster, p, false)) {}

                override fun getItemCount() = items.size

                override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                    val (meta, act) = items[i]
                    h.itemView.findViewById<TextView>(R.id.vodPosterTitle).text = meta.first
                    h.itemView.findViewById<ImageView>(R.id.vodPosterImg).load(meta.second)
                    h.itemView.findViewById<TextView>(R.id.vodRatingBadge).text = meta.third.ifEmpty { "HD" }
                    h.itemView.setOnClickListener { act() }
                }
            }
        }
        container.addView(rv)
    }

    private fun renderSimpleList(title: String) {
        findViewById<TextView>(R.id.simpleListTitle).text = title
        val rv = findViewById<RecyclerView>(R.id.simpleListRecycler)
        val empty = findViewById<TextView>(R.id.simpleListEmpty)
        if (title == "Recordings") {
            val recs = storage.getRecordings()
            empty.visibility = if (recs.isEmpty()) View.VISIBLE else View.GONE
            rv.adapter = DrawerAdapter(recs.map { DrawerItem(it.title, it.channelName) })
        } else {
            val ids = storage.getMyListVod()
            val items = allMovies.filter { ids.contains(it.id) }.map { m ->
                DrawerItem(m.title, m.groupTitle) { playVodUrl(m.streamUrl, m.title) }
            }
            empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            rv.adapter = DrawerAdapter(items)
        }
    }

    private fun openChannelContextMenu(ch: ChannelItem, prog: EpgProgram?) {
        val playlist = storage.getPlaylists().find { it.id == ch.playlistId }
        val isFav = storage.getFavorites().contains(ch.id)
        openDrawer(
            ch.name,
            listOf(
                DrawerItem("Search", iconRes = R.drawable.ic_search) { closeDrawer(); switchTab("search") },
                DrawerItem("Settings", iconRes = R.drawable.ic_settings) { openSettingsDrawer() },
                DrawerItem("Watch from start", section = prog?.title ?: "Program") { closeDrawer() },
                DrawerItem("Open in external player") {
                    closeDrawer()
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(ch.streamUrl), "video/*")) }
                },
                DrawerItem("Record") {
                    storage.addRecording(RecordingEntry(UUID.randomUUID().toString(), prog?.title ?: ch.name, ch.name, System.currentTimeMillis()))
                    Toast.makeText(this, "Recording scheduled", Toast.LENGTH_SHORT).show()
                    closeDrawer()
                },
                DrawerItem("Custom recording") {
                    storage.addRecording(RecordingEntry(UUID.randomUUID().toString(), ch.name, ch.name, System.currentTimeMillis()))
                    Toast.makeText(this, "Custom recording saved", Toast.LENGTH_SHORT).show()
                    closeDrawer()
                },
                DrawerItem(if (isFav) "Remove from Favorites" else "Add to Favorites", section = ch.name) {
                    storage.toggleFavorite(ch.id)
                    closeDrawer()
                },
                DrawerItem("Block channel") {
                    playlist?.let {
                        it.blockedChannels.add(ch.id)
                        saveUpdatedPlaylist(it)
                    }
                    closeDrawer()
                    reloadAllData()
                },
                DrawerItem("Hide channel") {
                    playlist?.let {
                        it.hiddenChannels.add(ch.id)
                        saveUpdatedPlaylist(it)
                    }
                    closeDrawer()
                    reloadAllData()
                },
                DrawerItem("Channel options") { openChannelOptionsDrawer(ch) },
                DrawerItem("Manage groups", section = playlist?.name ?: "Playlist") {
                    playlist?.let { openManageGroupsDrawer(it) }
                }
            )
        )
    }

    private fun openChannelOptionsDrawer(ch: ChannelItem) {
        openDrawer(
            ch.name,
            listOf(
                DrawerItem("Channel name", ch.name),
                DrawerItem("Restore channel name", ch.originalName),
                DrawerItem("Audio decoder", ch.audioDecoder),
                DrawerItem("Video decoder", ch.videoDecoder),
                DrawerItem("Use external player", if (ch.useExternalPlayer) "Yes" else "No", isChecked = ch.useExternalPlayer, onToggle = { v ->
                    ch.useExternalPlayer = v
                }),
                DrawerItem("EPG time offset, h:min", "${ch.epgOffsetMin} min")
            )
        )
    }

    private fun openSettingsDrawer() {
        openDrawer(
            "Settings",
            listOf(
                DrawerItem("General") { openGeneralSettings() },
                DrawerItem("Playlists") { openPlaylistsDrawer() },
                DrawerItem("EPG") { openEpgSettings() },
                DrawerItem("Appearance") { openAppearanceSettings() },
                DrawerItem("Playback") { openPlaybackSettings() },
                DrawerItem("Remote control") { openRemoteSettings() },
                DrawerItem("Parental controls") { openParentalSettings() },
                DrawerItem("Other") { openOtherSettings() },
                DrawerItem("About", "TiviMate Player v1.0.0")
            )
        )
    }

    private fun openGeneralSettings() {
        val s = storage.getSettings()
        openDrawer(
            "General",
            listOf(
                DrawerItem("Auto start app on boot", isChecked = s.autoStartBoot, onToggle = { s.autoStartBoot = it; storage.saveSettings(s) }),
                DrawerItem("Auto start app on wake from sleep mode", isChecked = s.autoStartWake, onToggle = { s.autoStartWake = it; storage.saveSettings(s) }),
                DrawerItem("Turn on last channel on app start", isChecked = s.turnOnLastChannel, onToggle = { s.turnOnLastChannel = it; storage.saveSettings(s) }),
                DrawerItem("Switch to picture-in-picture mode on press Home", isChecked = s.pipOnHome, onToggle = { s.pipOnHome = it; storage.saveSettings(s) }),
                DrawerItem("Confirm exit by second press Back", isChecked = s.confirmExitBack, onToggle = { s.confirmExitBack = it; storage.saveSettings(s) }),
                DrawerItem("User-Agent", s.globalUserAgent.ifEmpty { "Not set" }),
                DrawerItem("UDP proxy (address:port)", s.udpProxy.ifEmpty { "Not set" }),
                DrawerItem("Back up data") {
                    Toast.makeText(this, "Backup exported (${storage.exportBackupJson().length} bytes)", Toast.LENGTH_SHORT).show()
                },
                DrawerItem("Restore data") { Toast.makeText(this, "Select backup file", Toast.LENGTH_SHORT).show() }
            )
        )
    }

    private fun openPlaylistsDrawer() {
        val playlists = storage.getPlaylists()
        val items = mutableListOf<DrawerItem>()
        playlists.forEach { p ->
            val sub = buildString {
                append("Channels: ${p.channelCount}")
                if (p.movieCount > 0) append(", movies: ${p.movieCount}")
                if (p.showCount > 0) append(", shows: ${p.showCount}")
            }
            items.add(DrawerItem(p.name, sub, iconRes = if (p.enabled) R.drawable.ic_check_circle else null) {
                openPlaylistDetailsDrawer(p)
            })
        }
        items.add(DrawerItem("Add playlist") {
            closeDrawer()
            addPlaylistLauncher.launch(Intent(this, AddPlaylistActivity::class.java))
        })
        items.add(DrawerItem("Update all playlists") {
            Toast.makeText(this, "Updating playlists...", Toast.LENGTH_SHORT).show()
            thread {
                playlists.forEach { p ->
                    runCatching {
                        val res = PlaylistParser.fetchAndParse(this, p)
                        p.channelCount = res.channels.size
                        p.movieCount = res.movies.size
                        p.showCount = res.shows.size
                        storage.saveChannels(p.id, res.channels)
                        storage.saveMovies(p.id, res.movies)
                        storage.saveShows(p.id, res.shows)
                    }
                }
                storage.savePlaylists(playlists)
                runOnUiThread { reloadAllData(); Toast.makeText(this, "Playlists updated", Toast.LENGTH_SHORT).show() }
            }
        })
        items.add(DrawerItem("Playlists sorting", "By name"))
        items.add(DrawerItem("Reorder playlists"))
        openDrawer("Playlists", items)
    }

    private fun openPlaylistDetailsDrawer(p: PlaylistConfig) {
        val items = mutableListOf(
            DrawerItem("Enable playlist", isChecked = p.enabled, onToggle = { v -> p.enabled = v; saveUpdatedPlaylist(p); reloadAllData() }),
            DrawerItem("Playlist name", p.name),
            DrawerItem("EPG sources", if (p.epgUrl.isNotEmpty()) "1 source" else "None"),
            DrawerItem("Logos priority", p.logosPriority),
            DrawerItem("Catch-up", p.catchUpType),
            DrawerItem("User-Agent", p.userAgent.ifEmpty { "Not set" }),
            DrawerItem(if (p.type == PlaylistType.STALKER) "Stalker Portal parameters" else "Xtream Codes parameters") {
                openDrawer(
                    if (p.type == PlaylistType.STALKER) "Stalker Portal parameters" else "Xtream Codes parameters",
                    listOf(
                        DrawerItem("Server address", p.url),
                        DrawerItem("Username", p.username.ifEmpty { "Not set" }),
                        DrawerItem("MAC address", p.macAddress),
                        DrawerItem("Output format", p.outputFormat),
                        DrawerItem("Expiration date", p.expirationDate.ifEmpty { "Unlimited" })
                    )
                )
            },
            DrawerItem("Manage groups") { openManageGroupsDrawer(p) },
            DrawerItem("Update interval, hours", p.updateIntervalHours.toString()),
            DrawerItem("Update on app start", isChecked = p.updateOnAppStart, onToggle = { v -> p.updateOnAppStart = v; saveUpdatedPlaylist(p) }),
            DrawerItem("Update playlist") {
                thread {
                    runCatching {
                        val res = PlaylistParser.fetchAndParse(this, p)
                        p.channelCount = res.channels.size
                        storage.saveChannels(p.id, res.channels)
                        saveUpdatedPlaylist(p)
                    }
                    runOnUiThread { reloadAllData(); Toast.makeText(this, "Updated ${p.name}", Toast.LENGTH_SHORT).show() }
                }
            },
            DrawerItem("Delete playlist") {
                val all = storage.getPlaylists().filter { it.id != p.id }
                storage.savePlaylists(all)
                storage.deletePlaylistData(p.id)
                closeDrawer()
                reloadAllData()
            }
        )
        openDrawer(p.name, items)
    }

    private fun openManageGroupsDrawer(p: PlaylistConfig) {
        val groups = storage.loadChannels(p.id).map { it.groupTitle }.distinct()
        openDrawer(
            "Manage groups",
            groups.map { g ->
                val visible = !p.hiddenTvGroups.contains(g)
                DrawerItem(g, isChecked = visible, onToggle = { v ->
                    if (v) p.hiddenTvGroups.remove(g) else p.hiddenTvGroups.add(g)
                    saveUpdatedPlaylist(p)
                    reloadAllData()
                })
            }
        )
    }

    private fun openEpgSettings() {
        val s = storage.getSettings()
        openDrawer(
            "EPG",
            listOf(
                DrawerItem("EPG sources", "${storage.getEpgSources().size} sources"),
                DrawerItem("Past days to keep EPG", s.pastDaysToKeepEpg.toString()),
                DrawerItem("Store program descriptions", isChecked = s.storeProgramDescriptions, onToggle = { s.storeProgramDescriptions = it; storage.saveSettings(s) }),
                DrawerItem("Update interval, hours", s.epgUpdateIntervalHours.toString()),
                DrawerItem("Update on app start", isChecked = s.epgUpdateOnAppStart, onToggle = { s.epgUpdateOnAppStart = it; storage.saveSettings(s) }),
                DrawerItem("Update on playlists change", isChecked = s.epgUpdateOnPlaylistChange, onToggle = { s.epgUpdateOnPlaylistChange = it; storage.saveSettings(s) }),
                DrawerItem("Update EPG") {
                    thread {
                        val combined = storage.loadEpgMap()
                        storage.getEpgSources().forEach { src ->
                            runCatching { combined.putAll(EpgParser.fetchAndParse(src.url, s.pastDaysToKeepEpg)) }
                        }
                        storage.saveEpgMap(combined)
                        runOnUiThread { reloadAllData(); Toast.makeText(this, "EPG updated", Toast.LENGTH_SHORT).show() }
                    }
                },
                DrawerItem("Clear EPG") { storage.clearEpg(); reloadAllData() },
                DrawerItem("Latest update status", s.latestEpgStatus)
            )
        )
    }

    private fun openAppearanceSettings() {
        val s = storage.getSettings()
        openDrawer(
            "Appearance",
            listOf(
                DrawerItem("TV guide") {
                    openDrawer(
                        "TV guide",
                        listOf(
                            DrawerItem("Show channel numbers", isChecked = s.showChannelNumbers, onToggle = { s.showChannelNumbers = it; storage.saveSettings(s) }),
                            DrawerItem("Show channel names", isChecked = s.showChannelNames, onToggle = { s.showChannelNames = it; storage.saveSettings(s) }),
                            DrawerItem("Two-line channel names", isChecked = s.twoLineChannelNames, onToggle = { s.twoLineChannelNames = it; storage.saveSettings(s) }),
                            DrawerItem("Highlight current programs", isChecked = s.highlightCurrentPrograms, onToggle = { s.highlightCurrentPrograms = it; storage.saveSettings(s) })
                        )
                    )
                },
                DrawerItem("Player") {
                    openDrawer(
                        "Player",
                        listOf(
                            DrawerItem("Show info panel on switch", isChecked = s.showInfoPanelOnSwitch, onToggle = { s.showInfoPanelOnSwitch = it; storage.saveSettings(s) }),
                            DrawerItem("Show clock", isChecked = s.showClock, onToggle = { s.showClock = it; storage.saveSettings(s) }),
                            DrawerItem("Show \"TV guide\" button", isChecked = s.showTvGuideButton, onToggle = { s.showTvGuideButton = it; storage.saveSettings(s) }),
                            DrawerItem("Show \"History\" button", isChecked = s.showHistoryButton, onToggle = { s.showHistoryButton = it; storage.saveSettings(s) }),
                            DrawerItem("Panels timeout, sec", s.panelsTimeoutSec.toString())
                        )
                    )
                },
                DrawerItem("Groups") {
                    openDrawer(
                        "Groups",
                        listOf(
                            DrawerItem("Show \"All playlists\" category", isChecked = s.showAllPlaylistsCategory, onToggle = { s.showAllPlaylistsCategory = it; storage.saveSettings(s); buildGroupsSidebar() }),
                            DrawerItem("Show \"Favorites\" category", isChecked = s.showFavoritesCategory, onToggle = { s.showFavoritesCategory = it; storage.saveSettings(s); buildGroupsSidebar() }),
                            DrawerItem("Show \"All channels\" category", isChecked = s.showAllChannelsCategory, onToggle = { s.showAllChannelsCategory = it; storage.saveSettings(s); buildGroupsSidebar() })
                        )
                    )
                },
                DrawerItem("Logos", s.logosPriority),
                DrawerItem("Language", s.language),
                DrawerItem("Font size", s.fontSize),
                DrawerItem("Color theme", "${s.backgroundColorName} • ${s.accentColorName}"),
                DrawerItem("User interface transparency, %", s.uiTransparencyPct.toString())
            )
        )
    }

    private fun openPlaybackSettings() {
        val s = storage.getSettings()
        openDrawer(
            "Playback",
            listOf(
                DrawerItem("Buffer size", s.bufferSize) {
                    val opts = arrayOf("None", "Small", "Medium", "Large", "Very large")
                    AlertDialog.Builder(this).setTitle("Buffer size").setItems(opts) { _, w ->
                        s.bufferSize = opts[w]; storage.saveSettings(s); openPlaybackSettings()
                    }.show()
                },
                DrawerItem("Audio decoder", s.audioDecoder) {
                    s.audioDecoder = if (s.audioDecoder == "Hardware") "Software" else "Hardware"
                    storage.saveSettings(s); openPlaybackSettings()
                },
                DrawerItem("Video decoder", s.videoDecoder) {
                    s.videoDecoder = if (s.videoDecoder == "Hardware") "Software" else "Hardware"
                    storage.saveSettings(s); openPlaybackSettings()
                },
                DrawerItem("Auto frame rate (AFR)", if (s.autoFrameRate) "On" else "Off", isChecked = s.autoFrameRate, onToggle = { s.autoFrameRate = it; storage.saveSettings(s) }),
                DrawerItem("Select surround audio track by default", isChecked = s.surroundAudioByDefault, onToggle = { s.surroundAudioByDefault = it; storage.saveSettings(s) }),
                DrawerItem("Audio passthrough", isChecked = s.audioPassthrough, onToggle = { s.audioPassthrough = it; storage.saveSettings(s) }),
                DrawerItem("Use external player", if (s.useExternalPlayer) "Yes" else "No", isChecked = s.useExternalPlayer, onToggle = { s.useExternalPlayer = it; storage.saveSettings(s) })
            )
        )
    }

    private fun openRemoteSettings() {
        openDrawer(
            "Remote control",
            listOf(
                DrawerItem("TV guide", "DPAD_CENTER: Play, LONG_PRESS: Menu"),
                DrawerItem("Player", "DPAD_UP/DOWN: Switch channel, CENTER: OSD")
            )
        )
    }

    private fun openParentalSettings() {
        val s = storage.getSettings()
        openDrawer(
            "Parental controls",
            listOf(
                DrawerItem("Change PIN", if (s.parentalPin.isEmpty()) "Not set" else "••••"),
                DrawerItem("Require PIN for Settings", isChecked = s.requirePinForSettings, onToggle = { s.requirePinForSettings = it; storage.saveSettings(s) })
            )
        )
    }

    private fun openOtherSettings() {
        val s = storage.getSettings()
        openDrawer(
            "Other",
            listOf(
                DrawerItem("Reminders", "Remind before: ${s.remindBeforeMin} min"),
                DrawerItem("Recording", s.recordingsFolder),
                DrawerItem("VOD", "Autoplay next episode: ${if (s.vodAutoplayNextEpisode) "On" else "Off"}", isChecked = s.vodAutoplayNextEpisode, onToggle = { s.vodAutoplayNextEpisode = it; storage.saveSettings(s) })
            )
        )
    }

    private fun saveUpdatedPlaylist(p: PlaylistConfig) {
        val all = storage.getPlaylists().map { if (it.id == p.id) p else it }
        storage.savePlaylists(all)
    }

    private fun openDrawer(title: String, items: List<DrawerItem>) {
        drawerTitle.text = title
        drawerRecycler.adapter = DrawerAdapter(items)
        drawerBackdrop.visibility = View.VISIBLE
        drawerRecycler.requestFocus()
    }

    private fun closeDrawer() {
        drawerBackdrop.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (drawerBackdrop.visibility == View.VISIBLE) {
                closeDrawer()
                return true
            }
            if (groupsSidebar.visibility == View.VISIBLE) {
                groupsSidebar.visibility = View.GONE
                return true
            }
            if (storage.getSettings().confirmExitBack) {
                val now = System.currentTimeMillis()
                if (now - lastBackMs > 2000) {
                    lastBackMs = now
                    Toast.makeText(this, "Press Back again to exit", Toast.LENGTH_SHORT).show()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        previewPlayer?.release()
    }

    inner class DrawerAdapter(private val items: List<DrawerItem>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_drawer_row, parent, false)
            return object : RecyclerView.ViewHolder(v) {}
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val item = items[position]
            val v = holder.itemView
            val tvTitle = v.findViewById<TextView>(R.id.drawerRowTitle)
            val tvSub = v.findViewById<TextView>(R.id.drawerRowSubtitle)
            val tvSec = v.findViewById<TextView>(R.id.drawerRowSection)
            val ivIcon = v.findViewById<ImageView>(R.id.drawerRowIcon)
            val sw = v.findViewById<Switch>(R.id.drawerRowSwitch)

            tvTitle.text = item.title
            if (!item.subtitle.isNullOrEmpty()) {
                tvSub.text = item.subtitle
                tvSub.visibility = View.VISIBLE
            } else {
                tvSub.visibility = View.GONE
            }
            if (!item.section.isNullOrEmpty()) {
                tvSec.text = item.section
                tvSec.visibility = View.VISIBLE
            } else {
                tvSec.visibility = View.GONE
            }
            if (item.iconRes != null) {
                ivIcon.setImageResource(item.iconRes)
                ivIcon.visibility = View.VISIBLE
            } else {
                ivIcon.visibility = View.GONE
            }
            if (item.isChecked != null) {
                sw.visibility = View.VISIBLE
                sw.isChecked = item.isChecked
            } else {
                sw.visibility = View.GONE
            }

            v.setOnFocusChangeListener { _, hasFocus ->
                tvTitle.setTextColor(getColor(if (hasFocus) R.color.tivi_text_dark else R.color.tivi_text_primary))
                tvSub.setTextColor(getColor(if (hasFocus) R.color.tivi_text_dark else R.color.tivi_text_muted))
            }
            v.setOnClickListener {
                if (item.isChecked != null && item.onToggle != null) {
                    val next = !sw.isChecked
                    sw.isChecked = next
                    item.onToggle.invoke(next)
                } else {
                    item.onClick?.invoke()
                }
            }
        }
    }
}
