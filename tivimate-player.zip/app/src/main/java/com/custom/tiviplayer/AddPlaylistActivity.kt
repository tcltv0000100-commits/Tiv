package com.custom.tiviplayer

import android.Manifest
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.custom.tiviplayer.data.AppStorage
import com.custom.tiviplayer.data.EpgParser
import com.custom.tiviplayer.data.PlaylistParser
import com.custom.tiviplayer.model.EpgSourceConfig
import com.custom.tiviplayer.model.PlaylistConfig
import com.custom.tiviplayer.model.PlaylistType
import java.io.File
import java.util.UUID
import kotlin.concurrent.thread

class AddPlaylistActivity : AppCompatActivity() {

    private lateinit var storage: AppStorage
    private lateinit var wizIcon: ImageView
    private lateinit var wizTitle: TextView
    private lateinit var wizSubtitle: TextView
    private lateinit var wizStatus: TextView
    private lateinit var wizMid: LinearLayout
    private lateinit var wizRight: LinearLayout

    private var selectedType = PlaylistType.M3U
    private var m3uUrl = ""
    private var m3uLocalUri = ""
    private var playlistName = ""
    private var isVodOnly = false
    private var epgUrl = ""

    // Xtream / Stalker fields
    private var serverAddress = ""
    private var username = ""
    private var password = ""
    private var macAddress = "00:1A:79:AB:6D:F4"
    private var deviceId = ""
    private var deviceId2 = ""
    private var serialNumber = ""
    private var includeTv = true
    private var includeVod = true

    private var parsedChannelsCount = 0
    private var parsedMoviesCount = 0
    private var parsedShowsCount = 0
    private var detectedEpg = ""
    private var expirationDate = ""
    private var pendingConfig: PlaylistConfig? = null

    private var currentDir: File = Environment.getExternalStorageDirectory()

    private val systemFilePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            m3uLocalUri = uri.toString()
            m3uUrl = ""
            playlistName = uri.lastPathSegment?.substringAfterLast('/') ?: "Local playlist"
            startProcessingPlaylist()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_playlist)
        storage = AppStorage(this)

        wizIcon = findViewById(R.id.wizIcon)
        wizTitle = findViewById(R.id.wizTitle)
        wizSubtitle = findViewById(R.id.wizSubtitle)
        wizStatus = findViewById(R.id.wizStatus)
        wizMid = findViewById(R.id.wizMidContainer)
        wizRight = findViewById(R.id.wizRightContainer)

        showPlaylistTypeStep()
    }

    private fun addOptionRow(
        parent: LinearLayout,
        title: String,
        subtitle: String? = null,
        iconRes: Int? = null,
        showArrow: Boolean = false,
        onClick: () -> Unit
    ): View {
        val v = LayoutInflater.from(this).inflate(R.layout.item_wizard_option, parent, false)
        val tvTitle = v.findViewById<TextView>(R.id.optTitle)
        val tvSub = v.findViewById<TextView>(R.id.optSubtitle)
        val ivIcon = v.findViewById<ImageView>(R.id.optIcon)
        val tvArrow = v.findViewById<TextView>(R.id.optArrow)

        tvTitle.text = title
        if (!subtitle.isNullOrEmpty()) {
            tvSub.text = subtitle
            tvSub.visibility = View.VISIBLE
        }
        if (iconRes != null) {
            ivIcon.setImageResource(iconRes)
            ivIcon.visibility = View.VISIBLE
        }
        if (showArrow) tvArrow.visibility = View.VISIBLE

        v.setOnFocusChangeListener { _, hasFocus ->
            tvTitle.setTextColor(getColor(if (hasFocus) R.color.tivi_text_dark else R.color.tivi_text_primary))
            tvSub.setTextColor(getColor(if (hasFocus) R.color.tivi_text_dark else R.color.tivi_text_muted))
            tvArrow.setTextColor(getColor(if (hasFocus) R.color.tivi_text_dark else R.color.tivi_text_secondary))
        }
        v.setOnClickListener { onClick() }
        parent.addView(v)
        return v
    }

    private fun showPlaylistTypeStep() {
        wizIcon.setImageResource(R.drawable.ic_playlist_add)
        wizTitle.text = "Playlist type"
        wizSubtitle.visibility = View.GONE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val first = addOptionRow(wizMid, "M3U playlist") {
            selectedType = PlaylistType.M3U
            showM3uStep()
        }
        addOptionRow(wizMid, "Xtream Codes") {
            selectedType = PlaylistType.XTREAM
            showXtreamStep()
        }
        addOptionRow(wizMid, "Stalker Portal") {
            selectedType = PlaylistType.STALKER
            showStalkerStep()
        }

        addOptionRow(wizRight, "Cancel") { finish() }
        first.requestFocus()
    }

    private fun showM3uStep() {
        wizIcon.setImageResource(R.drawable.ic_link)
        wizTitle.text = "M3U playlist"
        wizSubtitle.visibility = View.GONE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val first = addOptionRow(wizMid, "Enter URL", m3uUrl.ifEmpty { null }) {
            promptTextInput("Enter M3U URL", m3uUrl, "https://example.com/playlist.m3u8") { txt ->
                m3uUrl = txt.trim()
                m3uLocalUri = ""
                playlistName = runCatching { Uri.parse(m3uUrl).host ?: "M3U playlist" }.getOrDefault("M3U playlist")
                showM3uStep()
            }
        }
        addOptionRow(wizMid, "Paste from clipboard") {
            val clip = getClipboardText()
            if (clip.isNotEmpty()) {
                m3uUrl = clip.trim()
                m3uLocalUri = ""
                playlistName = runCatching { Uri.parse(m3uUrl).host ?: "M3U playlist" }.getOrDefault("M3U playlist")
                Toast.makeText(this, "Pasted: $m3uUrl", Toast.LENGTH_SHORT).show()
                showM3uStep()
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }
        addOptionRow(wizMid, "Select local playlist", m3uLocalUri.ifEmpty { null }) {
            checkStoragePermissionAndBrowse()
        }

        addOptionRow(wizRight, "Next", showArrow = true) {
            if (m3uUrl.isEmpty() && m3uLocalUri.isEmpty()) {
                Toast.makeText(this, "Enter URL or select a local playlist", Toast.LENGTH_SHORT).show()
            } else {
                startProcessingPlaylist()
            }
        }
        addOptionRow(wizRight, "Back") { showPlaylistTypeStep() }
        first.requestFocus()
    }

    private fun checkStoragePermissionAndBrowse() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            AlertDialog.Builder(this)
                .setTitle("M3U playlist")
                .setMessage("For the app to open local playlists, please allow \"All files access\" in Settings.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Settings") { _, _ ->
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                }
                .show()
            return
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            val perm = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            if (perm != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 101)
                return
            }
        }
        currentDir = Environment.getExternalStorageDirectory()
        showLocalStorageBrowser()
    }

    private fun showLocalStorageBrowser() {
        wizIcon.setImageResource(R.drawable.ic_folder)
        wizTitle.text = "Internal shared storage"
        wizSubtitle.text = "Select a local playlist (*.m3u or *.m3u8 file)"
        wizSubtitle.visibility = View.VISIBLE
        wizStatus.text = "The file system access can be restricted. Try to use the system picker."
        wizStatus.visibility = View.VISIBLE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val parent = currentDir.parentFile
        if (parent != null && currentDir.absolutePath != Environment.getExternalStorageDirectory().absolutePath) {
            addOptionRow(wizMid, "..", "Parent folder", R.drawable.ic_folder) {
                currentDir = parent
                showLocalStorageBrowser()
            }
        }

        val items = currentDir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
        items.forEach { file ->
            if (file.isDirectory && !file.name.startsWith(".")) {
                addOptionRow(wizMid, file.name, null, R.drawable.ic_folder) {
                    currentDir = file
                    showLocalStorageBrowser()
                }
            } else if (file.isFile && (file.name.endsWith(".m3u", true) || file.name.endsWith(".m3u8", true))) {
                addOptionRow(wizMid, file.name, "${file.length() / 1024} KB", R.drawable.ic_playlist_add) {
                    m3uLocalUri = file.absolutePath
                    m3uUrl = ""
                    playlistName = file.nameWithoutExtension
                    startProcessingPlaylist()
                }
            }
        }

        addOptionRow(wizRight, "System picker") {
            systemFilePicker.launch(arrayOf("*/*"))
        }
        addOptionRow(wizRight, "Setup SMB") {
            promptTextInput("SMB / Network M3U Path", "", "http://192.168.1.10/playlist.m3u") { url ->
                m3uUrl = url.trim()
                m3uLocalUri = ""
                playlistName = "SMB Playlist"
                startProcessingPlaylist()
            }
        }
        addOptionRow(wizRight, "Cancel") { showM3uStep() }
    }

    private fun showXtreamStep() {
        wizIcon.setImageResource(R.drawable.ic_portal)
        wizTitle.text = "Xtream Codes"
        wizSubtitle.visibility = View.GONE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val first = addOptionRow(wizMid, "Server address", serverAddress.ifEmpty { null }) {
            promptTextInput("Server address", serverAddress, "http://example.com:8080") { txt ->
                serverAddress = txt.trim()
                if (playlistName.isEmpty()) {
                    playlistName = serverAddress.removePrefix("http://").removePrefix("https://").substringBefore("/")
                }
                showXtreamStep()
            }
        }
        addOptionRow(wizMid, "Username", username.ifEmpty { null }) {
            promptTextInput("Username", username, "Username") { txt ->
                username = txt.trim()
                showXtreamStep()
            }
        }
        addOptionRow(wizMid, "Password", if (password.isNotEmpty()) "••••••••" else null) {
            promptTextInput("Password", password, "Password") { txt ->
                password = txt.trim()
                showXtreamStep()
            }
        }

        val cbTv = CheckBox(this).apply {
            text = "Include TV channels"
            isChecked = includeTv
            setTextColor(getColor(R.color.tivi_text_primary))
            setPadding(8, 14, 8, 8)
            setOnCheckedChangeListener { _, checked -> includeTv = checked }
        }
        val cbVod = CheckBox(this).apply {
            text = "Include VOD"
            isChecked = includeVod
            setTextColor(getColor(R.color.tivi_text_primary))
            setPadding(8, 8, 8, 14)
            setOnCheckedChangeListener { _, checked -> includeVod = checked }
        }
        wizMid.addView(cbTv)
        wizMid.addView(cbVod)

        addOptionRow(wizRight, "Next", showArrow = true) {
            if (serverAddress.isEmpty() || username.isEmpty()) {
                Toast.makeText(this, "Enter Server address and Username", Toast.LENGTH_SHORT).show()
            } else {
                startProcessingPlaylist()
            }
        }
        addOptionRow(wizRight, "Back") { showPlaylistTypeStep() }
        first.requestFocus()
    }

    private fun autoGenStalkerIdsFromMac(mac: String) {
        val macUpper = mac.trim().uppercase()
        val md5Bytes = java.security.MessageDigest.getInstance("MD5").digest(macUpper.toByteArray())
        val md5Hex = md5Bytes.joinToString("") { "%02x".format(it) }
        serialNumber = md5Hex.substring(0, 13).uppercase()

        val shaBytes = java.security.MessageDigest.getInstance("SHA-256").digest(macUpper.toByteArray())
        val shaHex = shaBytes.joinToString("") { "%02X".format(it) }
        deviceId = shaHex
        deviceId2 = shaHex
    }

    private fun showStalkerStep() {
        wizIcon.setImageResource(R.drawable.ic_portal)
        wizTitle.text = "Stalker Portal"
        wizSubtitle.visibility = View.GONE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val first = addOptionRow(wizMid, "Server address", serverAddress.ifEmpty { null }) {
            promptTextInput("Server address", serverAddress, "http://portal.example.com/stalker_portal") { txt ->
                serverAddress = txt.trim()
                if (playlistName.isEmpty()) {
                    playlistName = serverAddress.removePrefix("http://").removePrefix("https://").substringBefore("/")
                }
                showStalkerStep()
            }
        }
        if (deviceId.isEmpty() || serialNumber.isEmpty()) {
            autoGenStalkerIdsFromMac(macAddress)
        }
        addOptionRow(wizMid, "MAC address", macAddress) {
            promptTextInput("MAC address", macAddress, "00:1A:79:AB:6D:F4") { txt ->
                macAddress = txt.trim()
                autoGenStalkerIdsFromMac(macAddress)
                showStalkerStep()
            }
        }
        addOptionRow(wizMid, "Username (optional)", username.ifEmpty { null }) {
            promptTextInput("Username (optional)", username, "") { txt -> username = txt.trim(); showStalkerStep() }
        }
        addOptionRow(wizMid, "Password (optional)", if (password.isNotEmpty()) "••••" else null) {
            promptTextInput("Password (optional)", password, "") { txt -> password = txt.trim(); showStalkerStep() }
        }
        addOptionRow(wizMid, "Device ID (optional)", deviceId.ifEmpty { null }) {
            promptTextInput("Device ID (optional)", deviceId, "") { txt ->
                deviceId = txt.trim()
                deviceId2 = deviceId
                showStalkerStep()
            }
        }
        addOptionRow(wizMid, "Device ID 2 (optional)", deviceId2.ifEmpty { null }) {
            promptTextInput("Device ID 2 (optional)", deviceId2, "") { txt -> deviceId2 = txt.trim(); showStalkerStep() }
        }
        addOptionRow(wizMid, "Serial number (optional)", serialNumber.ifEmpty { null }) {
            promptTextInput("Serial number (optional)", serialNumber, "") { txt -> serialNumber = txt.trim(); showStalkerStep() }
        }

        val cbTv = CheckBox(this).apply {
            text = "Include TV channels"
            isChecked = includeTv
            setTextColor(getColor(R.color.tivi_text_primary))
            setOnCheckedChangeListener { _, checked -> includeTv = checked }
        }
        val cbVod = CheckBox(this).apply {
            text = "Include VOD"
            isChecked = includeVod
            setTextColor(getColor(R.color.tivi_text_primary))
            setOnCheckedChangeListener { _, checked -> includeVod = checked }
        }
        wizMid.addView(cbTv)
        wizMid.addView(cbVod)

        addOptionRow(wizRight, "Next", showArrow = true) {
            if (serverAddress.isEmpty() || macAddress.isEmpty()) {
                Toast.makeText(this, "Enter Server address and MAC address", Toast.LENGTH_SHORT).show()
            } else {
                startProcessingPlaylist()
            }
        }
        addOptionRow(wizRight, "Back") { showPlaylistTypeStep() }
        first.requestFocus()
    }

    private fun startProcessingPlaylist() {
        wizIcon.setImageResource(R.drawable.ic_download)
        wizTitle.text = "Processing..."
        wizSubtitle.visibility = View.GONE
        wizStatus.text = "Please wait..."
        wizStatus.visibility = View.VISIBLE
        wizMid.removeAllViews()
        wizRight.removeAllViews()

        val id = UUID.randomUUID().toString().take(8)
        val defaultName = when {
            playlistName.isNotEmpty() -> playlistName
            selectedType == PlaylistType.M3U -> "TV playlist"
            else -> serverAddress.removePrefix("http://").removePrefix("https://").substringBefore("/")
        }
        val config = PlaylistConfig(
            id = id,
            name = defaultName,
            type = selectedType,
            url = if (selectedType == PlaylistType.M3U) m3uUrl else serverAddress,
            localUri = m3uLocalUri,
            username = username,
            password = password,
            macAddress = macAddress,
            deviceId = deviceId,
            deviceId2 = deviceId2,
            serialNumber = serialNumber,
            includeTv = includeTv,
            includeVod = includeVod,
            isVodOnly = isVodOnly,
            catchUpType = if (selectedType == PlaylistType.XTREAM) "Xtream Codes" else "Default"
        )

        thread {
            try {
                val res = PlaylistParser.fetchAndParse(this, config)
                config.channelCount = res.channels.size
                config.movieCount = res.movies.size
                config.showCount = res.shows.size
                config.epgUrl = res.detectedEpgUrl
                config.expirationDate = res.expirationDate

                storage.saveChannels(config.id, res.channels)
                storage.saveMovies(config.id, res.movies)
                storage.saveShows(config.id, res.shows)

                parsedChannelsCount = res.channels.size
                parsedMoviesCount = res.movies.size
                parsedShowsCount = res.shows.size
                detectedEpg = res.detectedEpgUrl
                expirationDate = res.expirationDate
                pendingConfig = config

                runOnUiThread { showProcessedStep() }
            } catch (e: Exception) {
                runOnUiThread {
                    wizTitle.text = "Error processing playlist"
                    wizStatus.text = e.message ?: "Connection failed"
                    addOptionRow(wizRight, "Back") {
                        when (selectedType) {
                            PlaylistType.M3U -> showM3uStep()
                            PlaylistType.XTREAM -> showXtreamStep()
                            PlaylistType.STALKER -> showStalkerStep()
                        }
                    }
                }
            }
        }
    }

    private fun showProcessedStep() {
        val cfg = pendingConfig ?: return
        wizIcon.setImageResource(R.drawable.ic_download)
        wizTitle.text = "Playlist is processed"
        val counts = buildString {
            append("Channels: $parsedChannelsCount")
            if (parsedMoviesCount > 0) append("\nMovies: $parsedMoviesCount")
            if (parsedShowsCount > 0) append("\nShows: $parsedShowsCount")
        }
        wizSubtitle.text = counts
        wizSubtitle.visibility = View.VISIBLE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        addOptionRow(wizMid, "Playlist name", cfg.name) {
            promptTextInput("Playlist name", cfg.name, "My Playlist") { txt ->
                if (txt.isNotBlank()) {
                    cfg.name = txt.trim()
                    showProcessedStep()
                }
            }
        }

        if (selectedType == PlaylistType.M3U) {
            val rg = RadioGroup(this).apply { setPadding(8, 12, 8, 8) }
            val rbTv = RadioButton(this).apply {
                text = "TV playlist"
                isChecked = !cfg.isVodOnly
                setTextColor(getColor(R.color.tivi_text_primary))
            }
            val rbVod = RadioButton(this).apply {
                text = "VOD playlist (no TV channels)"
                isChecked = cfg.isVodOnly
                setTextColor(getColor(R.color.tivi_text_primary))
            }
            rg.addView(rbTv)
            rg.addView(rbVod)
            rg.setOnCheckedChangeListener { _, checkedId ->
                cfg.isVodOnly = (checkedId == rbVod.id)
            }
            wizMid.addView(rg)

            addOptionRow(wizRight, "Next", showArrow = true) { showEpgUrlStep() }
            addOptionRow(wizRight, "Back") { showM3uStep() }
        } else {
            addOptionRow(wizRight, "Done") { saveAndFinish(cfg) }
            addOptionRow(wizRight, "Back") {
                if (selectedType == PlaylistType.XTREAM) showXtreamStep() else showStalkerStep()
            }
        }
    }

    private fun showEpgUrlStep() {
        val cfg = pendingConfig ?: return
        wizIcon.setImageResource(R.drawable.ic_link)
        wizTitle.text = "EPG URL"
        wizSubtitle.text = "Enter EPG URL for the playlist. You can change it later in the settings. XMLTV only supported."
        wizSubtitle.visibility = View.VISIBLE
        wizStatus.visibility = View.GONE

        wizMid.removeAllViews()
        wizRight.removeAllViews()

        addOptionRow(wizMid, "Enter URL", epgUrl.ifEmpty { detectedEpg.ifEmpty { null } }) {
            promptTextInput("EPG URL (XMLTV)", epgUrl.ifEmpty { detectedEpg }, "https://example.com/epg.xml") { txt ->
                epgUrl = txt.trim()
                cfg.epgUrl = epgUrl
                showEpgUrlStep()
            }
        }
        addOptionRow(wizMid, "Paste from clipboard") {
            val clip = getClipboardText()
            if (clip.isNotEmpty()) {
                epgUrl = clip.trim()
                cfg.epgUrl = epgUrl
                showEpgUrlStep()
            }
        }
        addOptionRow(wizMid, "Paste playlist URL", "You can edit playlist URL if it has the similar format") {
            epgUrl = cfg.url
            cfg.epgUrl = epgUrl
            showEpgUrlStep()
        }
        addOptionRow(wizMid, "Use default source") {
            epgUrl = detectedEpg
            cfg.epgUrl = epgUrl
            saveAndFinish(cfg)
        }

        addOptionRow(wizRight, "Done") { saveAndFinish(cfg) }
        addOptionRow(wizRight, "Back") { showProcessedStep() }
    }

    private fun saveAndFinish(cfg: PlaylistConfig) {
        val all = storage.getPlaylists()
        all.add(cfg)
        storage.savePlaylists(all)

        if (cfg.epgUrl.isNotEmpty()) {
            val sources = storage.getEpgSources()
            sources.add(EpgSourceConfig(UUID.randomUUID().toString().take(8), cfg.name, cfg.epgUrl, isDefault = sources.isEmpty()))
            storage.saveEpgSources(sources)
            thread {
                runCatching {
                    val map = EpgParser.fetchAndParse(cfg.epgUrl, storage.getSettings().pastDaysToKeepEpg)
                    val existing = storage.loadEpgMap()
                    existing.putAll(map)
                    storage.saveEpgMap(existing)
                }
            }
        }
        setResult(RESULT_OK)
        finish()
    }

    private fun promptTextInput(title: String, initial: String, hint: String, onDone: (String) -> Unit) {
        val overlay = findViewById<LinearLayout>(R.id.wizInputOverlay)
        val label = findViewById<TextView>(R.id.wizInputLabel)
        val edit = findViewById<EditText>(R.id.wizInputEdit)
        val nextBtn = findViewById<Button>(R.id.wizInputNextBtn)

        label.text = title
        edit.hint = hint
        edit.setText(initial)
        edit.setSelection(edit.text.length)
        overlay.visibility = View.VISIBLE
        edit.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        edit.postDelayed({
            edit.requestFocus()
            imm.showSoftInput(edit, android.view.inputmethod.InputMethodManager.SHOW_FORCED)
        }, 120)

        val finishInput = {
            imm.hideSoftInputFromWindow(edit.windowToken, 0)
            overlay.visibility = View.GONE
            onDone(edit.text.toString())
        }
        nextBtn.setOnClickListener { finishInput() }
        edit.setOnEditorActionListener { _, _, _ -> finishInput(); true }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val overlay = findViewById<LinearLayout>(R.id.wizInputOverlay)
        if (overlay.visibility == View.VISIBLE) {
            overlay.visibility = View.GONE
            return
        }
        super.onBackPressed()
    }

    private fun getClipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
    }
}
