package com.custom.tiviplayer.model

enum class PlaylistType { M3U, XTREAM, STALKER }

data class PlaylistConfig(
    val id: String,
    var name: String,
    val type: PlaylistType,
    var url: String = "",
    var localUri: String = "",
    var username: String = "",
    var password: String = "",
    var macAddress: String = "00:1A:79:AB:6D:F4",
    var deviceId: String = "",
    var deviceId2: String = "",
    var serialNumber: String = "",
    var outputFormat: String = "MPEG-TS",
    var includeTv: Boolean = true,
    var includeVod: Boolean = true,
    var isVodOnly: Boolean = false,
    var epgUrl: String = "",
    var userAgent: String = "",
    var logosPriority: String = "Prefer logos from playlist",
    var catchUpType: String = "Xtream Codes",
    var enabled: Boolean = true,
    var updateIntervalHours: Int = 24,
    var updateOnAppStart: Boolean = false,
    var channelCount: Int = 0,
    var movieCount: Int = 0,
    var showCount: Int = 0,
    var expirationDate: String = "",
    val hiddenTvGroups: MutableSet<String> = mutableSetOf(),
    val hiddenMovieGroups: MutableSet<String> = mutableSetOf(),
    val hiddenShowGroups: MutableSet<String> = mutableSetOf(),
    val blockedChannels: MutableSet<String> = mutableSetOf(),
    val hiddenChannels: MutableSet<String> = mutableSetOf()
)

data class ChannelItem(
    val id: String,
    val playlistId: String,
    var number: Int,
    var name: String,
    val originalName: String,
    val streamUrl: String,
    val logoUrl: String = "",
    var groupTitle: String = "Uncategorized",
    var tvgId: String = "",
    val hasCatchUp: Boolean = false,
    var audioDecoder: String = "Hardware",
    var videoDecoder: String = "Hardware",
    var useExternalPlayer: Boolean = false,
    var epgOffsetMin: Int = 0,
    val stalkerCmd: String = ""
)

data class EpgProgram(
    val channelId: String,
    val title: String,
    val description: String = "",
    val startMs: Long,
    val endMs: Long
)

data class VodMovie(
    val id: String,
    val playlistId: String,
    val title: String,
    val groupTitle: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val streamUrl: String = "",
    val rating: String = "",
    val year: String = "",
    val duration: String = "",
    val genres: String = "",
    val cast: String = "",
    val director: String = "",
    val description: String = ""
)

data class VodEpisode(
    val id: String,
    val season: Int,
    val episodeNum: Int,
    val title: String,
    val streamUrl: String,
    val thumbUrl: String = "",
    val duration: String = ""
)

data class VodShow(
    val id: String,
    val playlistId: String,
    val title: String,
    val groupTitle: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val rating: String = "",
    val year: String = "",
    val genres: String = "",
    val description: String = "",
    val episodes: MutableList<VodEpisode> = mutableListOf()
)

data class EpgSourceConfig(
    val id: String,
    var name: String,
    var url: String,
    var offsetMin: Int = 0,
    var isDefault: Boolean = false
)

data class RecordingEntry(
    val id: String,
    val title: String,
    val channelName: String,
    val startMs: Long,
    val filePath: String = ""
)

data class AppSettings(
    // General
    var autoStartBoot: Boolean = false,
    var autoStartWake: Boolean = false,
    var turnOnLastChannel: Boolean = false,
    var pipOnHome: Boolean = false,
    var confirmExitBack: Boolean = false,
    var globalUserAgent: String = "",
    var udpProxy: String = "",
    // EPG
    var pastDaysToKeepEpg: Int = 7,
    var storeProgramDescriptions: Boolean = true,
    var epgUpdateIntervalHours: Int = 24,
    var epgUpdateOnAppStart: Boolean = false,
    var epgUpdateOnPlaylistChange: Boolean = true,
    var latestEpgStatus: String = "Not updated yet",
    // Appearance - TV guide
    var channelsSorting: String = "By order in playlist",
    var showChannelNumbers: Boolean = true,
    var showChannelNames: Boolean = true,
    var twoLineChannelNames: Boolean = false,
    var showCatchUpIcon: Boolean = true,
    var highlightCurrentChannel: Boolean = true,
    var twoLineProgramTitles: Boolean = false,
    var highlightCurrentPrograms: Boolean = true,
    var highlightProgressOnly: Boolean = false,
    var fullHeightTimeIndicator: Boolean = true,
    var animatedChannelsScrolling: Boolean = true,
    // Appearance - Player
    var showInfoPanelOnSwitch: Boolean = true,
    var showClock: Boolean = true,
    var showDateOnClock: Boolean = true,
    var showPlaylistAndGroupName: Boolean = true,
    var showProgramDescription: Boolean = true,
    var showMediaProperties: Boolean = true,
    var showTvGuideButton: Boolean = true,
    var showHistoryButton: Boolean = true,
    var panelsTimeoutSec: Int = 5,
    var showBlackScreenOnSwitch: Boolean = false,
    // Appearance - Groups & Logos & Theme
    var groupsSorting: String = "By order in playlist",
    var showAllPlaylistsCategory: Boolean = true,
    var showFavoritesCategory: Boolean = true,
    var showAllChannelsCategory: Boolean = true,
    var logosPriority: String = "Prefer logos from playlist",
    var language: String = "System",
    var fontSize: String = "Medium",
    var backgroundColorName: String = "Dark",
    var accentColorName: String = "Blue",
    var selectionColorName: String = "White",
    var uiTransparencyPct: Int = 80,
    // Playback
    var bufferSize: String = "Small",
    var audioDecoder: String = "Hardware",
    var videoDecoder: String = "Hardware",
    var autoFrameRate: Boolean = false,
    var surroundAudioByDefault: Boolean = false,
    var audioPassthrough: Boolean = false,
    var useExternalPlayer: Boolean = false,
    var skipStepBarBackMin: Int = 1,
    var skipStepBarFwdMin: Int = 1,
    var skipStepRwSec: Int = 10,
    var skipStepFfSec: Int = 10,
    // Parental
    var parentalPin: String = "",
    var requirePinForSettings: Boolean = false,
    // Other
    var remindBeforeMin: Int = 0,
    var recordingsFolder: String = "/storage/emulated/0/Download/TiviMate/Recordings",
    var vodAutoplayNextEpisode: Boolean = true
)
