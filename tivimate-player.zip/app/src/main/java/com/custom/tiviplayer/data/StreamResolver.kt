package com.custom.tiviplayer.data

import com.custom.tiviplayer.model.ChannelItem
import com.custom.tiviplayer.model.PlaylistConfig
import com.custom.tiviplayer.model.PlaylistType
import okhttp3.Request

enum class StreamFormat { HLS, DASH, PROGRESSIVE }

data class ResolvedStream(
    val finalUrl: String,
    val format: StreamFormat,
    val userAgent: String,
    val cookie: String = "",
    val referer: String = ""
)

object StreamResolver {
    fun resolveChannel(
        config: PlaylistConfig?,
        ch: ChannelItem,
        globalUserAgent: String
    ): ResolvedStream {
        val defaultStalkerUa =
            "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        val ua = when {
            ch.userAgent.isNotEmpty() -> ch.userAgent
            config?.userAgent?.isNotEmpty() == true -> config.userAgent
            config?.type == PlaylistType.STALKER -> defaultStalkerUa
            globalUserAgent.isNotEmpty() -> globalUserAgent
            else -> "TiviMate/4.7.0"
        }
        val cookie = if (config?.type == PlaylistType.STALKER) {
            "mac=${config.macAddress.trim()}; stb_lang=en; timezone=UTC"
        } else ""

        var rawUrl = ch.streamUrl
        if (config?.type == PlaylistType.STALKER && ch.stalkerCmd.isNotEmpty()) {
            val resolved = PlaylistParser.resolveStalkerStreamUrl(config, ch.stalkerCmd)
            if (resolved.isNotEmpty()) rawUrl = resolved
        }

        return probeUrl(rawUrl, ua, cookie, ch.referer)
    }

    fun resolveVod(
        config: PlaylistConfig?,
        rawUrl: String,
        globalUserAgent: String,
        isStalkerCmd: Boolean = false
    ): ResolvedStream {
        val defaultStalkerUa =
            "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        val ua = when {
            config?.userAgent?.isNotEmpty() == true -> config.userAgent
            config?.type == PlaylistType.STALKER -> defaultStalkerUa
            globalUserAgent.isNotEmpty() -> globalUserAgent
            else -> "TiviMate/4.7.0"
        }
        val cookie = if (config?.type == PlaylistType.STALKER) {
            "mac=${config.macAddress.trim()}; stb_lang=en; timezone=UTC"
        } else ""

        var url = rawUrl
        if (isStalkerCmd && config?.type == PlaylistType.STALKER) {
            val resolved = PlaylistParser.resolveStalkerStreamUrl(config, rawUrl, isVod = true)
            if (resolved.isNotEmpty()) url = resolved
        }
        return probeUrl(url, ua, cookie, "")
    }

    private fun probeUrl(url: String, ua: String, cookie: String, referer: String): ResolvedStream {
        if (url.contains(".m3u8", true)) {
            return ResolvedStream(url, StreamFormat.HLS, ua, cookie, referer)
        }
        if (url.contains(".mpd", true)) {
            return ResolvedStream(url, StreamFormat.DASH, ua, cookie, referer)
        }
        if (url.endsWith(".mp4", true) || url.endsWith(".mkv", true) || url.endsWith(".avi", true)) {
            return ResolvedStream(url, StreamFormat.PROGRESSIVE, ua, cookie, referer)
        }

        // Probe HTTP headers & first bytes to follow redirects and detect extensionless HLS/DASH/TS
        return runCatching {
            val req = Request.Builder().url(url)
                .header("User-Agent", ua)
                .header("Accept", "*/*")
                .header("Range", "bytes=0-1023")
                .apply {
                    if (cookie.isNotEmpty()) header("Cookie", cookie)
                    if (referer.isNotEmpty()) header("Referer", referer)
                }
                .build()
            PlaylistParser.httpClient.newCall(req).execute().use { resp ->
                val finalUrl = resp.request.url.toString()
                val ct = resp.header("Content-Type")?.lowercase() ?: ""
                val snippet = resp.body?.source()?.let { src ->
                    src.request(256)
                    src.buffer.clone().readUtf8(minOf(256L, src.buffer.size))
                } ?: ""

                val fmt = when {
                    finalUrl.contains(".m3u8", true) ||
                        ct.contains("mpegurl") ||
                        snippet.trimStart().startsWith("#EXTM3U") -> StreamFormat.HLS
                    finalUrl.contains(".mpd", true) ||
                        ct.contains("dash+xml") ||
                        snippet.contains("<MPD", true) -> StreamFormat.DASH
                    else -> StreamFormat.PROGRESSIVE
                }
                ResolvedStream(finalUrl, fmt, ua, cookie, referer)
            }
        }.getOrElse {
            ResolvedStream(url, StreamFormat.PROGRESSIVE, ua, cookie, referer)
        }
    }
}
