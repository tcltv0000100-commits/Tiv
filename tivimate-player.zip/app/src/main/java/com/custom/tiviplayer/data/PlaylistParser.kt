package com.custom.tiviplayer.data

import android.content.Context
import android.net.Uri
import com.custom.tiviplayer.model.*
import com.google.gson.Gson
import com.google.gson.JsonParser
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ParsedPlaylistResult(
    val channels: List<ChannelItem>,
    val movies: List<VodMovie>,
    val shows: List<VodShow>,
    val detectedEpgUrl: String = "",
    val expirationDate: String = ""
)

object PlaylistParser {
    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val gson = Gson()

    fun fetchAndParse(context: Context, config: PlaylistConfig): ParsedPlaylistResult {
        return when (config.type) {
            PlaylistType.M3U -> parseM3u(context, config)
            PlaylistType.XTREAM -> parseXtream(config)
            PlaylistType.STALKER -> parseStalker(config)
        }
    }

    private fun parseM3u(context: Context, config: PlaylistConfig): ParsedPlaylistResult {
        val reader: BufferedReader = when {
            config.localUri.isNotEmpty() -> {
                if (config.localUri.startsWith("content://")) {
                    val ins = context.contentResolver.openInputStream(Uri.parse(config.localUri))
                        ?: throw IllegalStateException("Cannot open local playlist")
                    BufferedReader(InputStreamReader(ins))
                } else {
                    File(config.localUri).bufferedReader()
                }
            }
            config.url.isNotEmpty() -> {
                val req = Request.Builder().url(config.url).apply {
                    if (config.userAgent.isNotEmpty()) header("User-Agent", config.userAgent)
                    else header("User-Agent", "TiviMate/4.7.0")
                }.build()
                val resp = httpClient.newCall(req).execute()
                if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                BufferedReader(InputStreamReader(resp.body!!.byteStream()))
            }
            else -> throw IllegalArgumentException("Empty M3U source")
        }

        val channels = mutableListOf<ChannelItem>()
        val movies = mutableListOf<VodMovie>()
        var detectedEpg = ""
        var num = 1

        var currentName = ""
        var currentLogo = ""
        var currentGroup = "Uncategorized"
        var currentTvgId = ""
        var currentCatchUp = false

        reader.use { br ->
            var line = br.readLine()
            while (line != null) {
                val trimmed = line.trim()
                if (trimmed.startsWith("#EXTM3U")) {
                    val epgMatch = Regex("""(?:url-tvg|x-tvg-url)="([^"]+)"""").find(trimmed)
                    if (epgMatch != null) detectedEpg = epgMatch.groupValues[1]
                } else if (trimmed.startsWith("#EXTINF")) {
                    currentLogo = Regex("""tvg-logo="([^"]*)"""").find(trimmed)?.groupValues?.get(1) ?: ""
                    currentGroup = Regex("""group-title="([^"]*)"""").find(trimmed)?.groupValues?.get(1)?.ifEmpty { "Uncategorized" } ?: "Uncategorized"
                    currentTvgId = Regex("""tvg-id="([^"]*)"""").find(trimmed)?.groupValues?.get(1) ?: ""
                    currentCatchUp = trimmed.contains("catchup=", ignoreCase = true)
                    val commaIdx = trimmed.lastIndexOf(',')
                    currentName = if (commaIdx >= 0 && commaIdx + 1 < trimmed.length) {
                        trimmed.substring(commaIdx + 1).trim()
                    } else "Channel $num"
                } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                    val url = trimmed
                    if (config.isVodOnly) {
                        movies.add(
                            VodMovie(
                                id = "${config.id}_m_$num",
                                playlistId = config.id,
                                title = currentName.ifEmpty { "Video $num" },
                                groupTitle = currentGroup,
                                posterUrl = currentLogo,
                                streamUrl = url
                            )
                        )
                    } else {
                        channels.add(
                            ChannelItem(
                                id = "${config.id}_c_$num",
                                playlistId = config.id,
                                number = num,
                                name = currentName.ifEmpty { "Channel $num" },
                                originalName = currentName.ifEmpty { "Channel $num" },
                                streamUrl = url,
                                logoUrl = currentLogo,
                                groupTitle = currentGroup,
                                tvgId = currentTvgId.ifEmpty { currentName },
                                hasCatchUp = currentCatchUp
                            )
                        )
                    }
                    num++
                    currentName = ""
                    currentLogo = ""
                    currentTvgId = ""
                    currentCatchUp = false
                }
                line = br.readLine()
            }
        }
        return ParsedPlaylistResult(channels, movies, emptyList(), detectedEpg)
    }

    private fun normalizeBaseUrl(raw: String): String {
        var u = raw.trim().trimEnd('/')
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
        return u
    }

    private fun getJson(url: String, ua: String = "TiviMate/4.7.0", cookie: String = ""): String {
        val req = Request.Builder().url(url).apply {
            header("User-Agent", ua.ifEmpty { "TiviMate/4.7.0" })
            if (cookie.isNotEmpty()) header("Cookie", cookie)
        }.build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            return resp.body?.string() ?: ""
        }
    }

    private fun parseXtream(config: PlaylistConfig): ParsedPlaylistResult {
        val base = normalizeBaseUrl(config.url)
        val u = config.username.trim()
        val p = config.password.trim()
        val ext = if (config.outputFormat.equals("HLS", true)) "m3u8" else "ts"

        var expStr = ""
        runCatching {
            val authJson = getJson("$base/player_api.php?username=$u&password=$p", config.userAgent)
            val obj = JsonParser.parseString(authJson).asJsonObject
            val expSec = obj.getAsJsonObject("user_info")?.get("exp_date")?.asString?.toLongOrNull()
            if (expSec != null && expSec > 0) {
                expStr = SimpleDateFormat("dd/MM/yy", Locale.US).format(Date(expSec * 1000L))
            }
        }

        val channels = mutableListOf<ChannelItem>()
        if (config.includeTv) {
            val catMap = mutableMapOf<String, String>()
            runCatching {
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_live_categories", config.userAgent)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id")?.asString ?: ""] = o.get("category_name")?.asString ?: "Uncategorized"
                }
            }
            val streamsJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_live_streams", config.userAgent)
            val arr = JsonParser.parseString(streamsJson).asJsonArray
            var num = 1
            arr.forEach { el ->
                val o = el.asJsonObject
                val sid = o.get("stream_id")?.asString ?: return@forEach
                val name = o.get("name")?.asString ?: "Channel $num"
                val icon = o.get("stream_icon")?.asString ?: ""
                val catId = o.get("category_id")?.asString ?: ""
                val epgId = o.get("epg_channel_id")?.asString ?: name
                val tvArchive = (o.get("tv_archive")?.asInt ?: 0) == 1
                channels.add(
                    ChannelItem(
                        id = "${config.id}_xc_$sid",
                        playlistId = config.id,
                        number = num++,
                        name = name,
                        originalName = name,
                        streamUrl = "$base/live/$u/$p/$sid.$ext",
                        logoUrl = icon,
                        groupTitle = catMap[catId] ?: "Live TV",
                        tvgId = epgId,
                        hasCatchUp = tvArchive
                    )
                )
            }
        }

        val movies = mutableListOf<VodMovie>()
        val shows = mutableListOf<VodShow>()
        if (config.includeVod) {
            runCatching {
                val catMap = mutableMapOf<String, String>()
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_vod_categories", config.userAgent)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id")?.asString ?: ""] = o.get("category_name")?.asString ?: "Movies"
                }
                val vodJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_vod_streams", config.userAgent)
                JsonParser.parseString(vodJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    val sid = o.get("stream_id")?.asString ?: return@forEach
                    val name = o.get("name")?.asString ?: "Movie"
                    val cExt = o.get("container_extension")?.asString ?: "mp4"
                    val catId = o.get("category_id")?.asString ?: ""
                    movies.add(
                        VodMovie(
                            id = "${config.id}_xm_$sid",
                            playlistId = config.id,
                            title = name,
                            groupTitle = catMap[catId] ?: "Movies",
                            posterUrl = o.get("stream_icon")?.asString ?: "",
                            streamUrl = "$base/movie/$u/$p/$sid.$cExt",
                            rating = o.get("rating")?.asString ?: ""
                        )
                    )
                }
            }

            runCatching {
                val catMap = mutableMapOf<String, String>()
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_series_categories", config.userAgent)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id")?.asString ?: ""] = o.get("category_name")?.asString ?: "Shows"
                }
                val seriesJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_series", config.userAgent)
                JsonParser.parseString(seriesJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    val sid = o.get("series_id")?.asString ?: return@forEach
                    val catId = o.get("category_id")?.asString ?: ""
                    shows.add(
                        VodShow(
                            id = "${config.id}_xs_$sid",
                            playlistId = config.id,
                            title = o.get("name")?.asString ?: "Show",
                            groupTitle = catMap[catId] ?: "Shows",
                            posterUrl = o.get("cover")?.asString ?: "",
                            backdropUrl = o.get("backdrop_path")?.let { b ->
                                if (b.isJsonArray && b.asJsonArray.size() > 0) b.asJsonArray[0].asString else ""
                            } ?: "",
                            rating = o.get("rating")?.asString ?: "",
                            year = o.get("releaseDate")?.asString ?: "",
                            genres = o.get("genre")?.asString ?: "",
                            description = o.get("plot")?.asString ?: ""
                        )
                    )
                }
            }
        }

        val defaultEpg = "$base/xmltv.php?username=$u&password=$p"
        return ParsedPlaylistResult(channels, movies, shows, defaultEpg, expStr)
    }

    private fun parseStalker(config: PlaylistConfig): ParsedPlaylistResult {
        val base = normalizeBaseUrl(config.url)
        val portalApi = if (base.endsWith(".php")) base else "$base/portal.php"
        val cookie = "mac=${config.macAddress}; stb_lang=en; timezone=UTC"
        val ua = config.userAgent.ifEmpty { "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3" }

        val hsJson = getJson("$portalApi?type=stb&action=handshake&token=&JsHttpRequest=1-xml", ua, cookie)
        val token = JsonParser.parseString(hsJson).asJsonObject
            .getAsJsonObject("js")?.get("token")?.asString ?: ""

        val genreMap = mutableMapOf<String, String>()
        runCatching {
            val gReq = Request.Builder().url("$portalApi?type=itv&action=get_genres&JsHttpRequest=1-xml")
                .header("User-Agent", ua)
                .header("Cookie", cookie)
                .apply { if (token.isNotEmpty()) header("Authorization", "Bearer $token") }
                .build()
            httpClient.newCall(gReq).execute().use { resp ->
                val txt = resp.body?.string() ?: "{}"
                JsonParser.parseString(txt).asJsonObject.getAsJsonArray("js")?.forEach { el ->
                    val o = el.asJsonObject
                    genreMap[o.get("id")?.asString ?: ""] = o.get("title")?.asString ?: "Live TV"
                }
            }
        }

        val channels = mutableListOf<ChannelItem>()
        if (config.includeTv) {
            val chReq = Request.Builder().url("$portalApi?type=itv&action=get_all_channels&JsHttpRequest=1-xml")
                .header("User-Agent", ua)
                .header("Cookie", cookie)
                .apply { if (token.isNotEmpty()) header("Authorization", "Bearer $token") }
                .build()
            httpClient.newCall(chReq).execute().use { resp ->
                val txt = resp.body?.string() ?: "{}"
                val dataArr = JsonParser.parseString(txt).asJsonObject
                    .getAsJsonObject("js")?.getAsJsonArray("data")
                var num = 1
                dataArr?.forEach { el ->
                    val o = el.asJsonObject
                    val cid = o.get("id")?.asString ?: "$num"
                    val name = o.get("name")?.asString ?: "Channel $num"
                    val cmd = o.get("cmd")?.asString ?: ""
                    val logo = o.get("logo")?.asString ?: ""
                    val gid = o.get("tv_genre_id")?.asString ?: ""
                    val directUrl = cmd.removePrefix("ffmpeg ").trim()
                    channels.add(
                        ChannelItem(
                            id = "${config.id}_st_$cid",
                            playlistId = config.id,
                            number = o.get("number")?.asInt ?: num,
                            name = name,
                            originalName = name,
                            streamUrl = directUrl,
                            logoUrl = if (logo.startsWith("http")) logo else "",
                            groupTitle = genreMap[gid] ?: "Stalker TV",
                            tvgId = cid,
                            stalkerCmd = cmd
                        )
                    )
                    num++
                }
            }
        }

        return ParsedPlaylistResult(channels, emptyList(), emptyList(), "")
    }

    fun resolveStalkerStreamUrl(config: PlaylistConfig, cmd: String): String {
        if (cmd.isEmpty()) return ""
        return runCatching {
            val base = normalizeBaseUrl(config.url)
            val portalApi = if (base.endsWith(".php")) base else "$base/portal.php"
            val cookie = "mac=${config.macAddress}; stb_lang=en; timezone=UTC"
            val ua = config.userAgent.ifEmpty { "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3" }
            val hsJson = getJson("$portalApi?type=stb&action=handshake&token=&JsHttpRequest=1-xml", ua, cookie)
            val token = JsonParser.parseString(hsJson).asJsonObject.getAsJsonObject("js")?.get("token")?.asString ?: ""
            val encodedCmd = java.net.URLEncoder.encode(cmd, "UTF-8")
            val req = Request.Builder().url("$portalApi?type=itv&action=create_link&cmd=$encodedCmd&JsHttpRequest=1-xml")
                .header("User-Agent", ua)
                .header("Cookie", cookie)
                .apply { if (token.isNotEmpty()) header("Authorization", "Bearer $token") }
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val txt = resp.body?.string() ?: "{}"
                val raw = JsonParser.parseString(txt).asJsonObject
                    .getAsJsonObject("js")?.get("cmd")?.asString ?: ""
                raw.removePrefix("ffmpeg ").trim()
            }
        }.getOrElse { cmd.removePrefix("ffmpeg ").trim() }
    }
}
