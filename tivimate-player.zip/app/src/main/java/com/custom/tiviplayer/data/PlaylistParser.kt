package com.custom.tiviplayer.data

import android.content.Context
import android.net.Uri
import com.custom.tiviplayer.model.*
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.URLEncoder
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

data class ParsedPlaylistResult(
    val channels: List<ChannelItem>,
    val movies: List<VodMovie>,
    val shows: List<VodShow>,
    val detectedEpgUrl: String = "",
    val expirationDate: String = ""
)

object PlaylistParser {
    val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    })

    val sslContext: SSLContext = SSLContext.getInstance("TLS").apply {
        init(null, trustAllCerts, SecureRandom())
    }

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .sslSocketFactory(sslContext.socketFactory, trustAllCerts[0] as X509TrustManager)
        .hostnameVerifier { _, _ -> true }
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun fetchAndParse(context: Context, config: PlaylistConfig): ParsedPlaylistResult {
        return when (config.type) {
            PlaylistType.M3U -> parseM3u(context, config)
            PlaylistType.XTREAM -> parseXtream(config)
            PlaylistType.STALKER -> parseStalker(config)
        }
    }

    private fun JsonElement?.asSafeString(default: String = ""): String {
        if (this == null || isJsonNull) return default
        return runCatching { asString }.getOrDefault(default)
    }

    private fun JsonElement?.asSafeInt(default: Int = 0): Int {
        if (this == null || isJsonNull) return default
        return runCatching { asInt }.getOrElse { asSafeString().toIntOrNull() ?: default }
    }

    private fun parseM3u(context: Context, config: PlaylistConfig): ParsedPlaylistResult {
        val reader: BufferedReader = when {
            config.localUri.isNotEmpty() -> {
                if (config.localUri.startsWith("content://")) {
                    val ins = context.contentResolver.openInputStream(Uri.parse(config.localUri))
                        ?: throw IllegalStateException("Cannot open local playlist")
                    BufferedReader(InputStreamReader(ins))
                } else {
                    File(config.localUri).bufferedReader()
                }
            }
            config.url.isNotEmpty() -> {
                val req = Request.Builder().url(config.url)
                    .header("User-Agent", config.userAgent.ifEmpty { "TiviMate/4.7.0" })
                    .build()
                val resp = httpClient.newCall(req).execute()
                if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                BufferedReader(InputStreamReader(resp.body!!.byteStream()))
            }
            else -> throw IllegalArgumentException("Empty M3U source")
        }

        val channels = mutableListOf<ChannelItem>()
        val movies = mutableListOf<VodMovie>()
        var detectedEpg = ""
        var num = 1

        var currentName = ""
        var currentLogo = ""
        var currentGroup = "Uncategorized"
        var currentTvgId = ""
        var currentCatchUp = false

        reader.use { br ->
            var line = br.readLine()
            while (line != null) {
                val trimmed = line.trim()
                if (trimmed.startsWith("#EXTM3U")) {
                    val epgMatch = Regex("""(?:url-tvg|x-tvg-url)="([^"]+)"""").find(trimmed)
                    if (epgMatch != null) detectedEpg = epgMatch.groupValues[1]
                } else if (trimmed.startsWith("#EXTINF")) {
                    currentLogo = Regex("""tvg-logo="([^"]*)"""").find(trimmed)?.groupValues?.get(1) ?: ""
                    currentGroup = Regex("""group-title="([^"]*)"""").find(trimmed)?.groupValues?.get(1)?.ifEmpty { "Uncategorized" } ?: "Uncategorized"
                    currentTvgId = Regex("""tvg-id="([^"]*)"""").find(trimmed)?.groupValues?.get(1) ?: ""
                    currentCatchUp = trimmed.contains("catchup=", ignoreCase = true)
                    val commaIdx = trimmed.lastIndexOf(',')
                    currentName = if (commaIdx >= 0 && commaIdx + 1 < trimmed.length) {
                        trimmed.substring(commaIdx + 1).trim()
                    } else "Channel $num"
                } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                    if (config.isVodOnly) {
                        movies.add(
                            VodMovie(
                                id = "${config.id}_m_$num",
                                playlistId = config.id,
                                title = currentName.ifEmpty { "Video $num" },
                                groupTitle = currentGroup,
                                posterUrl = currentLogo,
                                streamUrl = trimmed
                            )
                        )
                    } else {
                        channels.add(
                            ChannelItem(
                                id = "${config.id}_c_$num",
                                playlistId = config.id,
                                number = num,
                                name = currentName.ifEmpty { "Channel $num" },
                                originalName = currentName.ifEmpty { "Channel $num" },
                                streamUrl = trimmed,
                                logoUrl = currentLogo,
                                groupTitle = currentGroup,
                                tvgId = currentTvgId.ifEmpty { currentName },
                                hasCatchUp = currentCatchUp
                            )
                        )
                    }
                    num++
                    currentName = ""
                    currentLogo = ""
                    currentTvgId = ""
                    currentCatchUp = false
                }
                line = br.readLine()
            }
        }
        return ParsedPlaylistResult(channels, movies, emptyList(), detectedEpg)
    }

    private fun normalizeBaseUrl(raw: String): String {
        var u = raw.trim().trimEnd('/')
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
        return u
    }

    private fun getJson(url: String, ua: String = "TiviMate/4.7.0", cookie: String = "", token: String = ""): String {
        val req = Request.Builder().url(url).apply {
            header("User-Agent", ua.ifEmpty { "TiviMate/4.7.0" })
            header("Accept", "*/*")
            if (cookie.isNotEmpty()) header("Cookie", cookie)
            if (token.isNotEmpty()) header("Authorization", "Bearer $token")
            header("X-User-Agent", "Model: MAG250; Link: WiFi")
        }.build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            return resp.body?.string() ?: ""
        }
    }

    private fun parseXtream(config: PlaylistConfig): ParsedPlaylistResult {
        val base = normalizeBaseUrl(config.url)
        val u = URLEncoder.encode(config.username.trim(), "UTF-8")
        val p = URLEncoder.encode(config.password.trim(), "UTF-8")
        val rawU = config.username.trim()
        val rawP = config.password.trim()
        val ext = if (config.outputFormat.equals("HLS", true)) "m3u8" else "ts"
        val ua = config.userAgent.ifEmpty { "TiviMate/4.7.0" }

        var expStr = ""
        val authJson = getJson("$base/player_api.php?username=$u&password=$p", ua)
        val authObj = runCatching { JsonParser.parseString(authJson).asJsonObject }.getOrNull()
        val userInfo = authObj?.getAsJsonObject("user_info")
        val authStatus = userInfo?.get("auth")?.asSafeInt(1) ?: 1
        if (authStatus == 0) throw IllegalStateException("Invalid Xtream username or password")
        val expSec = userInfo?.get("exp_date")?.asSafeString()?.toLongOrNull()
        if (expSec != null && expSec > 0) {
            expStr = SimpleDateFormat("dd/MM/yy", Locale.US).format(Date(expSec * 1000L))
        }

        val channels = mutableListOf<ChannelItem>()
        if (config.includeTv) {
            val catMap = mutableMapOf<String, String>()
            runCatching {
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_live_categories", ua)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id").asSafeString()] = o.get("category_name").asSafeString("Live TV")
                }
            }
            runCatching {
                val streamsJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_live_streams", ua)
                val arr = JsonParser.parseString(streamsJson).asJsonArray
                var num = 1
                arr.forEach { el ->
                    val o = el.asJsonObject
                    val sid = o.get("stream_id").asSafeString()
                    if (sid.isEmpty()) return@forEach
                    val name = o.get("name").asSafeString("Channel $num")
                    val icon = o.get("stream_icon").asSafeString()
                    val catId = o.get("category_id").asSafeString()
                    val epgId = o.get("epg_channel_id").asSafeString(name).ifEmpty { name }
                    val tvArchive = o.get("tv_archive").asSafeInt(0) == 1
                    channels.add(
                        ChannelItem(
                            id = "${config.id}_xc_$sid",
                            playlistId = config.id,
                            number = num++,
                            name = name,
                            originalName = name,
                            streamUrl = "$base/live/$rawU/$rawP/$sid.$ext",
                            logoUrl = icon,
                            groupTitle = catMap[catId] ?: "Live TV",
                            tvgId = epgId,
                            hasCatchUp = tvArchive
                        )
                    )
                }
            }
        }

        val movies = mutableListOf<VodMovie>()
        val shows = mutableListOf<VodShow>()
        if (config.includeVod) {
            runCatching {
                val catMap = mutableMapOf<String, String>()
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_vod_categories", ua)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id").asSafeString()] = o.get("category_name").asSafeString("Movies")
                }
                val vodJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_vod_streams", ua)
                JsonParser.parseString(vodJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    val sid = o.get("stream_id").asSafeString()
                    if (sid.isEmpty()) return@forEach
                    val name = o.get("name").asSafeString("Movie")
                    val cExt = o.get("container_extension").asSafeString("mp4").ifEmpty { "mp4" }
                    val catId = o.get("category_id").asSafeString()
                    movies.add(
                        VodMovie(
                            id = "${config.id}_xm_$sid",
                            playlistId = config.id,
                            title = name,
                            groupTitle = catMap[catId] ?: "Movies",
                            posterUrl = o.get("stream_icon").asSafeString(),
                            streamUrl = "$base/movie/$rawU/$rawP/$sid.$cExt",
                            rating = o.get("rating").asSafeString()
                        )
                    )
                }
            }

            runCatching {
                val catMap = mutableMapOf<String, String>()
                val catJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_series_categories", ua)
                JsonParser.parseString(catJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    catMap[o.get("category_id").asSafeString()] = o.get("category_name").asSafeString("Shows")
                }
                val seriesJson = getJson("$base/player_api.php?username=$u&password=$p&action=get_series", ua)
                JsonParser.parseString(seriesJson).asJsonArray.forEach { el ->
                    val o = el.asJsonObject
                    val sid = o.get("series_id").asSafeString()
                    if (sid.isEmpty()) return@forEach
                    val catId = o.get("category_id").asSafeString()
                    val backdrop = runCatching {
                        val b = o.get("backdrop_path")
                        if (b != null && b.isJsonArray && b.asJsonArray.size() > 0) b.asJsonArray[0].asSafeString() else ""
                    }.getOrDefault("")
                    shows.add(
                        VodShow(
                            id = "${config.id}_xs_$sid",
                            playlistId = config.id,
                            seriesId = sid,
                            title = o.get("name").asSafeString("Show"),
                            groupTitle = catMap[catId] ?: "Shows",
                            posterUrl = o.get("cover").asSafeString(),
                            backdropUrl = backdrop,
                            rating = o.get("rating").asSafeString(),
                            year = o.get("releaseDate").asSafeString(),
                            genres = o.get("genre").asSafeString(),
                            description = o.get("plot").asSafeString()
                        )
                    )
                }
            }
        }

        val defaultEpg = "$base/xmltv.php?username=$rawU&password=$rawP"
        return ParsedPlaylistResult(channels, movies, shows, defaultEpg, expStr)
    }

    fun fetchXtreamSeriesEpisodes(config: PlaylistConfig, seriesId: String): List<VodEpisode> {
        val base = normalizeBaseUrl(config.url)
        val u = URLEncoder.encode(config.username.trim(), "UTF-8")
        val p = URLEncoder.encode(config.password.trim(), "UTF-8")
        val rawU = config.username.trim()
        val rawP = config.password.trim()
        val ua = config.userAgent.ifEmpty { "TiviMate/4.7.0" }
        val json = getJson("$base/player_api.php?username=$u&password=$p&action=get_series_info&series_id=$seriesId", ua)
        val root = JsonParser.parseString(json).asJsonObject
        val episodesObj = root.getAsJsonObject("episodes") ?: return emptyList()
        val list = mutableListOf<VodEpisode>()
        episodesObj.entrySet().forEach { (seasonKey, arrEl) ->
            val seasonNum = seasonKey.toIntOrNull() ?: 1
            if (arrEl.isJsonArray) {
                arrEl.asJsonArray.forEach { epEl ->
                    val o = epEl.asJsonObject
                    val eid = o.get("id").asSafeString()
                    val ext = o.get("container_extension").asSafeString("mp4").ifEmpty { "mp4" }
                    val epNum = o.get("episode_num").asSafeInt(1)
                    val title = o.get("title").asSafeString("S${seasonNum} E${epNum}")
                    val thumb = runCatching { o.getAsJsonObject("info")?.get("movie_image").asSafeString() }.getOrDefault("")
                    if (eid.isNotEmpty()) {
                        list.add(
                            VodEpisode(
                                id = eid,
                                season = seasonNum,
                                episodeNum = epNum,
                                title = title,
                                streamUrl = "$base/series/$rawU/$rawP/$eid.$ext",
                                thumbUrl = thumb
                            )
                        )
                    }
                }
            }
        }
        return list.sortedWith(compareBy({ it.season }, { it.episodeNum }))
    }

    private fun resolveStalkerEndpoint(base: String, ua: String, cookie: String): Pair<String, String> {
        val uri = Uri.parse(base)
        val origin = "${uri.scheme}://${uri.host}${if (uri.port != -1) ":${uri.port}" else ""}"
        val candidates = linkedSetOf(
            if (base.endsWith(".php")) base else "$base/server/load.php",
            "$base/portal.php",
            "$origin/stalker_portal/server/load.php",
            "$origin/portal/server/load.php",
            "$origin/server/load.php",
            "$origin/c/portal.php",
            "$origin/portal.php"
        )
        for (ep in candidates) {
            val res = runCatching {
                val txt = getJson("$ep?type=stb&action=handshake&token=&JsHttpRequest=1-xml", ua, cookie)
                val obj = JsonParser.parseString(txt).asJsonObject
                val token = obj.getAsJsonObject("js")?.get("token").asSafeString()
                if (token.isNotEmpty()) ep to token else null
            }.getOrNull()
            if (res != null) return res
        }
        throw IllegalStateException("Stalker Portal handshake failed")
    }

    private fun parseStalker(config: PlaylistConfig): ParsedPlaylistResult {
        val base = normalizeBaseUrl(config.url)
        val cookie = "mac=${config.macAddress.trim()}; stb_lang=en; timezone=UTC"
        val ua = config.userAgent.ifEmpty {
            "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        }

        val (portalApi, token) = resolveStalkerEndpoint(base, ua, cookie)

        // Auto-generate SN, Device ID, Device ID 2 from MAC if blank
        val macUpper = config.macAddress.trim().uppercase()
        if (config.serialNumber.isEmpty()) {
            val md5Hex = java.security.MessageDigest.getInstance("MD5").digest(macUpper.toByteArray()).joinToString("") { "%02x".format(it) }
            config.serialNumber = md5Hex.substring(0, 13).uppercase()
        }
        if (config.deviceId.isEmpty()) {
            val shaHex = java.security.MessageDigest.getInstance("SHA-256").digest(macUpper.toByteArray()).joinToString("") { "%02X".format(it) }
            config.deviceId = shaHex
            config.deviceId2 = shaHex
        } else if (config.deviceId2.isEmpty()) {
            config.deviceId2 = config.deviceId
        }

        // Send get_profile to authenticate MAC & device IDs
        runCatching {
            val snParam = "&sn=${URLEncoder.encode(config.serialNumber, "UTF-8")}"
            val d1Param = "&device_id=${URLEncoder.encode(config.deviceId, "UTF-8")}"
            val d2Param = "&device_id2=${URLEncoder.encode(config.deviceId2, "UTF-8")}"
            getJson("$portalApi?type=stb&action=get_profile&hd=1&ver=ImageDescription:%200.2.18-r14-pub-250;$snParam$d1Param$d2Param&stb_type=MAG250&num_banks=2$snParam&image_version=218&video_out=hdmi&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&JsHttpRequest=1-xml", ua, cookie, token)
        }

        val genreMap = mutableMapOf<String, String>()
        runCatching {
            val gTxt = getJson("$portalApi?type=itv&action=get_genres&JsHttpRequest=1-xml", ua, cookie, token)
            JsonParser.parseString(gTxt).asJsonObject.getAsJsonArray("js")?.forEach { el ->
                val o = el.asJsonObject
                genreMap[o.get("id").asSafeString()] = o.get("title").asSafeString("Live TV")
            }
        }

        val channels = mutableListOf<ChannelItem>()
        if (config.includeTv) {
            runCatching {
                val txt = getJson("$portalApi?type=itv&action=get_all_channels&JsHttpRequest=1-xml", ua, cookie, token)
                val dataArr = JsonParser.parseString(txt).asJsonObject
                    .getAsJsonObject("js")?.getAsJsonArray("data")
                var num = 1
                dataArr?.forEach { el ->
                    val o = el.asJsonObject
                    val cid = o.get("id").asSafeString("$num")
                    val name = o.get("name").asSafeString("Channel $num")
                    val cmd = o.get("cmd").asSafeString()
                    val logo = o.get("logo").asSafeString()
                    val gid = o.get("tv_genre_id").asSafeString()
                    val xmltvId = o.get("xmltv_id").asSafeString(cid).ifEmpty { cid }
                    val directUrl = cleanStalkerCmd(cmd)
                    channels.add(
                        ChannelItem(
                            id = "${config.id}_st_$cid",
                            playlistId = config.id,
                            number = o.get("number").asSafeInt(num),
                            name = name,
                            originalName = name,
                            streamUrl = directUrl,
                            logoUrl = if (logo.startsWith("http")) logo else "",
                            groupTitle = genreMap[gid] ?: "Stalker TV",
                            tvgId = xmltvId,
                            stalkerCmd = cmd
                        )
                    )
                    num++
                }
            }
        }

        val movies = mutableListOf<VodMovie>()
        val shows = mutableListOf<VodShow>()
        if (config.includeVod) {
            // Paginate Stalker VOD Movies (14 per page)
            runCatching {
                val vodCats = mutableMapOf<String, String>()
                runCatching {
                    val cTxt = getJson("$portalApi?type=vod&action=get_categories&JsHttpRequest=1-xml", ua, cookie, token)
                    JsonParser.parseString(cTxt).asJsonObject.getAsJsonArray("js")?.forEach { el ->
                        val o = el.asJsonObject
                        vodCats[o.get("id").asSafeString()] = o.get("title").asSafeString("VOD")
                    }
                }
                for (page in 1..25) {
                    val txt = getJson("$portalApi?type=vod&action=get_ordered_list&p=$page&JsHttpRequest=1-xml", ua, cookie, token)
                    val js = JsonParser.parseString(txt).asJsonObject.getAsJsonObject("js") ?: break
                    val dataArr = js.getAsJsonArray("data") ?: break
                    if (dataArr.size() == 0) break
                    dataArr.forEach { el ->
                        val o = el.asJsonObject
                        val id = o.get("id").asSafeString()
                        val name = o.get("name").asSafeString("Movie")
                        val cmd = o.get("cmd").asSafeString()
                        val catId = o.get("category_id").asSafeString()
                        val isSeries = o.get("is_series").asSafeInt(0) == 1
                        if (isSeries) {
                            shows.add(
                                VodShow(
                                    id = "${config.id}_ss_$id",
                                    playlistId = config.id,
                                    seriesId = id,
                                    title = name,
                                    groupTitle = vodCats[catId] ?: "Shows",
                                    posterUrl = o.get("screenshot_uri").asSafeString(),
                                    rating = o.get("rating_imdb").asSafeString(),
                                    year = o.get("year").asSafeString(),
                                    description = o.get("description").asSafeString()
                                )
                            )
                        } else {
                            movies.add(
                                VodMovie(
                                    id = "${config.id}_sm_$id",
                                    playlistId = config.id,
                                    title = name,
                                    groupTitle = vodCats[catId] ?: "Movies",
                                    posterUrl = o.get("screenshot_uri").asSafeString(),
                                    streamUrl = cleanStalkerCmd(cmd),
                                    rating = o.get("rating_imdb").asSafeString(),
                                    year = o.get("year").asSafeString(),
                                    description = o.get("description").asSafeString()
                                )
                            )
                        }
                    }
                    val total = js.get("total_items").asSafeInt(0)
                    if (total > 0 && movies.size + shows.size >= total) break
                }
            }

            // Also fetch dedicated Stalker Series endpoint
            runCatching {
                for (page in 1..25) {
                    val txt = getJson("$portalApi?type=series&action=get_ordered_list&p=$page&JsHttpRequest=1-xml", ua, cookie, token)
                    val js = JsonParser.parseString(txt).asJsonObject.getAsJsonObject("js") ?: break
                    val dataArr = js.getAsJsonArray("data") ?: break
                    if (dataArr.size() == 0) break
                    dataArr.forEach { el ->
                        val o = el.asJsonObject
                        val id = o.get("id").asSafeString()
                        val name = o.get("name").asSafeString("Show")
                        shows.add(
                            VodShow(
                                id = "${config.id}_ss2_$id",
                                playlistId = config.id,
                                seriesId = id,
                                title = name,
                                groupTitle = "Series",
                                posterUrl = o.get("screenshot_uri").asSafeString(),
                                rating = o.get("rating_imdb").asSafeString(),
                                year = o.get("year").asSafeString(),
                                description = o.get("description").asSafeString()
                            )
                        )
                    }
                    val total = js.get("total_items").asSafeInt(0)
                    if (total > 0 && dataArr.size() < 14) break
                }
            }
        }

        return ParsedPlaylistResult(channels, movies, shows, "")
    }

    private fun cleanStalkerCmd(cmd: String): String {
        return cmd.trim()
            .removePrefix("ffmpeg ")
            .removePrefix("ffrt ")
            .removePrefix("ffrt2 ")
            .removePrefix("ffrt3 ")
            .removePrefix("ffrt4 ")
            .trim()
    }

    fun resolveStalkerStreamUrl(config: PlaylistConfig, cmd: String): String {
        if (cmd.isEmpty()) return ""
        return runCatching {
            val base = normalizeBaseUrl(config.url)
            val cookie = "mac=${config.macAddress.trim()}; stb_lang=en; timezone=UTC"
            val ua = config.userAgent.ifEmpty {
                "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
            }
            val (portalApi, token) = resolveStalkerEndpoint(base, ua, cookie)
            val encodedCmd = URLEncoder.encode(cmd, "UTF-8")
            val txt = getJson("$portalApi?type=itv&action=create_link&cmd=$encodedCmd&series=0&forced_storage=undefined&disable_ad=0&JsHttpRequest=1-xml", ua, cookie, token)
            val raw = JsonParser.parseString(txt).asJsonObject
                .getAsJsonObject("js")?.get("cmd").asSafeString()
            cleanStalkerCmd(raw).ifEmpty { cleanStalkerCmd(cmd) }
        }.getOrElse { cleanStalkerCmd(cmd) }
    }
}
