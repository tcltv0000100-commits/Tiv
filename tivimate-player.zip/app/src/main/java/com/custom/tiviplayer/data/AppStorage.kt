package com.custom.tiviplayer.data

import android.content.Context
import com.custom.tiviplayer.model.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

class AppStorage(private val context: Context) {
    private val prefs = context.getSharedPreferences("tivimate_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val cacheDir = File(context.filesDir, "tivimate_cache").apply { mkdirs() }

    fun getSettings(): AppSettings {
        val json = prefs.getString("app_settings", null) ?: return AppSettings()
        return runCatching { gson.fromJson(json, AppSettings::class.java) }.getOrElse { AppSettings() }
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit().putString("app_settings", gson.toJson(settings)).apply()
    }

    fun getPlaylists(): MutableList<PlaylistConfig> {
        val json = prefs.getString("playlists", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<PlaylistConfig>>() {}.type
        return runCatching { gson.fromJson<MutableList<PlaylistConfig>>(json, type) }.getOrElse { mutableListOf() }
    }

    fun savePlaylists(list: List<PlaylistConfig>) {
        prefs.edit().putString("playlists", gson.toJson(list)).apply()
    }

    fun getEpgSources(): MutableList<EpgSourceConfig> {
        val json = prefs.getString("epg_sources", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<EpgSourceConfig>>() {}.type
        return runCatching { gson.fromJson<MutableList<EpgSourceConfig>>(json, type) }.getOrElse { mutableListOf() }
    }

    fun saveEpgSources(list: List<EpgSourceConfig>) {
        prefs.edit().putString("epg_sources", gson.toJson(list)).apply()
    }

    fun saveChannels(playlistId: String, channels: List<ChannelItem>) {
        File(cacheDir, "ch_$playlistId.json").writeText(gson.toJson(channels))
    }

    fun loadChannels(playlistId: String): MutableList<ChannelItem> {
        val f = File(cacheDir, "ch_$playlistId.json")
        if (!f.exists()) return mutableListOf()
        val type = object : TypeToken<MutableList<ChannelItem>>() {}.type
        return runCatching { gson.fromJson<MutableList<ChannelItem>>(f.readText(), type) }.getOrElse { mutableListOf() }
    }

    fun saveMovies(playlistId: String, movies: List<VodMovie>) {
        File(cacheDir, "mov_$playlistId.json").writeText(gson.toJson(movies))
    }

    fun loadMovies(playlistId: String): MutableList<VodMovie> {
        val f = File(cacheDir, "mov_$playlistId.json")
        if (!f.exists()) return mutableListOf()
        val type = object : TypeToken<MutableList<VodMovie>>() {}.type
        return runCatching { gson.fromJson<MutableList<VodMovie>>(f.readText(), type) }.getOrElse { mutableListOf() }
    }

    fun saveShows(playlistId: String, shows: List<VodShow>) {
        File(cacheDir, "show_$playlistId.json").writeText(gson.toJson(shows))
    }

    fun loadShows(playlistId: String): MutableList<VodShow> {
        val f = File(cacheDir, "show_$playlistId.json")
        if (!f.exists()) return mutableListOf()
        val type = object : TypeToken<MutableList<VodShow>>() {}.type
        return runCatching { gson.fromJson<MutableList<VodShow>>(f.readText(), type) }.getOrElse { mutableListOf() }
    }

    fun saveEpgMap(epgMap: Map<String, List<EpgProgram>>) {
        File(cacheDir, "epg_programs.json").writeText(gson.toJson(epgMap))
    }

    fun loadEpgMap(): MutableMap<String, MutableList<EpgProgram>> {
        val f = File(cacheDir, "epg_programs.json")
        if (!f.exists()) return mutableMapOf()
        val type = object : TypeToken<MutableMap<String, MutableList<EpgProgram>>>() {}.type
        return runCatching { gson.fromJson<MutableMap<String, MutableList<EpgProgram>>>(f.readText(), type) }.getOrElse { mutableMapOf() }
    }

    fun clearEpg() {
        File(cacheDir, "epg_programs.json").delete()
    }

    fun getFavorites(): MutableSet<String> =
        prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()

    fun toggleFavorite(channelId: String): Boolean {
        val favs = getFavorites()
        val added = if (favs.contains(channelId)) { favs.remove(channelId); false } else { favs.add(channelId); true }
        prefs.edit().putStringSet("favorites", favs).apply()
        return added
    }

    fun getMyListVod(): MutableSet<String> =
        prefs.getStringSet("my_list_vod", emptySet())?.toMutableSet() ?: mutableSetOf()

    fun toggleMyListVod(id: String): Boolean {
        val set = getMyListVod()
        val added = if (set.contains(id)) { set.remove(id); false } else { set.add(id); true }
        prefs.edit().putStringSet("my_list_vod", set).apply()
        return added
    }

    fun getRecentChannelIds(): MutableList<String> {
        val json = prefs.getString("recent_channels", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<String>>() {}.type
        return runCatching { gson.fromJson<MutableList<String>>(json, type) }.getOrElse { mutableListOf() }
    }

    fun addRecentChannel(channelId: String) {
        val list = getRecentChannelIds()
        list.remove(channelId)
        list.add(0, channelId)
        if (list.size > 20) list.subList(20, list.size).clear()
        prefs.edit().putString("recent_channels", gson.toJson(list)).apply()
    }

    fun clearRecentChannels() {
        prefs.edit().remove("recent_channels").apply()
    }

    fun getSearchHistory(): MutableList<String> {
        val json = prefs.getString("search_history", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<String>>() {}.type
        return runCatching { gson.fromJson<MutableList<String>>(json, type) }.getOrElse { mutableListOf() }
    }

    fun addSearchHistory(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val list = getSearchHistory()
        list.remove(q)
        list.add(0, q)
        if (list.size > 15) list.subList(15, list.size).clear()
        prefs.edit().putString("search_history", gson.toJson(list)).apply()
    }

    fun clearSearchHistory() {
        prefs.edit().remove("search_history").apply()
    }

    fun getRecordings(): MutableList<RecordingEntry> {
        val json = prefs.getString("recordings", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<RecordingEntry>>() {}.type
        return runCatching { gson.fromJson<MutableList<RecordingEntry>>(json, type) }.getOrElse { mutableListOf() }
    }

    fun addRecording(entry: RecordingEntry) {
        val list = getRecordings()
        list.add(0, entry)
        prefs.edit().putString("recordings", gson.toJson(list)).apply()
    }

    fun getLastChannelId(): String? = prefs.getString("last_channel_id", null)
    fun setLastChannelId(id: String) { prefs.edit().putString("last_channel_id", id).apply() }

    fun deletePlaylistData(playlistId: String) {
        File(cacheDir, "ch_$playlistId.json").delete()
        File(cacheDir, "mov_$playlistId.json").delete()
        File(cacheDir, "show_$playlistId.json").delete()
    }

    fun exportBackupJson(): String {
        val backup = mapOf(
            "settings" to getSettings(),
            "playlists" to getPlaylists(),
            "epgSources" to getEpgSources(),
            "favorites" to getFavorites().toList()
        )
        return gson.toJson(backup)
    }
}
