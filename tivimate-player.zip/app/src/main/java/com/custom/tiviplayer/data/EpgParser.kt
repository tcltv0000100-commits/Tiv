package com.custom.tiviplayer.data

import android.util.Xml
import com.custom.tiviplayer.model.EpgProgram
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.GZIPInputStream

object EpgParser {
    private val fmtWithTz = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
    private val fmtNoTz = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun fetchAndParse(url: String, pastDaysToKeep: Int = 7): Map<String, MutableList<EpgProgram>> {
        val req = Request.Builder().url(url).header("User-Agent", "TiviMate/4.7.0").build()
        PlaylistParser.httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("EPG HTTP ${resp.code}")
            val rawStream = resp.body!!.byteStream()
            val stream: InputStream = if (url.endsWith(".gz", true)) GZIPInputStream(rawStream) else rawStream
            return parseXmltv(stream, pastDaysToKeep)
        }
    }

    private fun parseTime(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        val clean = raw.trim()
        return runCatching { fmtWithTz.parse(clean)?.time ?: 0L }.getOrElse {
            runCatching { fmtNoTz.parse(clean.take(14))?.time ?: 0L }.getOrElse { 0L }
        }
    }

    private fun parseXmltv(stream: InputStream, pastDaysToKeep: Int): Map<String, MutableList<EpgProgram>> {
        val map = mutableMapOf<String, MutableList<EpgProgram>>()
        val displayNames = mutableMapOf<String, String>()
        val cutoffMs = System.currentTimeMillis() - pastDaysToKeep * 24L * 3600L * 1000L
        val parser = Xml.newPullParser()
        parser.setInput(stream, null)

        var event = parser.eventType
        var inProgramme = false
        var currentChId = ""
        var startMs = 0L
        var endMs = 0L
        var title = ""
        var desc = ""

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "channel" -> {
                            currentChId = parser.getAttributeValue(null, "id") ?: ""
                        }
                        "display-name" -> if (!inProgramme && currentChId.isNotEmpty()) {
                            val dn = runCatching { parser.nextText() }.getOrDefault("").trim()
                            if (dn.isNotEmpty()) displayNames[currentChId] = dn
                        }
                        "programme" -> {
                            inProgramme = true
                            currentChId = parser.getAttributeValue(null, "channel") ?: ""
                            startMs = parseTime(parser.getAttributeValue(null, "start"))
                            endMs = parseTime(parser.getAttributeValue(null, "stop"))
                            title = ""
                            desc = ""
                        }
                        "title" -> if (inProgramme) title = runCatching { parser.nextText() }.getOrDefault("")
                        "desc" -> if (inProgramme) desc = runCatching { parser.nextText() }.getOrDefault("")
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "programme" && inProgramme) {
                        inProgramme = false
                        if (currentChId.isNotEmpty() && endMs > cutoffMs && title.isNotEmpty()) {
                            val prog = EpgProgram(currentChId, title, desc, startMs, endMs)
                            map.getOrPut(currentChId.lowercase()) { mutableListOf() }.add(prog)
                            displayNames[currentChId]?.lowercase()?.let { dn ->
                                if (dn != currentChId.lowercase()) {
                                    map.getOrPut(dn) { mutableListOf() }.add(prog)
                                }
                            }
                        }
                    }
                }
            }
            event = parser.next()
        }
        return map
    }
}
