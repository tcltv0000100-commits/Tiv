package com.custom.tiviplayer

import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.custom.tiviplayer.data.AppStorage
import com.custom.tiviplayer.data.PlaylistParser
import com.custom.tiviplayer.model.ChannelItem
import com.custom.tiviplayer.model.PlaylistType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.X509TrustManager
import kotlin.concurrent.thread

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var storage: AppStorage
    private lateinit var playerView: PlayerView
    private lateinit var multiviewGrid: LinearLayout
    private lateinit var buffering: ProgressBar
    private lateinit var osdOverlay: FrameLayout
    private lateinit var channelsOverlay: LinearLayout
    private lateinit var persistentClock: TextView

    private var player: ExoPlayer? = null
    private val mvPlayers = mutableListOf<ExoPlayer>()
    private var isMultiview = false

    private val channels = mutableListOf<ChannelItem>()
    private var currentIndex = 0
    private var vodTitle: String? = null
    private var vodUrl: String? = null
    private var retriedAltFormat = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideOsdRunnable = Runnable { osdOverlay.visibility = View.GONE }
    private val sleepRunnable = Runnable { finish() }
    private var sleepMinutes = 0
    private var audioOffsetMs = 0
    private var currentResizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
    private var resizeLabel = "Normal"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        HttpsURLConnection.setDefaultSSLSocketFactory(PlaylistParser.sslContext.socketFactory)
        HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }

        setContentView(R.layout.activity_player)
        storage = AppStorage(this)

        playerView = findViewById(R.id.mainPlayerView)
        multiviewGrid = findViewById(R.id.multiviewGrid)
        buffering = findViewById(R.id.playerBuffering)
        osdOverlay = findViewById(R.id.playerOsdOverlay)
        channelsOverlay = findViewById(R.id.playerChannelsOverlay)
        persistentClock = findViewById(R.id.persistentClock)

        val settings = storage.getSettings()
        applyHdrBoost(settings.hdrMode)
        if (settings.showClock) {
            persistentClock.visibility = View.VISIBLE
            updateClockText()
        }

        vodUrl = intent.getStringExtra("vod_url")
        vodTitle = intent.getStringExtra("vod_title")
        val targetChannelId = intent.getStringExtra("channel_id")

        if (vodUrl == null) {
            val playlists = storage.getPlaylists().filter { it.enabled }
            playlists.forEach { p ->
                channels.addAll(storage.loadChannels(p.id).filter { !p.hiddenChannels.contains(it.id) && !p.blockedChannels.contains(it.id) })
            }
            if (targetChannelId != null) {
                currentIndex = channels.indexOfFirst { it.id == targetChannelId }.coerceAtLeast(0)
            }
        }

        playerView.setOnClickListener {
            if (channelsOverlay.visibility == View.VISIBLE) {
                channelsOverlay.visibility = View.GONE
            } else {
                toggleOsd()
            }
        }

        setupQuickCards()
        setupBottomActions()
        setupChannelsOverlay()

        if (vodUrl != null) {
            playStream(vodUrl!!, vodTitle ?: "VOD", "")
        } else if (channels.isNotEmpty()) {
            playChannelAt(currentIndex)
        } else {
            Toast.makeText(this, "No playable channels", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun applyHdrBoost(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = if (enabled) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
        }
    }

    private fun updateClockText() {
        val fmt = SimpleDateFormat("EEE, d MMM, HH:mm", Locale.US)
        val now = fmt.format(Date())
        persistentClock.text = now
        findViewById<TextView>(R.id.osdDateTime).text = now
        handler.postDelayed({ if (!isFinishing) updateClockText() }, 15000)
    }

    private fun buildExoPlayer(ua: String, cookie: String = ""): ExoPlayer {
        val settings = storage.getSettings()
        val rf = DefaultRenderersFactory(this).apply {
            val mode = if (settings.audioDecoder == "Software" || settings.videoDecoder == "Software") {
                DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            } else {
                DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            }
            setExtensionRendererMode(mode)
        }
        val minBuf = when (settings.bufferSize) {
            "None" -> 500
            "Small" -> 2500
            "Medium" -> 5000
            "Large" -> 10000
            else -> 15000
        }
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBuf, minBuf * 3, 500, 1500)
            .build()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(ua.ifEmpty { "TiviMate/4.7.0" })
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(30000)
        if (cookie.isNotEmpty()) {
            httpFactory.setDefaultRequestProperties(mapOf("Cookie" to cookie))
        }
        val dsFactory = DefaultDataSource.Factory(this, httpFactory)
        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES)

        return ExoPlayer.Builder(this, rf)
            .setLoadControl(lc)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory, extractors))
            .build()
    }

    private fun playChannelAt(idx: Int) {
        if (channels.isEmpty()) return
        retriedAltFormat = false
        currentIndex = ((idx % channels.size) + channels.size) % channels.size
        val ch = channels[currentIndex]
        storage.setLastChannelId(ch.id)
        storage.addRecentChannel(ch.id)

        val playlist = storage.getPlaylists().find { it.id == ch.playlistId }
        val defaultStalkerUa = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
        val ua = when {
            playlist?.userAgent?.isNotEmpty() == true -> playlist.userAgent
            playlist?.type == PlaylistType.STALKER -> defaultStalkerUa
            else -> storage.getSettings().globalUserAgent.ifEmpty { "TiviMate/4.7.0" }
        }
        val cookie = if (playlist?.type == PlaylistType.STALKER) "mac=${playlist.macAddress.trim()}; stb_lang=en; timezone=UTC" else ""

        findViewById<TextView>(R.id.osdPlaylistGroup).text = "${playlist?.name ?: "Playlist"} • ${ch.groupTitle}"
        findViewById<TextView>(R.id.osdProgramTitle).text = ch.name
        findViewById<TextView>(R.id.osdTimeAndChannel).text = "${ch.number}  ${ch.name}"
        findViewById<ImageView>(R.id.osdChannelLogo).load(ch.logoUrl)

        if (playlist?.type == PlaylistType.STALKER && ch.stalkerCmd.isNotEmpty()) {
            buffering.visibility = View.VISIBLE
            thread {
                val resolved = PlaylistParser.resolveStalkerStreamUrl(playlist, ch.stalkerCmd)
                runOnUiThread { playStream(resolved.ifEmpty { ch.streamUrl }, ch.name, ua, cookie) }
            }
        } else {
            playStream(ch.streamUrl, ch.name, ua, cookie)
        }
        setupQuickCards()
    }

    private fun playStream(url: String, title: String, ua: String, cookie: String = "") {
        if (url.isEmpty()) return
        buffering.visibility = View.VISIBLE
        player?.release()
        player = buildExoPlayer(ua, cookie).also { p ->
            playerView.player = p
            playerView.resizeMode = currentResizeMode
            applyHdrBoost(storage.getSettings().hdrMode)

            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    buffering.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                }

                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    val hdLabel = if (videoSize.height >= 2000) "4K" else if (videoSize.height >= 720) "HD" else "SD"
                    findViewById<TextView>(R.id.osdBadgeHd).text = hdLabel
                    setupBottomActions()
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (!retriedAltFormat) {
                        retriedAltFormat = true
                        val altUrl = when {
                            url.endsWith(".ts", true) -> url.dropLast(3) + ".m3u8"
                            url.endsWith(".m3u8", true) -> url.dropLast(5) + ".ts"
                            else -> ""
                        }
                        if (altUrl.isNotEmpty()) {
                            playStream(altUrl, title, ua, cookie)
                            return
                        }
                    }
                    buffering.visibility = View.GONE
                    Toast.makeText(this@PlayerActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_SHORT).show()
                }
            })

            val itemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
            if (url.contains(".m3u8", true)) itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            p.setMediaItem(itemBuilder.build())
            p.prepare()
            p.playWhenReady = true
        }
        if (vodTitle != null) {
            findViewById<TextView>(R.id.osdPlaylistGroup).text = "VOD"
            findViewById<TextView>(R.id.osdProgramTitle).text = title
            findViewById<TextView>(R.id.osdTimeAndChannel).text = title
        }
        showOsd()
    }

    private fun toggleOsd() {
        if (osdOverlay.visibility == View.VISIBLE) {
            osdOverlay.visibility = View.GONE
            handler.removeCallbacks(hideOsdRunnable)
        } else {
            showOsd()
        }
    }

    private fun showOsd() {
        osdOverlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOsdRunnable)
        val timeout = storage.getSettings().panelsTimeoutSec.coerceIn(2, 15) * 1000L
        handler.postDelayed(hideOsdRunnable, timeout)
    }

    private fun setupQuickCards() {
        val row = findViewById<LinearLayout>(R.id.osdQuickCardsRow)
        row.removeAllViews()

        fun addCard(label: String, iconRes: Int? = null, logoUrl: String? = null, onClick: () -> Unit) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                background = getDrawable(R.drawable.bg_focus_card)
                isFocusable = true
                isClickable = true
                setPadding(16, 12, 16, 12)
                layoutParams = LinearLayout.LayoutParams(160, 110).apply { marginEnd = 12 }
            }
            val iv = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(44, 44)
                if (!logoUrl.isNullOrEmpty()) load(logoUrl)
                else if (iconRes != null) setImageResource(iconRes)
            }
            val tv = TextView(this).apply {
                text = label
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(getColor(R.color.tivi_text_primary))
                textSize = 11f
                gravity = android.view.Gravity.CENTER
                setPadding(0, 8, 0, 0)
            }
            card.addView(iv)
            card.addView(tv)
            card.setOnClickListener { onClick() }
            row.addView(card)
        }

        if (storage.getSettings().showTvGuideButton) {
            addCard("TV guide", R.drawable.ic_list) { finish() }
        }
        if (storage.getSettings().showHistoryButton) {
            addCard("History", R.drawable.ic_history) { channelsOverlay.visibility = View.VISIBLE }
        }
        val recentIds = storage.getRecentChannelIds().take(6)
        recentIds.forEach { id ->
            val ch = channels.find { it.id == id }
            if (ch != null) {
                addCard(ch.name, R.drawable.ic_tv, ch.logoUrl) {
                    val idx = channels.indexOfFirst { it.id == ch.id }
                    if (idx >= 0) playChannelAt(idx)
                }
            }
        }
        if (recentIds.isNotEmpty()) {
            addCard("Clear", R.drawable.ic_delete) {
                storage.clearRecentChannels()
                setupQuickCards()
            }
        }
    }

    private fun setupBottomActions() {
        val rv = findViewById<RecyclerView>(R.id.osdActionsRecycler)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        val currentCh = channels.getOrNull(currentIndex)
        val isFav = currentCh != null && storage.getFavorites().contains(currentCh.id)
        val vs = player?.videoSize
        val resText = if (vs != null && vs.width > 0) "${vs.width}×${vs.height}" else "Auto"
        val hdrOn = storage.getSettings().hdrMode

        val actions = listOf(
            Triple("Search", R.drawable.ic_search) {
                startActivity(Intent(this, MainActivity::class.java).putExtra("open_tab", "search"))
                finish()
            },
            Triple("Channels list", R.drawable.ic_list) {
                channelsOverlay.visibility = if (channelsOverlay.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            },
            Triple("Recordings", R.drawable.ic_dvr) {
                startActivity(Intent(this, MainActivity::class.java).putExtra("open_tab", "recordings"))
                finish()
            },
            Triple("Multiview", R.drawable.ic_multiview) { toggleMultiview() },
            Triple("Picture-in-picture", R.drawable.ic_pip) { enterPip() },
            Triple(resText, R.drawable.ic_video) { showTrackPicker(C.TRACK_TYPE_VIDEO, "Video tracks") },
            Triple("Audio", R.drawable.ic_audio) { showTrackPicker(C.TRACK_TYPE_AUDIO, "Audio tracks") },
            Triple("$audioOffsetMs ms", R.drawable.ic_audio) { showAudioOffsetDialog() },
            Triple("Off", R.drawable.ic_subtitles) { showTrackPicker(C.TRACK_TYPE_TEXT, "Subtitles (CC)") },
            Triple(resizeLabel, R.drawable.ic_aspect) { cycleAspectRatio() },
            Triple(if (hdrOn) "HDR ON" else "HDR OFF", R.drawable.ic_video) {
                val s = storage.getSettings()
                s.hdrMode = !s.hdrMode
                storage.saveSettings(s)
                applyHdrBoost(s.hdrMode)
                setupBottomActions()
            },
            Triple(if (sleepMinutes > 0) "${sleepMinutes}m" else "Off", R.drawable.ic_sleep) { showSleepTimerDialog() },
            Triple(if (isFav) "Favorited" else "Add to Favorites", R.drawable.ic_star) {
                if (currentCh != null) {
                    val added = storage.toggleFavorite(currentCh.id)
                    Toast.makeText(this, if (added) "Added to Favorites" else "Removed from Favorites", Toast.LENGTH_SHORT).show()
                    setupBottomActions()
                }
            },
            Triple("Settings", R.drawable.ic_settings) {
                startActivity(Intent(this, MainActivity::class.java).putExtra("open_tab", "settings"))
                finish()
            }
        )

        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.item_osd_action, parent, false)
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun getItemCount() = actions.size

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val (label, icon, act) = actions[position]
                holder.itemView.findViewById<ImageView>(R.id.osdActionIcon).setImageResource(icon)
                holder.itemView.findViewById<TextView>(R.id.osdActionLabel).text = label
                holder.itemView.setOnClickListener {
                    showOsd()
                    act()
                }
            }
        }
    }

    private fun setupChannelsOverlay() {
        val rv = findViewById<RecyclerView>(R.id.playerChannelsRecycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.item_wizard_option, parent, false)
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun getItemCount() = channels.size

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val ch = channels[position]
                val tv = holder.itemView.findViewById<TextView>(R.id.optTitle)
                val sub = holder.itemView.findViewById<TextView>(R.id.optSubtitle)
                tv.text = "${ch.number}. ${ch.name}"
                sub.text = ch.groupTitle
                sub.visibility = View.VISIBLE
                holder.itemView.setOnClickListener {
                    channelsOverlay.visibility = View.GONE
                    playChannelAt(position)
                }
            }
        }
    }

    private fun toggleMultiview() {
        isMultiview = !isMultiview
        if (isMultiview && channels.size >= 2) {
            playerView.visibility = View.GONE
            multiviewGrid.visibility = View.VISIBLE
            val views = listOf(
                findViewById<PlayerView>(R.id.mvPlayer1),
                findViewById<PlayerView>(R.id.mvPlayer2),
                findViewById<PlayerView>(R.id.mvPlayer3),
                findViewById<PlayerView>(R.id.mvPlayer4)
            )
            mvPlayers.forEach { it.release() }
            mvPlayers.clear()
            for (i in 0 until 4) {
                val ch = channels[(currentIndex + i) % channels.size]
                val p = buildExoPlayer("")
                views[i].player = p
                p.setMediaItem(MediaItem.fromUri(Uri.parse(ch.streamUrl)))
                p.volume = if (i == 0) 1f else 0f
                p.prepare()
                p.playWhenReady = true
                mvPlayers.add(p)
                views[i].setOnClickListener {
                    mvPlayers.forEachIndexed { idx, mp -> mp.volume = if (idx == i) 1f else 0f }
                }
            }
        } else {
            mvPlayers.forEach { it.release() }
            mvPlayers.clear()
            multiviewGrid.visibility = View.GONE
            playerView.visibility = View.VISIBLE
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            osdOverlay.visibility = View.GONE
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (storage.getSettings().pipOnHome) {
            enterPip()
        }
    }

    private fun cycleAspectRatio() {
        when (currentResizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> {
                currentResizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                resizeLabel = "Zoom"
            }
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> {
                currentResizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                resizeLabel = "Fill"
            }
            else -> {
                currentResizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                resizeLabel = "Normal"
            }
        }
        playerView.resizeMode = currentResizeMode
        setupBottomActions()
    }

    private fun showTrackPicker(trackType: Int, title: String) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == trackType }
        if (groups.isEmpty()) {
            Toast.makeText(this, "No tracks available", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        groups.forEach { g ->
            for (i in 0 until g.length) {
                val fmt = g.getTrackFormat(i)
                val lbl = when (trackType) {
                    C.TRACK_TYPE_VIDEO -> "${fmt.width}×${fmt.height} (${fmt.bitrate / 1000} kbps)"
                    C.TRACK_TYPE_AUDIO -> "${fmt.language ?: "und"} • ${fmt.channelCount}ch"
                    else -> fmt.language ?: "Subtitle ${i + 1}"
                }
                labels.add(lbl)
                actions.add {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                        .build()
                }
            }
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showAudioOffsetDialog() {
        val opts = arrayOf("-500 ms", "-250 ms", "0 ms", "+250 ms", "+500 ms")
        val vals = intArrayOf(-500, -250, 0, 250, 500)
        AlertDialog.Builder(this)
            .setTitle("Audio offset")
            .setItems(opts) { _, which ->
                audioOffsetMs = vals[which]
                setupBottomActions()
            }
            .show()
    }

    private fun showSleepTimerDialog() {
        val opts = arrayOf("Off", "15 min", "30 min", "60 min", "90 min", "120 min")
        val mins = intArrayOf(0, 15, 30, 60, 90, 120)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(opts) { _, which ->
                sleepMinutes = mins[which]
                handler.removeCallbacks(sleepRunnable)
                if (sleepMinutes > 0) {
                    handler.postDelayed(sleepRunnable, sleepMinutes * 60_000L)
                }
                setupBottomActions()
            }
            .show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MENU -> {
                toggleOsd()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (osdOverlay.visibility != View.VISIBLE && vodUrl == null) {
                    playChannelAt(currentIndex - 1)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (osdOverlay.visibility != View.VISIBLE && vodUrl == null) {
                    playChannelAt(currentIndex + 1)
                    return true
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                if (channelsOverlay.visibility == View.VISIBLE) {
                    channelsOverlay.visibility = View.GONE
                    return true
                }
                if (osdOverlay.visibility == View.VISIBLE) {
                    osdOverlay.visibility = View.GONE
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        mvPlayers.forEach { it.release() }
    }
}
